rm /data/dalvik-cache/*/system@framework@services.jar@classes.*
rm /data/misc/apexdata/com.android.art/dalvik-cache/*/system@framework@services.jar@classes.*

rm /data/dalvik-cache/*/system@framework@semwifi-service.jar@classes.*
rm /data/misc/apexdata/com.android.art/dalvik-cache/*/system@framework@semwifi-service.jar@classes.*

rm /data/dalvik-cache/*/system_ext@framework@miui-services.jar@classes.*
rm /data/misc/apexdata/com.android.art/dalvik-cache/*/system_ext@framework@miui-services.jar@classes.*
