# Mountify WebUI Translation Contributor List

## Chinese (Simplified)

- [KOWX712](https://github.com/KOWX712)

---

## English

- [KOWX712](https://github.com/KOWX712)

## Portuguese (Brazil)

- [brutw](https://github.com/brutw)
