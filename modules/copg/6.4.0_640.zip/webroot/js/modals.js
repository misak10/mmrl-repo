/* ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
   modals.js — Device & Package add/edit/delete modals
   Built as bottom-sheets (same visual family as theme/lang sheets).
   Data goes through COPG.* (js/copg-data.js); on save calls
   window.LibRefresh() (defined in library.js) to persist + re-render.
   ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━ */
(function (w) {

  /* ─── DOM scaffold: inject three sheets + reuse #sheetOverlay ─── */
  const mount = document.getElementById('modalRoot') || document.body;

  /* little info "ⓘ" used on the cpu/got toggle rows → tap for a plain explanation */
  const INFO_SVG =
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`;
  const WARN_SVG =
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10.29 3.86 1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;

  mount.insertAdjacentHTML('beforeend', `
    <!-- DEVICE MODAL -->
    <div class="bottom-sheet sheet--form" id="deviceModal" role="dialog" aria-modal="true">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <span class="sheet-header__title" id="deviceModalTitle" data-i18n="dev_add_title">Add Device</span>
        <button class="sheet-header__close" data-close="deviceModal" aria-label="Close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <form class="sheet-body form-body" id="deviceForm" autocomplete="off" novalidate>
        <label class="field"><span class="field__label" data-i18n="dev_f_name">Device Name</span>
          <input class="field__input" id="dfName" type="text" placeholder="Pixel 8 Pro" required /></label>
        <label class="field"><span class="field__label" data-i18n="dev_f_brand">Brand</span>
          <input class="field__input" id="dfBrand" type="text" placeholder="google" required /></label>
        <label class="field"><span class="field__label" data-i18n="dev_f_model">Model</span>
          <input class="field__input" id="dfModel" type="text" placeholder="Pixel 8 Pro" required /></label>
        <label class="field"><span class="field__label" data-i18n="dev_f_manufacturer">Manufacturer</span>
          <input class="field__input" id="dfManufacturer" type="text" placeholder="Google" required /></label>
        <label class="field"><span class="field__label" data-i18n="dev_f_fingerprint">Fingerprint</span>
          <input class="field__input field__input--mono" id="dfFingerprint" type="text" placeholder="google/husky/husky:15/AP3A.240617.008/12345678:user/release-keys" required /></label>
        <div class="adv-group" id="dfAdvGroup">
          <button type="button" class="adv-toggle" id="dfAdvToggle" aria-expanded="false">
            <span class="field__label" data-i18n="dev_adv_title">Advanced build props</span>
            <span class="field__opt" data-i18n="opt_optional">(optional)</span>
            <span class="field__warn field__warn--inline" id="dfAdvInfo" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span>
            <svg class="adv-caret" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
          </button>
          <div class="adv-body" id="dfAdvBody" hidden>
            <div class="field-row">
              <label class="field"><span class="field__head"><span class="field__label" data-i18n="dev_f_android">Android Version</span></span>
                <input class="field__input" id="dfAndroid" type="text" inputmode="decimal" placeholder="15" /></label>
              <label class="field"><span class="field__head"><span class="field__label" data-i18n="dev_f_sdk">SDK Int</span><span class="field__warn field__warn--inline" id="dfSdkWarn" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
                <input class="field__input" id="dfSdk" type="text" inputmode="numeric" placeholder="35" /></label>
            </div>
            <label class="field"><span class="field__head"><span class="field__label" data-i18n="dev_f_serial">Serial Number</span><span class="field__gen" id="dfSerialGen" role="button" tabindex="0" data-i18n="serial_gen">Generate</span></span>
              <input class="field__input field__input--mono" id="dfSerial" type="text" maxlength="24" placeholder="1A2B3C4D" /></label>
            <div class="field-row">
              <label class="field"><span class="field__label" data-i18n="dev_f_board">Board</span>
                <input class="field__input field__input--mono" id="dfBoard" type="text" placeholder="sm8650" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
              <label class="field"><span class="field__label" data-i18n="dev_f_hardware">Hardware</span>
                <input class="field__input field__input--mono" id="dfHardware" type="text" placeholder="qcom" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
            </div>
            <div class="field-row">
              <label class="field"><span class="field__label" data-i18n="dev_f_buildid">Build ID</span>
                <input class="field__input field__input--mono" id="dfId" type="text" placeholder="AP3A.240617.008" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
              <label class="field"><span class="field__label" data-i18n="dev_f_display">Display ID</span>
                <input class="field__input field__input--mono" id="dfDisplay" type="text" placeholder="AP3A.240617.008" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
            </div>
            <div class="field-row">
              <label class="field"><span class="field__label" data-i18n="dev_f_bootloader">Bootloader</span>
                <input class="field__input field__input--mono" id="dfBootloader" type="text" placeholder="unknown" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
              <label class="field"><span class="field__label" data-i18n="dev_f_tags">Build Tags</span>
                <input class="field__input field__input--mono" id="dfTags" type="text" placeholder="release-keys" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
            </div>
            <div class="field-row">
              <label class="field"><span class="field__label" data-i18n="dev_f_btype">Build Type</span>
                <input class="field__input field__input--mono" id="dfType" type="text" placeholder="user" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
              <label class="field"><span class="field__label" data-i18n="dev_f_codename">Codename</span>
                <input class="field__input field__input--mono" id="dfCodename" type="text" placeholder="REL" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
            </div>
            <div class="field-row">
              <label class="field"><span class="field__head"><span class="field__label" data-i18n="dev_f_secpatch">Security Patch</span><span class="field__gen" id="dfSecPatchGen" role="button" tabindex="0" data-i18n="serial_gen">Generate</span></span>
                <input class="field__input field__input--mono" id="dfSecPatch" type="text" placeholder="2025-09-05" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
              <label class="field"><span class="field__head"><span class="field__label" data-i18n="dev_f_incremental">Incremental</span><span class="field__gen" id="dfIncrementalGen" role="button" tabindex="0" data-i18n="serial_gen">Generate</span></span>
                <input class="field__input field__input--mono" id="dfIncremental" type="text" placeholder="20250910.230227" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
            </div>
            <div class="field-row">
              <label class="field"><span class="field__label" data-i18n="dev_f_socman">SOC Manufacturer</span>
                <input class="field__input field__input--mono" id="dfSocMan" type="text" placeholder="Qualcomm" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
              <label class="field"><span class="field__label" data-i18n="dev_f_socmodel">SOC Model</span>
                <input class="field__input field__input--mono" id="dfSocModel" type="text" placeholder="SM8650" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
            </div>
            <label class="field"><span class="field__head"><span class="field__label" data-i18n="dev_f_radio">Baseband version</span><span class="field__gen" id="dfRadioGen" role="button" tabindex="0" data-i18n="serial_gen">Generate</span></span>
              <input class="field__input field__input--mono" id="dfRadio" type="text" placeholder="MPSS.HI.3.0.c4-00108-SM8650_GEN_PACK-1" autocapitalize="off" autocorrect="off" spellcheck="false" /></label>
          </div>
        </div>
        <div class="form-buttons">
          <button type="button" class="btn btn--ghost" data-close="deviceModal" data-i18n="btn_cancel">Cancel</button>
          <button type="submit" class="btn btn--primary" data-i18n="btn_save">Save</button>
        </div>
      </form>
    </div>

    <!-- DEVICE SHARE (export/import code) MODAL -->
    <div class="bottom-sheet sheet--form" id="deviceShareModal" role="dialog" aria-modal="true">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <span class="sheet-header__title" id="dsTitle" data-i18n="dev_share_title">Share Device</span>
        <button class="sheet-header__close" data-close="deviceShareModal" aria-label="Close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <div class="sheet-body form-body">
        <p class="ds-hint" id="dsHint" data-i18n="dev_export_hint">Copy this code and send it to anyone — they can import this device without re-typing every field.</p>
        <label class="ds-pkgrow" id="dsPkgRow" hidden>
          <input type="checkbox" id="dsInclPkgs" />
          <span id="dsPkgLabel" data-i18n="dev_incl_pkgs">Include packages</span>
        </label>
        <label class="field"><span class="field__label" data-i18n="dev_code_label">Device Code</span>
          <textarea class="field__input" id="dsCode" rows="4" spellcheck="false" autocapitalize="off" autocomplete="off" placeholder="COPG-DEV1:…"></textarea></label>
        <div class="sheet-footer">
          <button type="button" class="btn btn--ghost" data-close="deviceShareModal" data-i18n="btn_cancel">Cancel</button>
          <button type="button" class="btn btn--primary" id="dsAction" data-i18n="act_copy">Copy</button>
        </div>
      </div>
    </div>

    <!-- PACKAGE MODAL -->
    <div class="bottom-sheet sheet--form" id="packageModal" role="dialog" aria-modal="true">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <span class="sheet-header__title" id="packageModalTitle" data-i18n="pkg_add_title">Add Package</span>
        <button class="sheet-header__close" data-close="packageModal" aria-label="Close">
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
        </button>
      </div>
      <form class="sheet-body form-body" id="packageForm" autocomplete="off">
        <label class="field"><span class="field__label" data-i18n="pkg_f_package">Package Name</span>
          <div class="field-with-btn">
            <input class="field__input field__input--mono" id="pfPackage" type="text" required placeholder="com.example.app" />
            <button type="button" class="field-pick-btn" id="pfPickBtn" data-i18n-attr="aria-label:pick_from_installed" aria-label="Pick from installed apps">
              <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="2.2" fill="currentColor" stroke="none"/><rect x="14" y="3" width="7" height="7" rx="2.2"/><rect x="3" y="14" width="7" height="7" rx="2.2"/><rect x="14" y="14" width="7" height="7" rx="2.2"/></svg>
            </button>
          </div></label>
        <label class="field"><span class="field__label" data-i18n="pkg_f_name">Display Name</span>
          <input class="field__input" id="pfName" type="text" placeholder="My Game" /></label>


        <div class="field" id="pfDeviceField"><span class="field__label" data-i18n="pkg_f_device">Device Profile</span>
          <button type="button" class="field__input field__picker" id="pfDevice" data-i18n-attr="aria-label:pkg_f_device" aria-label="Device Profile">
            <span class="field__picker-text is-placeholder" id="pfDeviceText" data-i18n="pkg_pick_device">Choose a device…</span>
            <svg class="field__picker-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
          </button></div>

        <div id="pfToggles">
         <div class="toggles toggle-group" id="pfSpoofGroup">
          <button type="button" class="toggles__head toggles__head--btn" id="pfSpoofHead" aria-expanded="false">
            <span data-i18n="pkg_sec_spoofing">Spoofing</span>
            <svg class="adv-caret" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
          </button>
          <div class="toggle-body" id="pfSpoofBody" hidden>
          <label class="trow" id="pfWithCpuRow">
            <span class="trow__label"><span data-i18n="pkg_t_withcpu">With CPU Spoofing</span>
              <span class="trow__info" role="button" tabindex="0" data-info="withcpu" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfWithCpu"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfCpuRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_cpu_model">CPU Model</span>
            <button type="button" class="field__input field__picker" id="pfCpuModel" data-i18n-attr="aria-label:pkg_cpu_model" aria-label="CPU Model">
              <span class="field__picker-text" id="pfCpuModelText" data-i18n="pkg_cpu_default">Qualcomm Snapdragon 8 Elite</span>
              <svg class="field__picker-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
            </button></div>
          <label class="trow" id="pfBlockRow">
            <span class="trow__label"><span data-i18n="pkg_t_block">Block CPU</span>
              <span class="trow__info" role="button" tabindex="0" data-info="block" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfBlock"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <label class="trow" id="pfCowRow">
            <span class="trow__label"><span data-i18n="pkg_t_cow">COW Prop Spoof</span>
              <span class="trow__pro" id="pfCowPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info" data-info="cow" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfCow"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <label class="trow" id="pfAidRow">
            <span class="trow__label"><span data-i18n="pkg_t_aid">Spoof Android ID</span>
              <span class="trow__pro" id="pfAidPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info" id="pfAidInfo" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfAid"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfAidValRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_aid_value">Android ID</span>
            <input class="field__input" id="pfAidVal" type="text" maxlength="16" spellcheck="false" autocapitalize="none" autocomplete="off" placeholder="auto (from seed)" style="flex:1;min-width:0;text-transform:lowercase" />
            <button type="button" class="field__input field__picker" id="pfAidGen" data-i18n-attr="aria-label:pkg_aid_gen" aria-label="Generate" style="flex:none;width:auto;padding:0 12px;justify-content:center">↻</button>
          </div>
          <label class="trow" id="pfSerialRow">
            <span class="trow__label"><span data-i18n="pkg_t_serial">Custom serial</span>
              <span id="pfSerialHint" hidden data-i18n="pkg_serial_locked" style="font-size:11px;opacity:.6;margin-left:6px">Set by device profile</span>
              <span class="trow__info" data-info="serial" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfSerial"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfSerialValRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_serial_value">Serial</span>
            <input class="field__input" id="pfSerialVal" type="text" maxlength="24" spellcheck="false" autocapitalize="characters" autocomplete="off" placeholder="auto (from package)" style="flex:1;min-width:0;text-transform:uppercase" />
            <button type="button" class="field__input field__picker" id="pfSerialGen" data-i18n-attr="aria-label:pkg_serial_gen" aria-label="Generate" style="flex:none;width:auto;padding:0 12px;justify-content:center">↻</button>
          </div>
          <label class="trow" id="pfGaidRow">
            <span class="trow__label"><span data-i18n="pkg_t_gaid">Spoof Advertising ID</span>
              <span class="trow__pro" id="pfGaidPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info trow__info--warn" id="pfGaidInfo" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfGaid"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfGaidValRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_gaid_value">Advertising ID</span>
            <input class="field__input" id="pfGaidVal" type="text" maxlength="36" spellcheck="false" autocapitalize="none" autocomplete="off" placeholder="auto (from seed)" style="flex:1;min-width:0;text-transform:lowercase" />
            <button type="button" class="field__input field__picker" id="pfGaidGen" data-i18n-attr="aria-label:pkg_gaid_gen" aria-label="Generate" style="flex:none;width:auto;padding:0 12px;justify-content:center">↻</button>
          </div>
          <label class="trow" id="pfAppSetRow">
            <span class="trow__label"><span data-i18n="pkg_t_appset">Spoof App Set ID</span>
              <span class="trow__pro" id="pfAppSetPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info trow__info--warn" id="pfAppSetInfo" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfAppSet"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfAppSetValRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_appset_value">App Set ID</span>
            <input class="field__input" id="pfAppSetVal" type="text" maxlength="36" spellcheck="false" autocapitalize="none" autocomplete="off" placeholder="auto (per-app)" style="flex:1;min-width:0;text-transform:lowercase" />
            <button type="button" class="field__input field__picker" id="pfAppSetGen" data-i18n-attr="aria-label:pkg_appset_gen" aria-label="Generate" style="flex:none;width:auto;padding:0 12px;justify-content:center">↻</button>
          </div>
          <label class="trow" id="pfHideDevRow">
            <span class="trow__label"><span data-i18n="pkg_t_hidedev">Hide Dev Options</span>
              <span class="trow__info" data-info="hidedev" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfHideDev"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow" id="pfTzRow">
            <span class="trow__label"><span data-i18n="pkg_t_tz">Timezone</span>
              <span class="trow__info" data-info="tz" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <button type="button" class="field__input field__picker" id="pfTzPick" style="flex:none;width:auto;max-width:60%" data-i18n-attr="aria-label:pkg_t_tz" aria-label="Timezone">
              <span class="field__picker-text" id="pfTzText" data-i18n="pkg_tz_off">Real (off)</span>
              <svg class="field__picker-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
            </button></div>
          <div class="trow" id="pfLangRow">
            <span class="trow__label"><span data-i18n="pkg_t_lang">Language</span>
              <span class="trow__info" data-info="lang" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <button type="button" class="field__input field__picker" id="pfLangPick" style="flex:none;width:auto;max-width:60%" data-i18n-attr="aria-label:pkg_t_lang" aria-label="Language">
              <span class="field__picker-text" id="pfLangText" data-i18n="pkg_lang_off">Real (off)</span>
              <svg class="field__picker-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
            </button></div>
          <label class="trow" id="pfGpuRow">
            <span class="trow__label"><span data-i18n="pkg_t_gpu">GPU Spoof</span>
              <span class="trow__pro" id="pfGpuPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info trow__info--warn" role="button" tabindex="0" data-info="gpu" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfGpu"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfGpuModelRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_gpu_model">GPU Model</span>
            <button type="button" class="field__input field__picker" id="pfGpuModel" data-i18n-attr="aria-label:pkg_gpu_model" aria-label="GPU Model">
              <span class="field__picker-text" id="pfGpuModelText" data-i18n="pkg_gpu_default">Adreno 830 (Snapdragon 8 Elite)</span>
              <svg class="field__picker-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
            </button></div>
          <label class="trow" id="pfMockRow">
            <span class="trow__label"><span data-i18n="pkg_t_mock">Mock Location Hide</span>
              <span class="trow__pro" id="pfMockPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info trow__info--warn" data-info="mock" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfMock"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <label class="trow" id="pfUptimeRow">
            <span class="trow__label"><span data-i18n="pkg_t_uptime">Fake Uptime</span>
              <span class="trow__pro" id="pfUptimePro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info trow__info--warn" data-info="uptime" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfUptime"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfUptimeValRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_uptime_value">Uptime (days)</span>
            <input class="field__input" id="pfUptimeD" type="number" min="0" max="3650" step="0.1" inputmode="decimal" placeholder="e.g. 5" style="flex:1;min-width:0" />
          </div>
          <label class="trow" id="pfRrRow">
            <span class="trow__label"><span data-i18n="pkg_t_rr">Spoof Refresh Rate</span>
              <span class="trow__info trow__info--warn" data-info="rr" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfRr"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfRrValRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_rr_value">Refresh rate (Hz)</span>
            <input class="field__input" id="pfRrHz" type="number" min="24" max="480" step="1" inputmode="numeric" placeholder="e.g. 120" style="flex:1;min-width:0" />
          </div>
          <label class="trow" id="pfDrmRow">
            <span class="trow__label"><span data-i18n="pkg_t_drm">Spoof DRM (Widevine)</span>
              <span class="trow__pro" id="pfDrmPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info trow__info--warn" data-info="drm" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfDrm"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfDrmLevelRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_drm_level">Security Level</span>
            <div class="seg" id="pfDrmLevel" data-level="L1">
              <button type="button" class="seg__opt active" data-level="L1">L1</button>
              <button type="button" class="seg__opt" data-level="L2">L2</button>
              <button type="button" class="seg__opt" data-level="L3">L3</button>
            </div>
          </div>
          <div class="trow-sub" id="pfDrmIdRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_drmid_value">Device Unique ID</span>
            <input class="field__input" id="pfDrmIdVal" type="text" maxlength="44" spellcheck="false" autocapitalize="none" autocomplete="off" placeholder="auto (per-app)" style="flex:1;min-width:0" />
            <button type="button" class="field__input field__picker" id="pfDrmIdFmt" data-i18n-attr="aria-label:pkg_drmid_fmt" aria-label="Toggle format" style="flex:none;width:auto;padding:0 10px;justify-content:center;font-size:11px;font-weight:600">B64</button>
            <button type="button" class="field__input field__picker" id="pfDrmIdGen" data-i18n-attr="aria-label:pkg_drmid_gen" aria-label="Generate" style="flex:none;width:auto;padding:0 12px;justify-content:center">↻</button>
          </div>
          <div class="trow-sub" id="pfDrmSysRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_drmsys_value">System ID</span>
            <input class="field__input" id="pfDrmSysVal" type="text" inputmode="numeric" maxlength="10" spellcheck="false" autocapitalize="none" autocomplete="off" placeholder="auto (per-app)" style="flex:1;min-width:0" />
            <button type="button" class="field__input field__picker" id="pfDrmSysGen" data-i18n-attr="aria-label:pkg_drmsys_gen" aria-label="Generate" style="flex:none;width:auto;padding:0 12px;justify-content:center">↻</button>
          </div>
          <label class="trow" id="pfImeiRow">
            <span class="trow__label"><span data-i18n="pkg_t_imei">Spoof IMEI</span>
              <span class="trow__pro" id="pfImeiPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info trow__info--warn" data-info="imei" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfImei"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfImeiValRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_imei_value">IMEI (SIM 1)</span>
            <input class="field__input" id="pfImeiVal" type="text" inputmode="numeric" maxlength="15" spellcheck="false" autocapitalize="none" autocomplete="off" placeholder="auto (per-app)" style="flex:1;min-width:0" />
            <button type="button" class="field__input field__picker" id="pfImeiGen" data-i18n-attr="aria-label:pkg_imei_gen" aria-label="Generate" style="flex:none;width:auto;padding:0 12px;justify-content:center">↻</button>
          </div>
          <div class="trow-sub" id="pfImei2ValRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_imei2_value">IMEI (SIM 2)</span>
            <input class="field__input" id="pfImei2Val" type="text" inputmode="numeric" maxlength="15" spellcheck="false" autocapitalize="none" autocomplete="off" placeholder="auto (per-app)" style="flex:1;min-width:0" />
            <button type="button" class="field__input field__picker" id="pfImei2Gen" data-i18n-attr="aria-label:pkg_imei2_gen" aria-label="Generate" style="flex:none;width:auto;padding:0 12px;justify-content:center">↻</button>
          </div>
          <label class="trow" id="pfWebuaRow">
            <span class="trow__label"><span data-i18n="pkg_t_webua">WebView User-Agent</span>
              <span class="trow__pro" id="pfWebuaPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info trow__info--warn" data-info="webua" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfWebua"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfWebuaValRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_webua_value">User-Agent</span>
            <button type="button" class="field__input field__picker" id="pfWebuaPick" data-i18n-attr="aria-label:pkg_t_webua" aria-label="User-Agent" style="flex:1;min-width:0">
              <span class="field__picker-text" id="pfWebuaPickText" data-i18n="pkg_webua_off">Choose…</span>
            </button>
          </div>
          <label class="trow" id="pfVpnRow">
            <span class="trow__label"><span data-i18n="pkg_t_vpn">Hide VPN</span>
              <span class="trow__info" data-info="vpns" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfVpn"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <label class="trow-sub trow-sub--warn trow-sub--toggle" id="pfVpnAggRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_t_vpn_agg">Aggressive (in-app)</span>
            <span class="trow__info trow__info--warn" data-info="vpn" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${WARN_SVG}</span>
            <span class="toggle"><input type="checkbox" id="pfVpnAgg"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <label class="trow" id="pfSimRow">
            <span class="trow__label"><span data-i18n="pkg_t_sim">SIM / Carrier Spoof</span>
              <span class="trow__pro" id="pfSimPro" hidden><svg class="trow__pro-lock" width="9" height="9" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg><span data-i18n="lic_pro_tag">PRO</span></span>
              <span class="trow__info" data-info="sim" role="button" tabindex="0" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="trow__lockico" aria-hidden="true"><svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="4" y="10" width="16" height="11" rx="2"/><path d="M8 10V7a4 4 0 0 1 8 0v3"/></svg></span>
            <span class="toggle"><input type="checkbox" id="pfSim"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <div class="trow-sub" id="pfSimModeRow" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_sim_mode">Mode</span>
            <div class="seg" id="pfSimMode" data-mode="safe">
              <button type="button" class="seg__opt active" data-mode="safe" data-i18n="pkg_sim_safe">Safe</button>
              <button type="button" class="seg__opt" data-mode="aggressive"><span data-i18n="pkg_sim_aggr">Aggressive</span><span class="seg__unsafe" aria-hidden="true" title="Unsafe — resident/detectable">${WARN_SVG}</span></button>
            </div></div>
          <div class="trow-sub" id="pfSim1Row" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_sim_slot1">SIM 1</span>
            <button type="button" class="field__input field__picker" id="pfSim1Model" data-i18n-attr="aria-label:pkg_sim_slot1" aria-label="SIM 1">
              <span class="field__picker-text" id="pfSim1Text" data-i18n="pkg_sim_none">None (real)</span>
              <svg class="field__picker-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
            </button></div>
          <div class="trow-sub" id="pfSim2Row" style="display:none">
            <span class="trow-sub__label" data-i18n="pkg_sim_slot2">SIM 2</span>
            <button type="button" class="field__input field__picker" id="pfSim2Model" data-i18n-attr="aria-label:pkg_sim_slot2" aria-label="SIM 2">
              <span class="field__picker-text" id="pfSim2Text" data-i18n="pkg_sim_none">None (real)</span>
              <svg class="field__picker-chevron" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
            </button></div>
          </div>
         </div>

         <div class="toggles toggle-group" id="pfTweakGroup">
          <button type="button" class="toggles__head toggles__head--btn" id="pfTweakHead" aria-expanded="false">
            <span data-i18n="pkg_sec_tweaks">Tweaks</span>
            <svg class="adv-caret" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>
          </button>
          <div class="toggle-body" id="pfTweakBody" hidden>
          <label class="trow" id="pfDndRow">
            <span class="trow__label"><span data-i18n="pkg_t_dnd">Do Not Disturb</span>
              <span class="trow__info" role="button" tabindex="0" data-info="dnd" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfDnd"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <label class="trow" id="pfDabRow">
            <span class="trow__label"><span data-i18n="pkg_t_dab">Disable Auto-Brightness</span>
              <span class="trow__info" role="button" tabindex="0" data-info="dab" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfDab"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <label class="trow" id="pfKsoRow">
            <span class="trow__label"><span data-i18n="pkg_t_kso">Keep Screen On</span>
              <span class="trow__info" role="button" tabindex="0" data-info="kso" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfKso"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <label class="trow" id="pfNologRow">
            <span class="trow__label"><span data-i18n="pkg_t_nolog">Disable Logging</span>
              <span class="trow__info" role="button" tabindex="0" data-info="nolog" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <span class="toggle"><input type="checkbox" id="pfNolog"><span class="toggle__track"><span class="toggle__thumb"></span></span></span></label>
          <label class="trow" id="pfDpiRow">
            <span class="trow__label"><span data-i18n="pkg_t_dpi">Screen DPI</span>
              <span class="trow__info" role="button" tabindex="0" data-info="dpi" data-i18n-attr="aria-label:info_aria" aria-label="What's this?">${INFO_SVG}</span></span>
            <input class="field__input" id="pfDpi" type="number" min="120" max="640" step="1" inputmode="numeric" placeholder="e.g. 480" style="width:92px;flex:0 0 auto;text-align:center" /></label>
          </div>
         </div>
        </div>

        <div class="form-error" id="pfError" hidden></div>
        <div class="form-buttons">
          <button type="button" class="btn btn--ghost" data-close="packageModal" data-i18n="btn_cancel">Cancel</button>
          <button type="submit" class="btn btn--primary" data-i18n="btn_save">Save</button>
        </div>
      </form>
    </div>

    <!-- CONFIRM DELETE -->
    <div class="bottom-sheet sheet--confirm" id="confirmModal" role="dialog" aria-modal="true">
      <div class="sheet-handle"></div>
      <div class="sheet-header">
        <span class="sheet-header__title" id="confirmTitle">Delete</span>
      </div>
      <div class="sheet-body">
        <p class="confirm-msg" id="confirmMsg"></p>
        <a class="confirm-link" id="confirmLink" target="_blank" rel="noopener noreferrer" hidden></a>
        <label class="confirm-dsa" id="confirmDsaRow" hidden>
          <input type="checkbox" id="confirmDsa" />
          <span data-i18n="risk_dsa">Don't show this warning again</span>
        </label>
        <div class="form-buttons" id="confirmBtns">
          <button type="button" class="btn btn--ghost" id="confirmCancel" data-close="confirmModal" data-i18n="btn_cancel">Cancel</button>
          <button type="button" class="btn btn--ghost" id="confirmAlt" hidden></button>
          <button type="button" class="btn btn--danger" id="confirmOk" data-i18n="btn_delete">Delete</button>
        </div>
      </div>
    </div>
  `);

  const $m = s => document.querySelector(s);
  const overlay = () => document.getElementById('sheetOverlay');

  // Clearing any inline transform/transition is essential: a drag-to-dismiss
  // gesture (gestures.js) leaves an inline `transform:translateY()` that BEATS
  // the `.bottom-sheet.open` rule, so a sheet could otherwise never visually
  // reopen after being dragged (no error, no log — just "nothing happens").
  function clearDrag(el) { if (el) { el.style.transition = ''; el.style.transform = ''; } }

  function openModal(id) {
    overlay()?.classList.add('visible');
    const sheet = document.getElementById(id);
    clearDrag(sheet);
    requestAnimationFrame(() => sheet?.classList.add('open'));
  }
  function closeModal(id) {
    const sheet = document.getElementById(id);
    sheet?.classList.remove('open');
    clearDrag(sheet);
    if (![...document.querySelectorAll('.bottom-sheet.open')].length) overlay()?.classList.remove('visible');
  }
  function closeAll() {
    document.querySelectorAll('.bottom-sheet').forEach(s => { s.classList.remove('open'); clearDrag(s); });
    overlay()?.classList.remove('visible');
  }

  // close buttons + overlay
  document.querySelectorAll('[data-close]').forEach(b =>
    b.addEventListener('click', () => closeModal(b.dataset.close)));
  overlay()?.addEventListener('click', closeAll);

  /* field error helpers */
  function clearErrors(form) {
    form.querySelectorAll('.field--error').forEach(f => f.classList.remove('field--error'));
    form.querySelectorAll('.field-msg').forEach(m => m.remove());
  }
  function markError(inputEl, msg) {
    const field = inputEl.closest('.field') || inputEl.parentNode;
    field.classList.add('field--error');
    const span = document.createElement('span');
    span.className = 'field-msg';
    span.textContent = msg;
    field.appendChild(span);
  }
  function clearFieldError(inputEl) {
    const field = inputEl.closest('.field') || inputEl.parentNode;
    if (!field) return;
    field.classList.remove('field--error');
    field.querySelectorAll('.field-msg').forEach(m => m.remove());
  }

  /* ════════════ DEVICE MODAL ════════════ */
  let editingDeviceKey = null;

  /* Optional extra Build.* / Build$VERSION.* fields — [inputId, COPG.json key].
     Order/keys mirror EXTRA_BUILD_FIELDS in spoof_module.cpp. */
  const ADV_FIELDS = [
    ['dfBoard','BOARD'], ['dfHardware','HARDWARE'], ['dfId','ID'], ['dfDisplay','DISPLAY'],
    ['dfBootloader','BOOTLOADER'], ['dfTags','TAGS'], ['dfType','TYPE'],
    ['dfIncremental','INCREMENTAL'], ['dfSecPatch','SECURITY_PATCH'], ['dfCodename','CODENAME'],
    ['dfSocMan','SOC_MANUFACTURER'], ['dfSocModel','SOC_MODEL'], ['dfRadio','RADIO'],
  ];
  function advValues() {
    const o = {};
    ADV_FIELDS.forEach(([id, key]) => { o[key] = $m('#' + id).value; });
    return o;
  }
  function setAdvOpen(open) {
    const g = $m('#dfAdvGroup'), b = $m('#dfAdvBody'), t = $m('#dfAdvToggle');
    if (!g || !b) return;
    g.classList.toggle('is-open', !!open);
    b.hidden = !open;
    if (t) t.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  function wireAdvToggle() {
    const t = $m('#dfAdvToggle');
    if (!t) return;
    t.addEventListener('click', e => {
      if (e.target.closest('#dfAdvInfo')) return;   // ⓘ has its own handler
      setAdvOpen($m('#dfAdvBody').hidden);
    });
  }
  // Collapsible package-modal sections (Spoofing / Tweaks) — same accordion pattern
  // as the device modal's adv-group: header button toggles the body, caret rotates.
  function setGroupOpen(groupId, bodyId, open) {
    const g = $m('#' + groupId), b = $m('#' + bodyId);
    if (!g || !b) return;
    g.classList.toggle('is-open', !!open);
    b.hidden = !open;
    const btn = g.querySelector('.toggles__head--btn');
    if (btn) btn.setAttribute('aria-expanded', open ? 'true' : 'false');
  }
  function wireToggleGroups() {
    [['pfSpoofHead', 'pfSpoofGroup', 'pfSpoofBody'],
     ['pfTweakHead', 'pfTweakGroup', 'pfTweakBody']].forEach(([head, group, body]) => {
      const h = $m('#' + head);
      if (h) h.addEventListener('click', () => setGroupOpen(group, body, $m('#' + body).hidden));
    });
  }
  // Sections default collapsed; auto-expand one only if it already has an active
  // toggle (editing a package that uses it). Fresh add → both stay closed.
  function syncGroupsAutoOpen() {
    const on = ids => ids.some(id => { const e = $m('#' + id); return e && e.checked; });
    // tz + lang are value-pickers (dataset, not a checkbox) — count them as active too so the
    // Spoofing group auto-opens when only a Timezone/Language is set.
    const pickerOn = () => {
      const tz = $m('#pfTzPick'), lang = $m('#pfLangPick');
      return !!((tz && tz.dataset.tz) || (lang && lang.dataset.lang));
    };
    setGroupOpen('pfSpoofGroup', 'pfSpoofBody', on(SPOOF_CB) || pickerOn());
    // DPI is a value-input (not a checkbox) — count it as active so Tweaks auto-opens on edit.
    const dpiOn = () => { const d = $m('#pfDpi'); return !!(d && d.value); };
    setGroupOpen('pfTweakGroup', 'pfTweakBody', on(TWEAK_CB) || dpiOn());
  }
  function wireAdvInfo() {
    const w = $m('#dfAdvInfo');
    if (!w) return;
    const open = e => { if (e) { e.preventDefault(); e.stopPropagation(); }
      info({ title: I18N.t('info_adv_title'), message: I18N.t('info_adv_msg') }); };
    w.addEventListener('click', open);
    w.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') open(e); });
  }

  /* ─── Generators for the synthesizable advanced fields ─── */
  const _p2 = n => String(n).padStart(2, '0');
  function _randRecentDate() {                      // random instant within ~last 6 months
    const back = Math.floor(Math.random() * 180) * 86400000 + Math.floor(Math.random() * 86400000);
    return new Date(Date.now() - back);
  }
  function genSecPatch() {                          // YYYY-MM-05 (patch level, day is conventionally 01/05)
    const d = _randRecentDate();
    return `${d.getUTCFullYear()}-${_p2(d.getUTCMonth() + 1)}-05`;
  }
  function genIncremental() {                       // YYYYMMDD.HHMMSS — matches the build-number style in fingerprints
    const d = _randRecentDate();
    return `${d.getUTCFullYear()}${_p2(d.getUTCMonth() + 1)}${_p2(d.getUTCDate())}.${_p2(d.getUTCHours())}${_p2(d.getUTCMinutes())}${_p2(d.getUTCSeconds())}`;
  }
  function genRadio() {                              // Qualcomm MPSS baseband (the common Snapdragon format):
    // MPSS.HI.a.b.cN-BUILD-SOC_GEN_PACK-1 . Uses the profile's SOC Model (e.g. SM8650) when it looks
    // like an SMxxxx so the baseband is coherent with the chipset, else a random SMxxxx. Baseband
    // strings are chipset-specific — for an exact match, paste a real one from the target device.
    const soc  = ($m('#dfSocModel') && $m('#dfSocModel').value.trim()) || '';
    const chip = /^SM\w+$/i.test(soc) ? soc.toUpperCase() : ('SM' + (8350 + Math.floor(Math.random() * 400)));
    const a = 1 + Math.floor(Math.random() * 4), b = Math.floor(Math.random() * 3), c = 1 + Math.floor(Math.random() * 9);
    const build = _p2(Math.floor(Math.random() * 100)) + String(100 + Math.floor(Math.random() * 900));
    return `MPSS.HI.${a}.${b}.c${c}-${build}-${chip}_GEN_PACK-1`;
  }
  /* Generic Generate-button wiring (non-labelable span → never steals the row tap). */
  function wireGen(btnId, inputId, genFn) {
    const g = $m('#' + btnId), s = $m('#' + inputId);
    if (!g || !s) return;
    const gen = e => { if (e) { e.preventDefault(); e.stopPropagation(); } s.value = genFn(); flash(s); };
    g.addEventListener('click', gen);
    g.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') gen(e); });
  }

  function openDevice(deviceKey) {
    const form = $m('#deviceForm');
    clearErrors(form);
    editingDeviceKey = deviceKey || null;
    $m('#deviceModalTitle').textContent = I18N.t(deviceKey ? 'dev_edit_title' : 'dev_add_title');

    const identity = !!deviceKey && COPG.isThisDeviceKey(deviceKey);
    const nameEl = $m('#dfName');
    nameEl.readOnly = identity;                  // identity name is fixed ("This Device")
    if (deviceKey) {
      const d = COPG.config[deviceKey] || {};
      nameEl.value = identity ? I18N.t('dev_this_device') : (d.DEVICE || '');
      $m('#dfBrand').value = d.BRAND || '';
      $m('#dfModel').value = d.MODEL || '';
      $m('#dfManufacturer').value = d.MANUFACTURER || '';
      $m('#dfFingerprint').value = d.FINGERPRINT || '';
      $m('#dfAndroid').value = d.ANDROID_VERSION || '';
      $m('#dfSdk').value = d.SDK_INT || '';
      $m('#dfSerial').value = d.SERIAL || '';
      let hasAdv = !!d.SERIAL;                   // Serial lives in Advanced → expand if set
      ADV_FIELDS.forEach(([id, key]) => { const v = d[key] || ''; $m('#' + id).value = v; if (v) hasAdv = true; });
      setAdvOpen(hasAdv);                       // auto-expand if this profile uses any
    } else {
      form.reset();
      ADV_FIELDS.forEach(([id]) => { $m('#' + id).value = ''; });
      setAdvOpen(false);
    }
    openModal('deviceModal');
  }

  /* SDK is derived from + LOCKED to the Android version: typing 16 → 36,
     clearing/unknown Android → SDK clears too (prevents stale-SDK mistakes). */
  function wireAndroidSdk() {
    const a = $m('#dfAndroid'), s = $m('#dfSdk');
    if (!a || !s) return;
    // SDK auto-fills from a known Android version. An unknown/future version (not
    // in the map) or an empty field CLEARS SDK — so a stale value from a previous
    // android can't linger (e.g. 17→37 then 19→ must blank, not keep 37). SDK stays
    // editable: after the clear you can still type a future SDK by hand (sync only
    // fires on android input, so it won't wipe what you then type).
    const sync = () => {
      const v = a.value.trim();
      const sug = v ? COPG.sdkFromAndroid(v) : null;
      const next = sug != null ? String(sug) : '';
      if (next !== s.value) { s.value = next; if (next) flash(s); }
    };
    a.addEventListener('input', sync);
  }
  // Random plausible serial (uppercase alphanumeric) — typing 24 chars by hand is painful.
  function genSerial(n = 16) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let out = '';
    try {
      const buf = new Uint32Array(n);
      crypto.getRandomValues(buf);
      for (let i = 0; i < n; i++) out += chars[buf[i] % chars.length];
    } catch (_) {
      for (let i = 0; i < n; i++) out += chars[Math.floor(Math.random() * chars.length)];
    }
    return out;
  }
  function wireSerialGen() {
    const g = $m('#dfSerialGen'), s = $m('#dfSerial');
    if (!g || !s) return;
    const gen = e => { if (e) { e.preventDefault(); e.stopPropagation(); } s.value = genSerial(); flash(s); };
    g.addEventListener('click', gen);
    g.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') gen(e); });
  }
  // ANDROID_ID is exactly 16 lowercase hex chars (a 64-bit value). Used for the ↻ that
  // fills the per-app aid=<hex> literal field (the device seed field was removed).
  function genAndroidId() {
    const hex = '0123456789abcdef';
    let out = '';
    try {
      const buf = new Uint32Array(16);
      crypto.getRandomValues(buf);
      for (let i = 0; i < 16; i++) out += hex[buf[i] % 16];
    } catch (_) {
      for (let i = 0; i < 16; i++) out += hex[Math.floor(Math.random() * 16)];
    }
    return out;
  }
  // GAID is a random RFC-4122 v4 UUID (8-4-4-4-12 lowercase hex). Used for the ↻ that
  // fills the per-app gaid=<uuid> literal field.
  function genGaid() {
    const b = new Uint8Array(16);
    try { crypto.getRandomValues(b); }
    catch (_) { for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256); }
    b[6] = (b[6] & 0x0f) | 0x40;                 // version 4
    b[8] = (b[8] & 0x3f) | 0x80;                 // variant 10xx
    const h = [...b].map(x => x.toString(16).padStart(2, '0'));
    return `${h[0]}${h[1]}${h[2]}${h[3]}-${h[4]}${h[5]}-${h[6]}${h[7]}-${h[8]}${h[9]}-${h[10]}${h[11]}${h[12]}${h[13]}${h[14]}${h[15]}`;
  }
  // Widevine deviceUniqueId = 32 raw bytes. DRM-info apps DISPLAY it Base64-encoded (44 chars,
  // ends '='), so the WebUI field + ↻ generator are Base64 to match what the user sees in the app.
  // The drmid= TAG stays hex (native hex_to_bytes) — we convert at the save/load boundary below.
  function hexToB64(hex) {
    if (!hex || !/^[0-9a-fA-F]+$/.test(hex) || hex.length % 2) return '';
    let s = '';
    for (let i = 0; i < hex.length; i += 2) s += String.fromCharCode(parseInt(hex.substr(i, 2), 16));
    try { return btoa(s); } catch (_) { return ''; }
  }
  function b64ToHex(b64) {
    let s;
    try { s = atob((b64 || '').trim()); } catch (_) { return ''; }
    let h = '';
    for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i) & 0xff; h += (c < 16 ? '0' : '') + c.toString(16); }
    return h;
  }
  // Device Unique ID field FORMAT toggle. The drmid= TAG is always raw hex (native hex_to_bytes),
  // but the field can DISPLAY either Base64 (how DRM-info apps show deviceUniqueId — default) or the
  // raw hex, via the B64/HEX switch. drmIdHex tracks the current mode; conversions below normalize
  // to/from hex so the tag is format-agnostic.
  let drmIdHex = false;                                   // false = Base64 (app display), true = raw hex
  const drmIdHexToField = hex => drmIdHex ? (hex || '') : hexToB64(hex);   // hex → what the field shows
  function drmIdFieldToHex(v) {                           // what the field holds → canonical hex (for the tag)
    v = (v || '').trim();
    if (!v) return '';
    return drmIdHex ? ((/^[0-9a-fA-F]+$/.test(v) && v.length % 2 === 0) ? v.toLowerCase() : '') : b64ToHex(v);
  }
  function applyDrmIdFmt() {                              // reflect the current mode in the button + field
    const btn = $m('#pfDrmIdFmt'); if (btn) btn.textContent = drmIdHex ? 'HEX' : 'B64';
    const inp = $m('#pfDrmIdVal'); if (inp) inp.maxLength = drmIdHex ? 64 : 44;
    syncDrmVal();                                         // re-render the placeholder in the new format
  }
  function toggleDrmIdFmt() {                             // flip B64⇄HEX, converting the live value
    const inp = $m('#pfDrmIdVal'); if (!inp) return;
    const hex = drmIdFieldToHex(inp.value);               // interpret current value under the OLD mode → hex
    drmIdHex = !drmIdHex;
    inp.value = hex ? drmIdHexToField(hex) : '';          // re-render under the NEW mode
    applyDrmIdFmt();
  }
  // ↻ generate = 32 random bytes, shown in the CURRENT field format (Base64 like the app, or hex).
  function genDrmId() {
    const buf = new Uint8Array(32);
    try { crypto.getRandomValues(buf); } catch (_) { for (let i = 0; i < 32; i++) buf[i] = Math.floor(Math.random() * 256); }
    let hex = '';
    for (let i = 0; i < 32; i++) { const c = buf[i] & 0xff; hex += (c < 16 ? '0' : '') + c.toString(16); }
    return drmIdHexToField(hex);
  }
  function genDrmSys() {
    let n;
    try { const b = new Uint32Array(1); crypto.getRandomValues(b); n = b[0] % 90000 + 10000; }
    catch (_) { n = Math.floor(Math.random() * 90000) + 10000; }
    return String(n);
  }
  // IMEI = 14 random digits + Luhn check = 15, always Luhn-valid. Used for the ↻ that
  // fills the per-app imei=<15> literal field.
  function genImei() {
    let p14 = '';
    try {
      const b = new Uint8Array(14);
      crypto.getRandomValues(b);
      for (let i = 0; i < 14; i++) p14 += String(b[i] % 10);
    } catch (_) {
      for (let i = 0; i < 14; i++) p14 += String(Math.floor(Math.random() * 10));
    }
    let sum = 0, dbl = true;
    for (let i = 13; i >= 0; i--) { let d = p14.charCodeAt(i) - 48; if (dbl) { d *= 2; if (d > 9) d -= 9; } sum += d; dbl = !dbl; }
    return p14 + String((10 - (sum % 10)) % 10);
  }
  function wireSdkWarn() {
    const w = $m('#dfSdkWarn');
    if (!w) return;
    const open = e => { if (e) { e.preventDefault(); e.stopPropagation(); }
      info({ title: I18N.t('info_sdk_title'), message: I18N.t('info_sdk_msg') }); };
    w.addEventListener('click', open);
    w.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') open(e); });
  }
  function flash(el) {
    el.classList.add('field__input--suggested');
    setTimeout(() => el.classList.remove('field__input--suggested'), 2500);
  }

  $m('#deviceForm').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.currentTarget;
    clearErrors(form);
    const identity = COPG.isThisDeviceKey(editingDeviceKey);
    const fields = {
      name: $m('#dfName'), model: $m('#dfModel'),
      manufacturer: $m('#dfManufacturer'), fingerprint: $m('#dfFingerprint'),
    };
    // Identity profile is allowed to be fully empty (no-spoof) → skip required + dup checks.
    if (!identity) {
      let bad = false;
      for (const [, el] of Object.entries(fields)) {
        if (!el.value.trim()) { markError(el, I18N.t('msg_required')); bad = true; }
      }
      if (bad) return;
    }

    const name = fields.name.value.trim();
    const model = fields.model.value.trim();
    const dup = identity ? null : COPG.deviceNameExists(name, model, editingDeviceKey);
    if (dup && !editingDeviceKey) {
      if (dup.field === 'name')  markError(fields.name,  I18N.t('msg_dup_device'));
      if (dup.field === 'model') markError(fields.model, I18N.t('msg_dup_model'));
      return;
    }

    COPG.upsertDevice({
      name, brand: $m('#dfBrand').value, model,
      manufacturer: fields.manufacturer.value, fingerprint: fields.fingerprint.value,
      android: $m('#dfAndroid').value, sdk: $m('#dfSdk').value, serial: $m('#dfSerial').value,
      adv: advValues(),
    }, editingDeviceKey);

    closeAll();
    await w.LibRefresh(I18N.t(editingDeviceKey ? 'toast_device_saved' : 'toast_device_added'));
  });

  /* ─── Device share sheet: export (show+copy a code) / import (paste a code) ─── */
  let shareMode = 'export';   // 'export' | 'import'
  let shareKey  = null;       // device key being exported (for re-gen on toggle)

  function copyToClipboard(text) {
    try {
      if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(text); return true; }
    } catch (_) {}
    // WebView fallback: select the visible textarea + execCommand
    try { const ta = $m('#dsCode'); ta.focus(); ta.select(); return document.execCommand('copy'); }
    catch (_) { return false; }
  }

  // (re)build the export code from shareKey + the "include packages" checkbox
  function regenShareCode(copy) {
    const ta = $m('#dsCode');
    const code = COPG.exportDevice(shareKey, $m('#dsInclPkgs').checked);
    if (!code) { showToast(I18N.t('toast_dev_export_fail')); return false; }
    ta.value = code;
    if (copy) copyToClipboard(code);
    return true;
  }

  function openDeviceShare(mode, deviceKey) {
    shareMode = mode === 'import' ? 'import' : 'export';
    shareKey  = deviceKey || null;
    const ta = $m('#dsCode'), action = $m('#dsAction'), pkgRow = $m('#dsPkgRow');
    clearFieldError(ta);
    $m('#dsTitle').textContent = I18N.t(shareMode === 'import' ? 'dev_import_title' : 'dev_share_title');
    $m('#dsHint').textContent  = I18N.t(shareMode === 'import' ? 'dev_import_hint' : 'dev_export_hint');
    action.textContent = I18N.t(shareMode === 'import' ? 'act_import' : 'act_copy');
    if (shareMode === 'export') {
      // "include packages" row appears only when this device carries packages
      const n = COPG.devicePackageCount(deviceKey);
      pkgRow.hidden = n === 0;
      $m('#dsInclPkgs').checked = n > 0;                 // default: include when present
      $m('#dsPkgLabel').textContent = `${I18N.t('dev_incl_pkgs')} (${n})`;
      ta.readOnly = true;
      if (!regenShareCode(false)) return;                 // nothing shareable → toast, don't open
      openModal('deviceShareModal');
      copyToClipboard(ta.value);                          // auto-copy on open (footer re-copies)
    } else {
      pkgRow.hidden = true;
      ta.value = ''; ta.readOnly = false;
      openModal('deviceShareModal');
      setTimeout(() => ta.focus(), 120);
    }
  }
  // toggling "include packages" rebuilds + re-copies the code live
  $m('#dsInclPkgs').addEventListener('change', () => regenShareCode(true));

  $m('#dsAction').addEventListener('click', async () => {
    const ta = $m('#dsCode');
    if (shareMode === 'export') {
      showToast(I18N.t(copyToClipboard(ta.value) ? 'toast_dev_copied' : 'toast_dev_copy_fail'));
      return;
    }
    clearFieldError(ta);
    const res = COPG.importDevice(ta.value);
    if (res.needsConflict) {
      // a package may live on only one device — ask move-here vs keep-on-old
      const owners = [...new Set(res.conflicts.map(c => c.ownerName))].slice(0, 4).join(', ');
      confirm({
        title:    I18N.t('dev_conflict_title'),
        message:  I18N.t('dev_conflict_msg').replace('%n', res.conflictCount).replace('%d', owners),
        okLabel:  I18N.t('dev_conflict_move'),
        altLabel: I18N.t('dev_conflict_keep'),
        onOk:  () => finishImport(COPG.importDevice(ta.value, { conflictMode: 'move' })),
        onAlt: () => finishImport(COPG.importDevice(ta.value, { conflictMode: 'keep' })),
      });
      return;
    }
    await finishImport(res);
  });

  async function finishImport(res) {
    const ta = $m('#dsCode');
    if (!res.ok) {
      if (res.error === 'empty') { showToast(I18N.t('toast_dev_import_empty')); return; }
      markError(ta, I18N.t('msg_import_bad')); return;
    }
    closeAll();
    const parts = [];
    if (res.packageCount) parts.push(`+${res.packageCount}`);
    if (res.moved) parts.push(`${I18N.t('dev_moved')} ${res.moved}`);
    if (res.kept)  parts.push(`${I18N.t('dev_kept')} ${res.kept}`);
    const suffix = parts.length ? ` (${parts.join(', ')})` : '';
    await w.LibRefresh(`${res.name} — ${I18N.t('toast_dev_imported')}${suffix}`);
  }

  /* ════════════ PACKAGE MODAL ════════════ */
  let editingPkg = null;  // { clean, type, deviceKey } | null

  // The device field is now a picker button (opens DevicePicker). The chosen
  // device's package-array key (PACKAGES_X — what listPackages tags onto
  // pkg.deviceKey) is stashed in the button's dataset; the label shows its name.
  function setDeviceSelection(pkgKey) {
    const btn  = $m('#pfDevice');
    const text = $m('#pfDeviceText');
    const devs = COPG.listDevices();
    const dev  = pkgKey ? devs.find(d => d.pkgKey === pkgKey) : null;
    if (dev) {
      btn.dataset.deviceKey = dev.pkgKey;
      text.textContent = dev.name;
      text.classList.remove('is-placeholder');
      text.removeAttribute('data-i18n');          // a real value, not the placeholder
    } else {
      delete btn.dataset.deviceKey;
      text.textContent = I18N.t(devs.length ? 'pkg_pick_device' : 'pkg_no_devices');
      text.classList.add('is-placeholder');
      text.dataset.i18n = devs.length ? 'pkg_pick_device' : 'pkg_no_devices';
    }
    clearFieldError(btn);
    syncAidAvail();                              // AID toggle PRO lock
    syncSerialLock();                            // grey per-app serial if the new profile sets SERIAL
  }
  // kept name for the existing call sites (preselect on open/edit)
  function populateDeviceSelect(selectedKey) { setDeviceSelection(selectedKey); }

  // "Spoof Android ID" is a PRO feature (no profile seed — the id derives from the package).
  // Free tier → PRO lock (grey row + chip + lock, tap → upsell); licensed → enabled.
  function syncAidAvail() {
    const row = $m('#pfAidRow'), cb = $m('#pfAid'), tag = $m('#pfAidPro');
    if (!row || !cb) return;
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    row.classList.toggle('trow--locked', locked);
    cb.disabled = false;                          // always enabled (a free-tier tap fires the upsell)
    if (locked) cb.checked = false;
    row.classList.remove('trow--disabled');
  }
  // The AID literal/preview sub-row: shown only when Spoof Android ID is on. BLANK = derive the
  // id from the package (bare 'aid' tag); a typed/generated 16-hex value pins aid=<hex>. The
  // derived id shows as the PLACEHOLDER so the user sees what a blank field will produce.
  function syncAidVal() {
    const row = $m('#pfAidValRow'); if (!row) return;
    const on = $m('#pfAid').checked && !$m('#pfAidRow').classList.contains('trow--locked');
    row.style.display = on ? '' : 'none';
    if (on) {
      const pkg = COPG.clean(($m('#pfPackage').value || '').trim());
      const derived = (pkg && COPG.deriveAndroidId) ? COPG.deriveAndroidId(pkg) : '';
      $m('#pfAidVal').placeholder = derived || 'a1b2c3d4e5f60718';
    }
  }
  // Per-app serial (FREE) is mutually exclusive with the device profile's own SERIAL: if the chosen
  // profile already sets a serial, this row is greyed + hard-DISABLED (not a PRO upsell — the two set
  // the same field). The native `serial` tag would still override the profile if both were set; the
  // grey-out just keeps the user from configuring the serial in two places.
  function syncSerialLock() {
    const row = $m('#pfSerialRow'), cb = $m('#pfSerial'), hint = $m('#pfSerialHint');
    if (!row || !cb) return;
    const dk  = $m('#pfDevice') ? ($m('#pfDevice').dataset.deviceKey || '') : '';
    const dev = dk ? COPG.listDevices().find(d => d.pkgKey === dk) : null;
    const deviceHasSerial = !!(dev && dev.props && dev.props.SERIAL);
    row.classList.toggle('trow--locked', deviceHasSerial);
    cb.disabled = deviceHasSerial;                 // hard disable (mutual exclusion, not a license gate)
    if (deviceHasSerial) cb.checked = false;
    if (hint) hint.hidden = !deviceHasSerial;
    syncSerialVal();
  }
  // The serial literal/preview sub-row: shown only when Custom serial is on + not greyed. BLANK =
  // derive per-app from the package (bare 'serial' tag); a typed value pins serial=<value>.
  function syncSerialVal() {
    const row = $m('#pfSerialValRow'); if (!row) return;
    const on = $m('#pfSerial').checked && !$m('#pfSerialRow').classList.contains('trow--locked');
    row.style.display = on ? '' : 'none';
  }

  // Unified model: every package is a device package on a profile, so the profile
  // picker + both toggle groups are always shown. (with_cpu mount and block unmount
  // stay mutually exclusive — see wiring below.)
  const SPOOF_CB = ['pfWithCpu', 'pfBlock', 'pfCow', 'pfAid', 'pfSerial', 'pfGaid', 'pfAppSet', 'pfHideDev', 'pfGpu', 'pfMock', 'pfUptime', 'pfRr', 'pfDrm', 'pfImei', 'pfWebua', 'pfVpn', 'pfVpnAgg', 'pfSim'];
  const TWEAK_CB = ['pfDnd', 'pfDab', 'pfKso', 'pfNolog'];
  function setType() {
    $m('#pfDeviceField').style.display = '';
    $m('#pfToggles').style.display     = '';
    syncAidAvail();                             // re-evaluate the AID toggle's PRO lock
    // GPU spoof unsupported on x86_64-only → hide the toggle + clear it
    if (!gpuSupported()) { $m('#pfGpuRow').style.display = 'none'; $m('#pfGpu').checked = false; }
    if (!mockSupported()) { $m('#pfMockRow').style.display = 'none'; $m('#pfMock').checked = false; }
    if (!drmSupported())  { $m('#pfDrmRow').style.display  = 'none'; $m('#pfDrm').checked  = false; }
    if (!imeiSupported()) { $m('#pfImeiRow').style.display = 'none'; $m('#pfImei').checked = false; }
    if (!gaidSupported()) { $m('#pfGaidRow').style.display = 'none'; $m('#pfGaid').checked = false; }
    if (!gaidSupported()) { $m('#pfAppSetRow').style.display = 'none'; $m('#pfAppSet').checked = false; }   // same arm-only backend
    // Main "Hide VPN" (:vpns, system_server) works on ALL arches → never hidden. Only the nested
    // Aggressive (:vpnn, in-app ART/native) needs the arm-only backend → hidden on x86 (syncVpn).
    if (!vpnSupported()) { $m('#pfVpnAgg').checked = false; }
    if (!rrSupported())  { $m('#pfRrRow').style.display  = 'none'; $m('#pfRr').checked  = false; }
    syncCpuPick();                              // CPU model row visibility (with_cpu)
    syncGpuPick();                              // GPU model row visibility (gpu)
    syncRrVal();                                // Hz input row visibility (rr)
    syncVpn();                                  // Aggressive sub-row visibility
  }
  function currentType() { return 'device'; }   // retained for call sites; always device now

  // Device field → open the searchable/sortable device picker sheet.
  $m('#pfDevice').addEventListener('click', () => {
    if (!w.DevicePicker) return;
    const current = $m('#pfDevice').dataset.deviceKey || null;
    DevicePicker.open(current, sel => setDeviceSelection(sel.pkgKey));
  });
  // CPU spoof is opt-in (v4.7.3): "With CPU Spoofing" mounts the fake cpuinfo,
  // "Block CPU" unmounts it (forces real cpuinfo even if a global mount leaked).
  // They're opposite actions → mutually exclusive: turning one on clears the other.
  $m('#pfWithCpu').addEventListener('change', () => { if ($m('#pfWithCpu').checked) $m('#pfBlock').checked = false; syncCpuPick(); });
  $m('#pfBlock').addEventListener('change',   () => { if ($m('#pfBlock').checked)   $m('#pfWithCpu').checked = false; syncCpuPick(); });

  // CPU model sub-row (revealed only when "With CPU Spoofing" is on, device type).
  // Selected key lives on #pfCpuModel.dataset.cpuKey; '' = legacy default (Snapdragon).
  function setCpuSelection(key) {
    const btn = $m('#pfCpuModel'); if (!btn) return;
    btn.dataset.cpuKey = key || '';
    $m('#pfCpuModelText').textContent = (key && COPG.cpuModelName(key)) || I18N.t('pkg_cpu_default');
  }
  function syncCpuPick() {
    const row = $m('#pfCpuRow'); if (!row) return;
    row.style.display = $m('#pfWithCpu').checked ? '' : 'none';   // CPU model row only when CPU spoof on
  }
  $m('#pfCpuModel').addEventListener('click', () => {
    if (!w.CpuPicker) return;
    CpuPicker.open($m('#pfCpuModel').dataset.cpuKey || '', sel => setCpuSelection(sel.key));
  });
  // Timezone (tz=<IANA zone>) — FREE, stealth. Selected zone lives on #pfTzPick.dataset.tz
  // ('' = off/real). Opens the TzPicker sheet (searchable built-ins + add-custom), like CPU/GPU.
  function setTzSelection(zone) {
    const btn = $m('#pfTzPick'); if (!btn) return;
    btn.dataset.tz = zone || '';
    $m('#pfTzText').textContent = (zone && COPG.tzName ? COPG.tzName(zone) : zone) || I18N.t('pkg_tz_off');
  }
  $m('#pfTzPick').addEventListener('click', () => {
    if (!w.TzPicker) return;
    TzPicker.open($m('#pfTzPick').dataset.tz || '', sel => setTzSelection(sel.key));
  });
  // Language (lang=<BCP-47>) — FREE, stealth, applied system-side. Selected locale lives on
  // #pfLangPick.dataset.lang ('' = off/real). Opens the LangPicker sheet, like tz.
  function setLangSelection(loc) {
    const btn = $m('#pfLangPick'); if (!btn) return;
    btn.dataset.lang = loc || '';
    $m('#pfLangText').textContent = (loc && COPG.langName ? COPG.langName(loc) : loc) || I18N.t('pkg_lang_off');
  }
  $m('#pfLangPick').addEventListener('click', () => {
    if (!w.LangPicker) return;
    LangPicker.open($m('#pfLangPick').dataset.lang || '', sel => setLangSelection(sel.key));
  });
  // ↻ generate a fresh random 16-hex ANDROID_ID into the literal field.
  $m('#pfAidGen').addEventListener('click', () => { $m('#pfAidVal').value = genAndroidId(); });
  // Per-app serial (FREE): toggle reveals the literal sub-row; ↻ fills a random serial-shaped value.
  $m('#pfSerial').addEventListener('change', syncSerialVal);
  $m('#pfSerialGen').addEventListener('click', () => { $m('#pfSerialVal').value = genSerial(); });

  // GPU spoof (reference): RESIDENT inline hooks = detectable, so enabling it is
  // gated behind an explicit "use at own risk" confirm. We require acceptance before
  // the toggle flips on (uncheck-then-confirm), so dismissing leaves it OFF — no
  // onCancel needed. Selected key on #pfGpuModel.dataset.gpuKey; default adreno830.
  function setGpuSelection(key) {
    const btn = $m('#pfGpuModel'); if (!btn) return;
    btn.dataset.gpuKey = key || '';
    $m('#pfGpuModelText').textContent = (key && COPG.gpuModelName(key)) || I18N.t('pkg_gpu_default');
  }
  function syncGpuPick() {
    const row = $m('#pfGpuModelRow'); if (!row) return;
    row.style.display = $m('#pfGpu').checked ? '' : 'none';
  }
  // The nested "Aggressive (in-app)" sub-row shows when the main Hide VPN is on (or the aggressive
  // toggle itself is already on — preserve a legacy :vpn/:vpnn that had no :vpns). arm-only backend.
  function syncVpn() {
    const row = $m('#pfVpnAggRow'); if (!row) return;
    const show = (typeof vpnSupported !== 'function' || vpnSupported()) &&
                 ($m('#pfVpn').checked || $m('#pfVpnAgg').checked);
    row.style.display = show ? '' : 'none';
  }
  // GPU spoof AND per-app Android ID are PRO-only features. If a licensing layer is
  // present and the license isn't VALID/GRACE, they stay locked (native gates them too;
  // this makes the lock visible in the UI instead of a tag that silently does nothing).
  // No licensing layer (window.License absent) → not gated.
  function proLicensed() {
    if (!w.License) return true;
    const s = (w._licState && w._licState.state) || 'FREE';
    return s === 'VALID' || s === 'GRACE';
  }
  // Free-tier upsell for a PRO-only control (used to gate the GPU / SIM profile pickers, which
  // otherwise let free users open, browse, add and edit PRO profiles even though native re-gates).
  function proUpsell(titleKey, msgKey) {
    confirm({
      title: I18N.t(titleKey),
      message: I18N.t(msgKey),
      okLabel: I18N.t('gpu_pro_ok'),
      onOk: () => { closeAll(); if (w.License) License.reveal(); },
    });
  }
  function syncGpuLock() {
    const tag = $m('#pfGpuPro'), row = $m('#pfGpuRow');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;              // show "PRO" chip only on free tier
    if (row) row.classList.toggle('trow--locked', locked);   // grey the row when free
  }
  // COW prop spoof is a PRO feature too (stealth, but gated). Same lock pattern as GPU/AID:
  // grey the row + PRO chip + lock on free tier (native gates it in pre too). Checkbox stays
  // enabled so a tap fires the upsell.
  function syncCowLock() {
    const tag = $m('#pfCowPro'), row = $m('#pfCowRow'), cb = $m('#pfCow');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    if (row) row.classList.toggle('trow--locked', locked);
    if (locked && cb) cb.checked = false;
  }
  // Mock-location hide is PRO too, AND resident/detectable like GPU → same lock pattern
  // (grey row + PRO chip on free tier; native re-gates in post). Checkbox stays enabled so
  // a free-tier tap fires the upsell path in the change handler below.
  function syncMockLock() {
    const tag = $m('#pfMockPro'), row = $m('#pfMockRow'), cb = $m('#pfMock');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    if (row) row.classList.toggle('trow--locked', locked);
    if (locked && cb) cb.checked = false;
  }
  // Uptime spoof: PRO + resident/detectable like Mock/GPU → same lock pattern.
  function syncUptimeLock() {
    const tag = $m('#pfUptimePro'), row = $m('#pfUptimeRow'), cb = $m('#pfUptime');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    if (row) row.classList.toggle('trow--locked', locked);
    if (locked && cb) { cb.checked = false; syncUptimeVal(); }
  }
  // Reveal the days input only when Fake Uptime is on.
  function syncUptimeVal() {
    const row = $m('#pfUptimeValRow'); if (!row) return;
    row.style.display = $m('#pfUptime').checked ? '' : 'none';
  }
  // Reveal the Hz input only when Spoof Refresh Rate is on.
  function syncRrVal() {
    const row = $m('#pfRrValRow'); if (!row) return;
    row.style.display = $m('#pfRr').checked ? '' : 'none';
  }
  // Refresh-rate hook is arm-only (rr_hook install() stubs on x86/x86_64). Same rule as gpu/vpn.
  function rrSupported() {
    const a = String((w.State && State.sysInfo && State.sysInfo.abi) || '').toLowerCase();
    if (!a || a === '—') return true;
    return /arm/.test(a);
  }
  // DRM (Widevine securityLevel) spoof is PRO + resident/detectable like GPU/mock → same
  // lock pattern (grey row + PRO chip on free tier; native re-gates in post).
  function syncDrmLock() {
    const tag = $m('#pfDrmPro'), row = $m('#pfDrmRow'), cb = $m('#pfDrm');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    if (row) row.classList.toggle('trow--locked', locked);
    if (locked && cb) cb.checked = false;
    syncDrmVal();
  }
  // WebView User-Agent spoof: PRO + resident/detectable → same lock pattern as DRM/Mock.
  function syncWebuaLock() {
    const tag = $m('#pfWebuaPro'), row = $m('#pfWebuaRow'), cb = $m('#pfWebua');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    if (row) row.classList.toggle('trow--locked', locked);
    if (locked && cb) { cb.checked = false; syncWebuaVal(); }
  }
  // Reveal the UA text field only when WebView User-Agent spoof is on + unlocked.
  function syncWebuaVal() {
    const row = $m('#pfWebuaValRow'); if (!row) return;
    row.style.display = ($m('#pfWebua').checked && !$m('#pfWebuaRow').classList.contains('trow--locked')) ? '' : 'none';
  }
  // UA profile picker selection — key on #pfWebuaPick.dataset.uaKey (same pattern as GPU model).
  function setWebuaSelection(key) {
    const btn = $m('#pfWebuaPick'); if (!btn) return;
    btn.dataset.uaKey = key || '';
    $m('#pfWebuaPickText').textContent = (key && COPG.uaProfileName(key)) || I18N.t('pkg_webua_off');
  }
  // Widevine security level — a segmented control (same pattern as the SIM Mode row) rather than
  // a native <select>, whose WebView dropdown is the one control that doesn't follow the app's
  // visual language. Three short values also read better laid out than hidden behind a menu.
  function drmLevel() { return $m('#pfDrmLevel').dataset.level || 'L1'; }
  function setDrmLevel(lvl) {
    const seg = $m('#pfDrmLevel'); if (!seg) return;
    lvl = (['L1', 'L2', 'L3'].indexOf(String(lvl || '').toUpperCase()) >= 0)
      ? String(lvl).toUpperCase() : 'L1';
    seg.dataset.level = lvl;
    seg.querySelectorAll('.seg__opt').forEach(b =>
      b.classList.toggle('active', b.dataset.level === lvl));
  }
  // The DRM literal/preview sub-rows (deviceUniqueId + systemId): shown only when DRM spoof
  // is on + unlocked. BLANK = derive per-app from the package; a typed/generated value pins
  // drmid=<hex> / drmsys=<int>. Derived values show as PLACEHOLDERS so the user sees what a
  // blank field produces (byte-identical to the native derive via COPG.deriveDrm*).
  function syncDrmVal() {
    const idRow = $m('#pfDrmIdRow'), sysRow = $m('#pfDrmSysRow'), lvlRow = $m('#pfDrmLevelRow');
    if (!idRow || !sysRow || !lvlRow) return;
    const on = $m('#pfDrm').checked && !$m('#pfDrmRow').classList.contains('trow--locked');
    lvlRow.style.display = on ? '' : 'none';
    idRow.style.display = on ? '' : 'none';
    sysRow.style.display = on ? '' : 'none';
    if (on) {
      const pkg = COPG.clean(($m('#pfPackage').value || '').trim());
      $m('#pfDrmIdVal').placeholder  = (pkg && COPG.deriveDrmDeviceId) ? drmIdHexToField(COPG.deriveDrmDeviceId(pkg)) : 'auto (per-app)';
      $m('#pfDrmSysVal').placeholder = (pkg && COPG.deriveDrmSystemId) ? COPG.deriveDrmSystemId(pkg) : 'auto (per-app)';
    }
  }
  // IMEI spoof is PRO + resident/detectable → same lock pattern as GPU/mock/drm.
  function syncImeiLock() {
    const tag = $m('#pfImeiPro'), row = $m('#pfImeiRow'), cb = $m('#pfImei');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    if (row) row.classList.toggle('trow--locked', locked);
    if (locked && cb) cb.checked = false;
    syncImeiVal();
  }
  // IMEI backend is arm-only (LSPlant). Hide the toggle only when the ABI is KNOWN + no arm.
  function imeiSupported() {
    const a = String((w.State && State.sysInfo && State.sysInfo.abi) || '').toLowerCase();
    if (!a || a === '—') return true;
    return /arm/.test(a);
  }
  // The IMEI literal/preview sub-row: shown only when IMEI spoof is on + unlocked. BLANK =
  // derive per-app; a typed/generated 15-digit value pins imei=<15>. The derived IMEI shows
  // as the placeholder (byte-identical to the native derive via COPG.deriveImei).
  function syncImeiVal() {
    const row = $m('#pfImeiValRow'), row2 = $m('#pfImei2ValRow'); if (!row) return;
    const on = $m('#pfImei').checked && !$m('#pfImeiRow').classList.contains('trow--locked');
    row.style.display  = on ? '' : 'none';
    if (row2) row2.style.display = on ? '' : 'none';
    if (on) {
      const pkg = COPG.clean(($m('#pfPackage').value || '').trim());
      $m('#pfImeiVal').placeholder  = (pkg && COPG.deriveImei) ? COPG.deriveImei(pkg, 0) : 'auto (per-app)';
      $m('#pfImei2Val').placeholder = (pkg && COPG.deriveImei) ? COPG.deriveImei(pkg, 1) : 'auto (per-app)';
    }
  }
  // DRM backend is arm-only (LSPlant + And64/ele7enxxh; x86/x86_64 stub). Same rule as
  // mockSupported: hide the toggle only when the ABI is KNOWN and has no arm.
  function drmSupported() {
    const a = String((w.State && State.sysInfo && State.sysInfo.abi) || '').toLowerCase();
    if (!a || a === '—') return true;
    return /arm/.test(a);
  }
  // GPU spoof backend is arm-only (And64 arm64 + ele7enxxh arm32; x86/x86_64 = no-op
  // stub). Hide the whole GPU toggle on an x86_64-only device. Only hide when we KNOW
  // the ABI and it has no arm — unknown/preview ('—') keeps it visible.
  function gpuSupported() {
    const a = String((w.State && State.sysInfo && State.sysInfo.abi) || '').toLowerCase();
    if (!a || a === '—') return true;
    return /arm/.test(a);                       // arm64-v8a / armeabi-v7a / armeabi
  }
  // Mock-location hide backend is arm-only (LSPlant + And64 on arm64, ele7enxxh on arm32;
  // x86/x86_64 = no inline backend → native stubs). Same rule as gpuSupported: hide the
  // toggle only when we KNOW the ABI and it has no arm. Unknown/preview ('—') keeps it visible.
  function mockSupported() {
    const a = String((w.State && State.sysInfo && State.sysInfo.abi) || '').toLowerCase();
    if (!a || a === '—') return true;
    return /arm/.test(a);                        // arm64-v8a / armeabi-v7a
  }
  // VPN hide backend is arm-only (in-app LSPlant ART layer + native getifaddrs inline on
  // arm64/arm32; x86/x86_64 = vpn_hook install() stub → returns false). Same rule as
  // gpu/mockSupported: hide only when the ABI is KNOWN and has no arm; '—'/preview keeps it.
  function vpnSupported() {
    const a = String((w.State && State.sysInfo && State.sysInfo.abi) || '').toLowerCase();
    if (!a || a === '—') return true;
    return /arm/.test(a);                        // arm64-v8a / armeabi-v7a
  }
  $m('#pfGpu').addEventListener('change', () => {
    if ($m('#pfGpu').checked) {
      $m('#pfGpu').checked = false;                       // require explicit risk acceptance
      if (!proLicensed()) {                               // PRO-only → block on free tier
        confirm({
          title: I18N.t('gpu_pro_title'),
          message: I18N.t('gpu_pro_msg'),
          okLabel: I18N.t('gpu_pro_ok'),
          onOk: () => { closeAll(); if (w.License) License.reveal(); },
        });
        return;
      }
      riskConfirm('gpu', {
        title: I18N.t('gpu_risk_title'),
        message: I18N.t('gpu_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,                            // 5s cooldown on OK → forces a read
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => {
          $m('#pfGpu').checked = true;
          if (!$m('#pfGpuModel').dataset.gpuKey) setGpuSelection('adreno830');
          syncGpuPick();
        },
      });
    } else {
      syncGpuPick();
    }
  });
  // Refresh-rate spoof: RESIDENT v7878 hook = detectable → red-warn gate like GPU, but FREE
  // (no PRO lock). Uncheck-then-confirm so dismissing leaves it OFF. Number input (Hz).
  $m('#pfRr').addEventListener('change', () => {
    if ($m('#pfRr').checked) {
      $m('#pfRr').checked = false;                       // require explicit risk acceptance
      riskConfirm('rr', {
        title: I18N.t('rr_risk_title'),
        message: I18N.t('rr_risk_msg'),
        okLabel: I18N.t('rr_risk_ok'),
        danger: true,
        countdown: 5,
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => {
          $m('#pfRr').checked = true;
          if (!$m('#pfRrHz').value) $m('#pfRrHz').value = 120;
          syncRrVal();
        },
      });
    } else {
      syncRrVal();
    }
  });
  // Mock-location hide: RESIDENT LSPlant hook = detectable, so — like GPU — enabling it is
  // gated behind an explicit "use at own risk" confirm (uncheck-then-confirm, so dismissing
  // leaves it OFF). PRO-only: free tier gets the upsell instead. No model sub-row (boolean).
  $m('#pfMock').addEventListener('change', () => {
    if ($m('#pfMock').checked) {
      $m('#pfMock').checked = false;                       // require explicit risk acceptance
      if (!proLicensed()) {                                // PRO-only → block on free tier
        confirm({
          title: I18N.t('mock_pro_title'),
          message: I18N.t('mock_pro_msg'),
          okLabel: I18N.t('gpu_pro_ok'),
          onOk: () => { closeAll(); if (w.License) License.reveal(); },
        });
        return;
      }
      riskConfirm('mock', {
        title: I18N.t('mock_risk_title'),
        message: I18N.t('mock_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,                            // 5s cooldown on OK → forces a read
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => { $m('#pfMock').checked = true; },
      });
    }
  });
  // Fake Uptime: PRO + resident/detectable → same PRO-block + red risk gate as Mock.
  $m('#pfUptime').addEventListener('change', () => {
    if ($m('#pfUptime').checked) {
      $m('#pfUptime').checked = false;                     // require explicit risk acceptance
      if (!proLicensed()) {                                // PRO-only → block on free tier
        confirm({
          title: I18N.t('uptime_pro_title'),
          message: I18N.t('uptime_pro_msg'),
          okLabel: I18N.t('gpu_pro_ok'),
          onOk: () => { closeAll(); if (w.License) License.reveal(); },
        });
        return;
      }
      riskConfirm('uptime', {
        title: I18N.t('uptime_risk_title'),
        message: I18N.t('uptime_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => { $m('#pfUptime').checked = true; syncUptimeVal(); },
      });
    } else { syncUptimeVal(); }
  });
  $m('#pfDrmLevel').addEventListener('click', e => {
    const btn = e.target.closest('.seg__opt'); if (!btn) return;
    setDrmLevel(btn.dataset.level);
  });
  // ↻ generate a fresh random deviceUniqueId / systemId literal into the sub-row fields.
  $m('#pfDrmIdFmt').addEventListener('click', toggleDrmIdFmt);
  $m('#pfDrmIdGen').addEventListener('click', () => { $m('#pfDrmIdVal').value = genDrmId(); });
  $m('#pfDrmSysGen').addEventListener('click', () => { $m('#pfDrmSysVal').value = genDrmSys(); });
  // DRM (Widevine identity) spoof: RESIDENT LSPlant MediaDrm hook = detectable, so — like
  // GPU/mock — enabling it is gated behind an explicit "use at own risk" confirm (uncheck-
  // then-confirm). PRO-only: free tier gets the upsell. Sub-rows let the user pin/generate a
  // deviceUniqueId + systemId (blank = per-app derive).
  $m('#pfDrm').addEventListener('change', () => {
    if ($m('#pfDrm').checked) {
      $m('#pfDrm').checked = false;                        // require explicit risk acceptance
      if (!proLicensed()) {                                // PRO-only → block on free tier
        confirm({
          title: I18N.t('drm_pro_title'),
          message: I18N.t('drm_pro_msg'),
          okLabel: I18N.t('gpu_pro_ok'),
          onOk: () => { closeAll(); if (w.License) License.reveal(); },
        });
        return;
      }
      riskConfirm('drm', {
        title: I18N.t('drm_risk_title'),
        message: I18N.t('drm_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,                            // 5s cooldown on OK → forces a read
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => { $m('#pfDrm').checked = true; syncDrmVal(); },
      });
    } else {
      syncDrmVal();                              // toggled off → hide the sub-rows
    }
  });
  // ↻ generate a fresh Luhn-valid IMEI literal into each SIM slot's field.
  $m('#pfImeiGen').addEventListener('click', () => { $m('#pfImeiVal').value = genImei(); });
  $m('#pfImei2Gen').addEventListener('click', () => { $m('#pfImei2Val').value = genImei(); });
  // IMEI spoof: RESIDENT LSPlant TelephonyManager hook = detectable → PRO + risk-gate
  // (uncheck-then-confirm), same class as GPU/mock/drm.
  $m('#pfImei').addEventListener('change', () => {
    if ($m('#pfImei').checked) {
      $m('#pfImei').checked = false;                       // require explicit risk acceptance
      if (!proLicensed()) {                                // PRO-only → block on free tier
        confirm({
          title: I18N.t('imei_pro_title'),
          message: I18N.t('imei_pro_msg'),
          okLabel: I18N.t('gpu_pro_ok'),
          onOk: () => { closeAll(); if (w.License) License.reveal(); },
        });
        return;
      }
      riskConfirm('imei', {
        title: I18N.t('imei_risk_title'),
        message: I18N.t('imei_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => { $m('#pfImei').checked = true; syncImeiVal(); },
      });
    } else {
      syncImeiVal();                             // toggled off → hide the sub-row
    }
  });
  // WebView User-Agent spoof: RESIDENT v7878 WebSettings hook = detectable → PRO + risk-gate
  // (uncheck-then-confirm), same class as DRM/IMEI. Targets are web apps (no anti-cheat).
  $m('#pfWebua').addEventListener('change', () => {
    if ($m('#pfWebua').checked) {
      $m('#pfWebua').checked = false;                      // require explicit risk acceptance
      if (!proLicensed()) {                                // PRO-only → block on free tier
        confirm({
          title: I18N.t('webua_pro_title'),
          message: I18N.t('webua_pro_msg'),
          okLabel: I18N.t('gpu_pro_ok'),
          onOk: () => { closeAll(); if (w.License) License.reveal(); },
        });
        return;
      }
      riskConfirm('webua', {
        title: I18N.t('webua_risk_title'),
        message: I18N.t('webua_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => { $m('#pfWebua').checked = true; syncWebuaVal(); },
      });
    } else {
      syncWebuaVal();                            // toggled off → hide the UA field
    }
  });
  // ── GAID (Google Advertising ID) spoof — PRO + RESIDENT (LSPlant GMS bindService hook) ──
  // Same PRO lock + risk-gate class as Mock: greyed on free tier (tap → upsell), and enabling
  // pops the "use at own risk" red confirm (LSPlant stays mapped = detectable). No profile seed
  // — the literal/preview sub-row lets the user PIN an exact UUID (gaid=<uuid>) or leave it BLANK
  // to derive a distinct per-app id from the package (bare 'gaid' tag).
  // GAID backend is arm-only (LSPlant + And64 arm64 / ele7enxxh arm32; x86 = install() stub → false).
  function gaidSupported() {
    const a = String((w.State && State.sysInfo && State.sysInfo.abi) || '').toLowerCase();
    if (!a || a === '—') return true;
    return /arm/.test(a);
  }
  function syncGaidLock() {
    const tag = $m('#pfGaidPro'), row = $m('#pfGaidRow'), cb = $m('#pfGaid');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    if (row) row.classList.toggle('trow--locked', locked);
    if (locked && cb) cb.checked = false;
  }
  // The GAID literal/preview sub-row: shown only when Spoof Advertising ID is on. BLANK = derive
  // from the package (bare 'gaid' tag); a typed/generated UUID pins gaid=<uuid>. The derived id
  // shows as the PLACEHOLDER so the user sees what a blank field will produce.
  function syncGaidVal() {
    const row = $m('#pfGaidValRow'); if (!row) return;
    const on = $m('#pfGaid').checked && !$m('#pfGaidRow').classList.contains('trow--locked');
    row.style.display = on ? '' : 'none';
    if (on) {
      const pkg = COPG.clean(($m('#pfPackage').value || '').trim());
      const derived = (pkg && COPG.deriveGaid) ? COPG.deriveGaid(pkg) : '';
      $m('#pfGaidVal').placeholder = derived || '38400000-8cf0-11bd-b23e-10b96e40000d';
    }
  }
  // GAID ⓘ — preview the exact id the app reads (literal typed, else package-derived).
  function openGaidInfo(e) {
    e.preventDefault(); e.stopPropagation();
    const pkg  = COPG.clean(($m('#pfPackage').value || '').trim());
    const lit  = ($m('#pfGaidVal') ? $m('#pfGaidVal').value.trim().toLowerCase() : '');
    const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
    let msg;
    if (UUID.test(lit))  msg = I18N.t('info_pkggaid_msg') + ' ' + I18N.t('info_pkggaid_value') + ' ' + lit;
    else if (!pkg)       msg = I18N.t('info_pkggaid_msg') + ' ' + I18N.t('info_pkggaid_nopkg');
    else                 msg = I18N.t('info_pkggaid_msg') + ' ' + I18N.t('info_pkggaid_value') + ' ' + COPG.deriveGaid(pkg);
    info({ title: I18N.t('info_pkggaid_title'), message: msg });
  }
  { const el = $m('#pfGaidInfo');
    if (el) {
      el.addEventListener('click', openGaidInfo);
      el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') openGaidInfo(e); });
    } }
  // ↻ generate a fresh random UUID literal into the sub-row field.
  $m('#pfGaidGen').addEventListener('click', () => { $m('#pfGaidVal').value = genGaid(); });
  // GAID is PRO + RESIDENT → uncheck-then-confirm: free tier upsell, else red risk warn (5s).
  $m('#pfGaid').addEventListener('change', () => {
    if ($m('#pfGaid').checked) {
      $m('#pfGaid').checked = false;                       // require explicit risk acceptance
      if (!proLicensed()) { proUpsell('gaid_pro_title', 'gaid_pro_msg'); return; }  // PRO-only
      riskConfirm('gaid', {
        title: I18N.t('gaid_risk_title'),
        message: I18N.t('gaid_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,                            // 5s cooldown on OK → forces a read
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => { $m('#pfGaid').checked = true; syncGaidVal(); },
      });
    } else {
      syncGaidVal();
    }
  });

  // ── App Set ID (PRO, resident) — mirrors the GAID row exactly (same arm-only backend) ──
  function syncAppSetLock() {
    const tag = $m('#pfAppSetPro'), row = $m('#pfAppSetRow'), cb = $m('#pfAppSet');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    if (row) row.classList.toggle('trow--locked', locked);
    if (locked && cb) cb.checked = false;
  }
  function syncAppSetVal() {
    const row = $m('#pfAppSetValRow'); if (!row) return;
    const on = $m('#pfAppSet').checked && !$m('#pfAppSetRow').classList.contains('trow--locked');
    row.style.display = on ? '' : 'none';
    if (on) {
      const pkg = COPG.clean(($m('#pfPackage').value || '').trim());
      const derived = (pkg && COPG.deriveAppSetId) ? COPG.deriveAppSetId(pkg) : '';
      $m('#pfAppSetVal').placeholder = derived || 'auto (per-app)';
    }
  }
  function openAppSetInfo(e) {
    e.preventDefault(); e.stopPropagation();
    const pkg  = COPG.clean(($m('#pfPackage').value || '').trim());
    const lit  = ($m('#pfAppSetVal') ? $m('#pfAppSetVal').value.trim().toLowerCase() : '');
    const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/;
    let msg;
    if (UUID.test(lit))  msg = I18N.t('info_pkgappset_msg') + ' ' + I18N.t('info_pkgappset_value') + ' ' + lit;
    else if (!pkg)       msg = I18N.t('info_pkgappset_msg') + ' ' + I18N.t('info_pkgappset_nopkg');
    else                 msg = I18N.t('info_pkgappset_msg') + ' ' + I18N.t('info_pkgappset_value') + ' ' + COPG.deriveAppSetId(pkg);
    info({ title: I18N.t('info_pkgappset_title'), message: msg });
  }
  { const el = $m('#pfAppSetInfo');
    if (el) {
      el.addEventListener('click', openAppSetInfo);
      el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') openAppSetInfo(e); });
    } }
  $m('#pfAppSetGen').addEventListener('click', () => { $m('#pfAppSetVal').value = genGaid(); });   // App Set ID is a UUID too
  $m('#pfAppSet').addEventListener('change', () => {
    if ($m('#pfAppSet').checked) {
      $m('#pfAppSet').checked = false;                     // require explicit risk acceptance
      if (!proLicensed()) { proUpsell('appset_pro_title', 'appset_pro_msg'); return; }  // PRO-only
      riskConfirm('appset', {
        title: I18N.t('appset_risk_title'),
        message: I18N.t('appset_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => { $m('#pfAppSet').checked = true; syncAppSetVal(); },
      });
    } else {
      syncAppSetVal();
    }
  });
  // Hide VPN — base tag ':vpn' = the in-app LSPlant ART layer (NetworkCapabilities/
  // NetworkInfo/LinkProperties/ConnectivityManager/NetworkInterface). The old
  // system_server path was removed (it collided with LSPosed's LSPlant), so this is
  // now a RESIDENT in-app hook → detectable, and pairip's integrity scan CRASHES
  // banking/pairip apps under it. So the toggle is itself risk-gated (uncheck-then-confirm
  // red warn), same as GPU/mock. (The old "Native hooks" sub-toggle was removed — the base
  // hook is already resident/risky, so the extra layer was the same risk class.)
  // Main "Hide VPN" = the SAFE system_server :vpns hook (pairip-safe, no residency) → NO risk gate,
  // gray (!) info. Toggling it just reveals/hides the nested Aggressive sub.
  $m('#pfVpn').addEventListener('change', syncVpn);
  // Nested "Aggressive (in-app)" = the RESIDENT :vpnn hook (ART + native getifaddrs) → detectable,
  // crashes pairip/banking → red ⚠ risk-gated (uncheck-then-confirm), same as GPU/mock.
  $m('#pfVpnAgg').addEventListener('change', () => {
    if ($m('#pfVpnAgg').checked) {
      $m('#pfVpnAgg').checked = false;          // gate the ON transition behind the warn
      riskConfirm('vpn', {
        title: I18N.t('vpn_risk_title'),
        message: I18N.t('vpn_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => { $m('#pfVpnAgg').checked = true; },
      });
    }
  });
  $m('#pfGpuModel').addEventListener('click', () => {
    if (!w.GpuPicker) return;
    if (!proLicensed()) { proUpsell('gpu_pro_title', 'gpu_pro_msg'); return; }  // PRO-gate the picker
    GpuPicker.open($m('#pfGpuModel').dataset.gpuKey || '', sel => setGpuSelection(sel.key));
  });
  $m('#pfWebuaPick').addEventListener('click', () => {
    if (!w.UaPicker) return;
    if (!proLicensed()) { proUpsell('webua_pro_title', 'webua_pro_msg'); return; }
    UaPicker.open($m('#pfWebuaPick').dataset.uaKey || '', sel => setWebuaSelection(sel.key));
  });

  // ── SIM / Carrier spoof (PRO) ──────────────────────────────────────────
  // Two modes via the Safe|Aggressive segment: SAFE (sim=) = COW gsm.* props only
  // (stealth); AGGRESSIVE (simx=) = COW + resident ISub-proxy dex (detectable → red
  // risk-warning, never anti-cheat). Carrier picked from SIM/manifest.json.
  // Per-slot carrier pickers: SIM 1 (#pfSim1Model) + SIM 2 (#pfSim2Model). Each holds a
  // carrier key on its dataset ('' = that slot left real). Both same → written as the bare
  // sim=<key> shorthand; different → sim=A@0 + sim=B@1 (see setCarrierModel).
  function setSim(n, key) {
    const btn = $m('#pfSim' + n + 'Model'); if (!btn) return;
    btn.dataset.simKey = key || '';
    $m('#pfSim' + n + 'Text').textContent = (key && COPG.carrierModelName(key)) || I18N.t('pkg_sim_none');
  }
  function simMode() { return $m('#pfSimMode').dataset.mode || 'safe'; }
  function setSimMode(mode) {
    const seg = $m('#pfSimMode'); if (!seg) return;
    mode = (mode === 'aggressive') ? 'aggressive' : 'safe';
    seg.dataset.mode = mode;
    seg.querySelectorAll('.seg__opt').forEach(b =>
      b.classList.toggle('active', b.dataset.mode === mode));
  }
  function syncSimPick() {
    const on = $m('#pfSim').checked;
    $m('#pfSimModeRow').style.display = on ? '' : 'none';
    $m('#pfSim1Row').style.display    = on ? '' : 'none';
    $m('#pfSim2Row').style.display    = on ? '' : 'none';
  }
  // SIM/carrier is PRO (native gates it in pre/post). Same lock pattern as COW/AID/GPU.
  function syncSimLock() {
    const tag = $m('#pfSimPro'), row = $m('#pfSimRow'), cb = $m('#pfSim');
    const locked = !proLicensed();
    if (tag) tag.hidden = !locked;
    if (row) row.classList.toggle('trow--locked', locked);
    if (locked && cb) cb.checked = false;
  }
  $m('#pfSim').addEventListener('change', () => {
    if ($m('#pfSim').checked) {
      if (!proLicensed()) {                                // PRO-only → block + upsell
        $m('#pfSim').checked = false;
        confirm({
          title: I18N.t('sim_pro_title'),
          message: I18N.t('sim_pro_msg'),
          okLabel: I18N.t('gpu_pro_ok'),
          onOk: () => { closeAll(); if (w.License) License.reveal(); },
        });
        return;
      }
      setSimMode('safe');                                  // default to the stealth mode
      // default: fake both SIMs with the same carrier (bare shorthand → single-SIM safe)
      if (!$m('#pfSim1Model').dataset.simKey && !$m('#pfSim2Model').dataset.simKey) {
        setSim(1, 'tmobile_us'); setSim(2, 'tmobile_us');
      }
    }
    syncSimPick();
  });
  // Segment: Safe ↔ Aggressive. Switching TO aggressive pops the resident-risk warning
  // (same class as GPU); dismissing reverts to Safe.
  $m('#pfSimMode').addEventListener('click', e => {
    const btn = e.target.closest('.seg__opt'); if (!btn) return;
    const want = btn.dataset.mode;
    if (want === simMode()) return;
    if (want === 'aggressive') {
      riskConfirm('sim', {
        title: I18N.t('sim_risk_title'),
        message: I18N.t('sim_risk_msg'),
        okLabel: I18N.t('gpu_risk_ok'),
        danger: true,
        countdown: 5,
        link: { href: 'https://t.me/COPG_chat', label: I18N.t('gpu_risk_link') },
        onOk: () => setSimMode('aggressive'),
      });
    } else {
      setSimMode('safe');
    }
  });
  // Each SIM slot opens the carrier picker; picking "None (real)" clears that slot.
  $m('#pfSim1Model').addEventListener('click', () => {
    if (!w.CarrierPicker) return;
    if (!proLicensed()) { proUpsell('sim_pro_title', 'sim_pro_msg'); return; }  // PRO-gate the picker
    CarrierPicker.open($m('#pfSim1Model').dataset.simKey || '', sel => setSim(1, sel.key));
  });
  $m('#pfSim2Model').addEventListener('click', () => {
    if (!w.CarrierPicker) return;
    if (!proLicensed()) { proUpsell('sim_pro_title', 'sim_pro_msg'); return; }  // PRO-gate the picker
    CarrierPicker.open($m('#pfSim2Model').dataset.simKey || '', sel => setSim(2, sel.key));
  });

  // COW Prop Spoof is stealth (per-process copy-on-write prop edit, module
  // unloads before the app runs → zero memory residency), so no risk confirm —
  // it just toggles like any other spoof option.

  // ⓘ on the cpu/cow rows → plain-language explanation. preventDefault +
  // stopPropagation so tapping the icon doesn't toggle the row's checkbox.
  const INFO_KEYS = {
    withcpu:  ['info_withcpu_title',  'info_withcpu_msg'],
    block:    ['info_block_title',    'info_block_msg'],
    cow:      ['info_cow_title',      'info_cow_msg'],
    serial:   ['info_serial_title',   'info_serial_msg'],
    hidedev:  ['info_hidedev_title',  'info_hidedev_msg'],
    tz:       ['info_tz_title',       'info_tz_msg'],
    lang:     ['info_lang_title',     'info_lang_msg'],
    gpu:      ['info_gpu_title',      'info_gpu_msg'],
    mock:     ['info_mock_title',     'info_mock_msg'],
    uptime:   ['info_uptime_title',   'info_uptime_msg'],
    drm:      ['info_drm_title',      'info_drm_msg'],
    imei:     ['info_imei_title',     'info_imei_msg'],
    webua:    ['info_webua_title',    'info_webua_msg'],
    vpn:      ['info_vpn_title',      'info_vpn_msg'],
    vpns:     ['info_vpns_title',     'info_vpns_msg'],
    sim:      ['info_sim_title',      'info_sim_msg'],
    dnd:      ['info_dnd_title',      'info_dnd_msg'],
    dab:      ['info_dab_title',      'info_dab_msg'],
    kso:      ['info_kso_title',      'info_kso_msg'],
    nolog:    ['info_nolog_title',    'info_nolog_msg'],
    dpi:      ['info_dpi_title',      'info_dpi_msg'],
  };
  function openInfo(el, e) {
    e.preventDefault(); e.stopPropagation();    // don't let the row's label toggle the checkbox
    const k = INFO_KEYS[el.dataset.info]; if (!k) return;
    info({ title: I18N.t(k[0]), message: I18N.t(k[1]) });
  }
  $$('#pfToggles .trow__info').forEach(el => {
    el.addEventListener('click', e => openInfo(el, e));
    el.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') openInfo(el, e); });
  });

  // AID ⓘ is DYNAMIC: it previews the exact id this app will read (derived from the
  // package via COPG.deriveAndroidId — byte-identical to the native derive), or the
  // literal if one is typed. (Its plain .trow__info also got the generic no-op handler
  // above, which just stops the row toggle — harmless; we add the popup here.)
  function openAidInfo(e) {
    e.preventDefault(); e.stopPropagation();
    const pkg  = COPG.clean(($m('#pfPackage').value || '').trim());
    const lit  = ($m('#pfAidVal') ? $m('#pfAidVal').value.trim().toLowerCase() : '');
    let msg;
    if (/^[0-9a-f]{16}$/.test(lit))                  // exact id typed/generated → preview it as-is
      msg = I18N.t('info_pkgaid_msg') + ' ' + I18N.t('info_pkgaid_value') + ' ' + lit;
    else if (!pkg)  msg = I18N.t('info_pkgaid_msg') + ' ' + I18N.t('info_pkgaid_nopkg');
    else            msg = I18N.t('info_pkgaid_msg') + ' ' + I18N.t('info_pkgaid_value') + ' ' + COPG.deriveAndroidId(pkg);
    info({ title: I18N.t('info_pkgaid_title'), message: msg });
  }
  const aidInfoEl = $m('#pfAidInfo');
  if (aidInfoEl) {
    aidInfoEl.addEventListener('click', openAidInfo);
    aidInfoEl.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') openAidInfo(e); });
  }
  // Android ID is PRO — block the toggle on free tier and upsell (native re-gates too).
  $m('#pfAid').addEventListener('change', () => {
    if ($m('#pfAid').checked && !proLicensed()) {
      $m('#pfAid').checked = false;
      confirm({
        title: I18N.t('aid_pro_title'),
        message: I18N.t('aid_pro_msg'),
        okLabel: I18N.t('gpu_pro_ok'),
        onOk: () => { closeAll(); if (w.License) License.reveal(); },
      });
    }
    syncAidVal();   // reveal/hide the literal id sub-row
  });
  // COW prop spoof is PRO too — block on free tier and upsell (native re-gates in pre).
  $m('#pfCow').addEventListener('change', () => {
    if ($m('#pfCow').checked && !proLicensed()) {
      $m('#pfCow').checked = false;
      confirm({
        title: I18N.t('cow_pro_title'),
        message: I18N.t('cow_pro_msg'),
        okLabel: I18N.t('gpu_pro_ok'),
        onOk: () => { closeAll(); if (w.License) License.reveal(); },
      });
    }
  });

  function openPackage(pkg) {
    const form = $m('#packageForm');
    clearErrors(form);
    $m('#pfError').hidden = true;
    drmIdHex = false; applyDrmIdFmt();   // always open the Device Unique ID field in Base64 (app format)
    editingPkg = pkg ? { clean: pkg.clean, type: pkg.type, deviceKey: pkg.deviceKey } : null;
    $m('#packageModalTitle').textContent = I18N.t(pkg ? 'pkg_edit_title' : 'pkg_add_title');

    if (pkg) {
      $m('#pfPackage').value = pkg.clean;
      $m('#pfName').value = pkg.name && pkg.name !== pkg.clean ? pkg.name : (COPG.names[pkg.clean] || '');
      setType();
      populateDeviceSelect(pkg.deviceKey || COPG.THIS_DEVICE_PKEY);
      $m('#pfWithCpu').checked  = !!pkg.with_cpu;
      $m('#pfBlock').checked    = !!pkg.blocked;
      $m('#pfCow').checked      = !!pkg.cow;
      $m('#pfAid').checked      = !!pkg.aid;
      $m('#pfAidVal').value     = pkg.aidLiteral || '';   // literal aid=<hex>, else '' (derive/preview)
      $m('#pfSerial').checked   = !!pkg.serial;
      $m('#pfSerialVal').value  = pkg.serialLiteral || '';  // literal serial=<value>, else '' (derive from package)
      $m('#pfGaid').checked     = !!pkg.gaid;
      $m('#pfGaidVal').value    = pkg.gaidLiteral || '';  // literal gaid=<uuid>, else '' (derive/preview)
      $m('#pfAppSet').checked   = !!pkg.appset;
      $m('#pfAppSetVal').value  = pkg.appsetLiteral || ''; // literal appset=<uuid>, else '' (derive/preview)
      $m('#pfHideDev').checked  = !!pkg.hideDev;
      $m('#pfDnd').checked      = !!pkg.dnd;
      $m('#pfDab').checked      = !!pkg.dab;
      $m('#pfKso').checked      = !!pkg.kso;
      $m('#pfNolog').checked    = !!pkg.nolog;
      $m('#pfDpi').value        = pkg.dpi || '';           // dpi=<n> per-app screen density (controller tweak)
      $m('#pfGpu').checked      = !!pkg.gpu;
      $m('#pfMock').checked     = !!pkg.mock;
      $m('#pfUptime').checked   = !!pkg.uptime;
      $m('#pfUptimeD').value    = pkg.uptimeSeconds ? +(pkg.uptimeSeconds / 86400).toFixed(2) : '';  // seconds → days
      $m('#pfRr').checked       = !!pkg.rr;                // rr=<hz> resident refresh-rate hook (FREE)
      $m('#pfRrHz').value       = pkg.refreshHz || '';    // spoofed Hz, '' = off
      $m('#pfDrm').checked      = !!pkg.drm;
      setDrmLevel(pkg.drmLevel);                          // drm=<level>, default L1
      $m('#pfDrmIdVal').value   = drmIdHexToField(pkg.drmId);  // drmid=<hex> tag → shown in the current B64/HEX format; '' = derive/preview
      $m('#pfDrmSysVal').value  = pkg.drmSys || '';       // literal drmsys=<int>, else ''
      $m('#pfImei').checked     = !!pkg.imei;
      $m('#pfImeiVal').value    = pkg.imeiLiteral || '';  // literal imei=<15> slot 0, else '' (derive/preview)
      $m('#pfImei2Val').value   = pkg.imei2Literal || ''; // literal imei2=<15> slot 1, else ''
      $m('#pfWebua').checked    = !!pkg.webua;            // ua=<key> WebView User-Agent (PRO, resident)
      setWebuaSelection(pkg.webua || '');                 // ua=<key> UA profile, '' = off
      $m('#pfVpn').checked      = !!pkg.vpns;     // main "Hide VPN" = safe :vpns (system_server)
      $m('#pfVpnAgg').checked   = !!pkg.vpnAgg;   // nested aggressive = resident in-app :vpn/:vpnn
      $m('#pfSim').checked      = !!pkg.sim;
      setCpuSelection(pkg.cpuModel || '');
      setGpuSelection(pkg.gpuModel || '');
      setTzSelection(pkg.timezone || '');
      setLangSelection(pkg.locale || '');
      setSimMode(pkg.sim || 'safe');
      setSim(1, pkg.simS0 || '');
      setSim(2, pkg.simS1 || '');
    } else {
      form.reset();
      setType();
      populateDeviceSelect(COPG.THIS_DEVICE_PKEY);  // default new packages to "This Device" (no identity spoof)
      setCpuSelection('');
      setGpuSelection('');
      setTzSelection('');
      setLangSelection('');
      setDrmLevel('L1');   // the seg is not a form control, so form.reset() can't clear it
      setSimMode('safe');
      setSim(1, '');
      setSim(2, '');
    }
    if (COPG.getCpuModels) COPG.getCpuModels();  // warm the model-name cache for display
    if (COPG.getGpuModels) COPG.getGpuModels();  // warm GPU model-name cache too
    if (COPG.getTzZones) COPG.getTzZones();      // warm timezone list (custom zones) for display
    if (COPG.getLangLocales) COPG.getLangLocales();  // warm locale list (custom locales) for display
    if (COPG.getCarrierModels) COPG.getCarrierModels();  // warm carrier-name cache too
    if (w.License && License.refresh) License.refresh();   // refresh _licState for the PRO locks
    syncAidAvail();                             // final gate + AID PRO lock after checkboxes are set
    syncAidVal();                               // reveal the AID literal/preview sub-row if AID on
    syncSerialLock();                           // grey per-app serial if the profile sets SERIAL (+ reveal sub-row)
    syncCpuPick();
    syncGpuPick();
    syncVpn();                                 // reveal the Aggressive sub-row if VPN hide is already on
    syncGpuLock();                             // show/hide the PRO chip on the GPU row
    syncCowLock();                              // show/hide the PRO chip on the COW row
    syncMockLock();                             // show/hide the PRO chip on the Mock-hide row
    syncUptimeLock();                            // show/hide the PRO chip on the Fake-Uptime row
    syncUptimeVal();                             // reveal the days input if Fake Uptime is on
    syncDrmLock();                              // show/hide the PRO chip on the DRM-spoof row
    syncImeiLock();                             // show/hide the PRO chip on the IMEI row + sub-row
    syncWebuaLock();                            // show/hide the PRO chip on the WebView-UA row
    syncWebuaVal();                             // reveal the UA field if WebView-UA is on
    syncGaidLock();                             // show/hide the PRO chip on the GAID row
    syncGaidVal();                              // reveal the GAID literal/preview sub-row if GAID on
    syncAppSetLock();                           // show/hide the PRO chip on the App Set ID row
    syncAppSetVal();                            // reveal the App Set ID literal/preview sub-row if on
    syncSimLock();                              // show/hide the PRO chip on the SIM row
    syncSimPick();                              // reveal the mode+carrier sub-rows if SIM on
    syncGroupsAutoOpen();                        // expand a section only if it has an active toggle
    openModal('packageModal');
  }

  $m('#packageForm').addEventListener('submit', async e => {
    e.preventDefault();
    const form = e.currentTarget;
    clearErrors(form);
    const errBox = $m('#pfError'); errBox.hidden = true; errBox.textContent = '';

    const pkgEl = $m('#pfPackage');
    const raw = pkgEl.value.trim();
    const type = currentType();
    const devSel = $m('#pfDevice');
    const deviceKey = devSel.dataset.deviceKey || null;

    let bad = false;
    if (!raw) { markError(pkgEl, I18N.t('msg_required')); bad = true; }
    if (type === 'device' && !deviceKey) { markError(devSel, I18N.t('msg_pick_device')); bad = true; }
    if (bad) return;

    const cleanName = COPG.clean(raw);
    // cross-config duplicate (skip the package being edited)
    const where = COPG.locate(cleanName, editingPkg ? editingPkg.clean : null);
    if (where) {
      errBox.textContent = I18N.t('msg_dup_pkg') + ' ' + where;
      errBox.hidden = false;
      markError(pkgEl, I18N.t('msg_duplicate'));
      return;
    }

    COPG.upsertPackage({
      pkg: raw, name: $m('#pfName').value, type, deviceKey,
      with_cpu: $m('#pfWithCpu').checked,
      blocked: $m('#pfBlock').checked,
      cow: $m('#pfCow').checked,
      aid: $m('#pfAid').checked,
      aidLiteral: $m('#pfAidVal').value.trim(),           // aid=<hex> literal (blank = derive from seed)
      serial: $m('#pfSerial').checked && !$m('#pfSerial').disabled,   // per-app serial (FREE); disabled = profile owns it
      serialLiteral: $m('#pfSerialVal').value.trim(),     // serial=<value> literal (blank = derive from package)
      gaid: $m('#pfGaid').checked,
      gaidLiteral: $m('#pfGaidVal').value.trim(),         // gaid=<uuid> literal (blank = derive from seed; PRO, resident)
      appset: $m('#pfAppSet').checked,
      appsetLiteral: $m('#pfAppSetVal').value.trim(),     // appset=<uuid> literal (blank = derive from package; PRO, resident)
      hideDev: $m('#pfHideDev').checked,                  // hidedev tag → hide USB-debugging + dev-options (PRO, stealth)
      cpuModel: $m('#pfCpuModel').dataset.cpuKey || '',   // upsertPackage gates by type/with_cpu
      gpu: $m('#pfGpu').checked,
      gpuModel: $m('#pfGpuModel').dataset.gpuKey || '',   // upsertPackage gates by type (device)
      timezone: $m('#pfTzPick').dataset.tz || '',         // tz=<IANA zone> per-app timezone (FREE, stealth)
      locale: $m('#pfLangPick').dataset.lang || '',       // lang=<BCP-47> per-app locale (FREE, stealth, system-side)
      mock: $m('#pfMock').checked,                        // mock tag → resident Location.isMock hook (PRO)
      uptime: $m('#pfUptime').checked,                    // uptime=<sec> tag → resident clock_gettime/sysinfo hook (PRO)
      uptimeSeconds: Math.round((parseFloat($m('#pfUptimeD').value) || 0) * 86400),   // days → seconds
      rr: $m('#pfRr').checked,                            // rr=<hz> tag → resident DisplayManagerGlobal hook (FREE)
      refreshHz: parseFloat($m('#pfRrHz').value) || 0,    // spoofed display refresh rate (Hz)
      drm: $m('#pfDrm').checked,                          // drm tag → resident MediaDrm identity spoof (PRO)
      drmLevel: drmLevel(),                               // drm=<level> securityLevel L1/L2/L3 (L1 = bare :drm)
      drmId: drmIdFieldToHex($m('#pfDrmIdVal').value),    // field (B64 or hex per toggle) → canonical hex for the drmid= tag (blank/invalid = derive)
      drmSys: $m('#pfDrmSysVal').value.trim(),            // drmsys=<int> literal systemId (blank = derive)
      imei: $m('#pfImei').checked,                        // imei tag → resident TelephonyManager IMEI spoof (PRO)
      imeiLiteral: $m('#pfImeiVal').value.trim(),         // imei=<15> literal slot 0 (blank = derive per-app)
      imei2Literal: $m('#pfImei2Val').value.trim(),       // imei2=<15> literal slot 1 / dual-SIM (blank = derive)
      webua: $m('#pfWebua').checked ? ($m('#pfWebuaPick').dataset.uaKey || '') : '',  // ua=<key> WebView UA profile
      vpns: $m('#pfVpn').checked,                         // main Hide VPN → :vpns (system_server, pairip-safe, reboot to apply)
      vpnAgg: $m('#pfVpnAgg').checked,                    // aggressive → :vpnn (resident in-app ART + native; risk-gated)
      sim: $m('#pfSim').checked ? simMode() : '',          // '' | 'safe' | 'aggressive'
      simS0: $m('#pfSim1Model').dataset.simKey || '',      // SIM1 carrier key ('' = real)
      simS1: $m('#pfSim2Model').dataset.simKey || '',      // SIM2 carrier key ('' = real)
      dnd: $m('#pfDnd').checked,
      dab: $m('#pfDab').checked,
      kso: $m('#pfKso').checked,
      nolog: $m('#pfNolog').checked,
      dpi: $m('#pfDpi').value.trim(),                     // dpi=<n> per-app screen density (controller tweak)
    }, editingPkg);

    closeAll();
    await w.LibRefresh(I18N.t(editingPkg ? 'toast_package_saved' : 'toast_package_added'));
  });

  /* ════════════ CONFIRM DELETE ════════════ */
  let confirmCb = null;
  let confirmAltCb = null;       // optional third-button callback (e.g. import Keep vs Move)
  let confirmTimer = null;       // GPU-risk-style cooldown ticker on the OK button
  let confirmRiskKey = null;     // when set, the "don't show again" row is shown for this spoof

  // Per-spoof "don't show this risk warning again" acknowledgements, persisted like the other
  // copg-* prefs. Keyed by spoof (gpu/mock/drm/imei/gaid/appset/vpn/sim); once acked, that
  // spoof's red risk gate is skipped and its onOk runs straight away.
  const RISK_ACK_KEY = 'copg-risk-ack';
  function riskAckMap() { try { return JSON.parse(localStorage.getItem(RISK_ACK_KEY) || '{}') || {}; } catch (_) { return {}; } }
  function riskAcked(k) { return !!riskAckMap()[k]; }
  function setRiskAck(k) { try { const m = riskAckMap(); m[k] = 1; localStorage.setItem(RISK_ACK_KEY, JSON.stringify(m)); } catch (_) {} }
  // Risk gate that remembers acceptance: if the user already ticked "don't show again" for this
  // spoof, run the accept path immediately; otherwise show the normal confirm carrying riskKey so
  // the confirm sheet offers the checkbox.
  function riskConfirm(key, opts) {
    if (riskAcked(key)) { if (opts.onOk) opts.onOk(); return; }
    confirm(Object.assign({}, opts, { riskKey: key }));
  }
  /* Generic confirm sheet. `danger` paints the OK button red (delete);
     otherwise it's the primary accent (restore, and any future confirm). */
  function confirm(opts) {
    $m('#confirmTitle').textContent = opts.title || '';
    $m('#confirmMsg').textContent   = opts.message || '';
    // optional clickable link (e.g. the community group for the GOT warning) —
    // confirmMsg is textContent so it can't hold an anchor; this row carries it.
    const link = $m('#confirmLink');
    if (opts.link && opts.link.href) {
      link.href = opts.link.href;
      link.textContent = opts.link.label || opts.link.href;
      link.hidden = false;
      // On device, route through an Android VIEW intent so a t.me link opens in the
      // Telegram app instead of the in-WebView browser. (onclick = idempotent.)
      link.onclick = e => {
        if (COPG.hasBridge && COPG.hasBridge()) { e.preventDefault(); COPG.openExternal(link.href); }
      };
    } else { link.hidden = true; link.removeAttribute('href'); link.onclick = null; }
    // "Don't show again" row — only for risk gates (opts.riskKey), reset unticked each open.
    confirmRiskKey = opts.riskKey || null;
    const dsaRow = $m('#confirmDsaRow'), dsa = $m('#confirmDsa');
    if (dsaRow) { dsaRow.hidden = !confirmRiskKey; if (dsa) dsa.checked = false; }
    // info-only: a single acknowledge button, no Cancel (pure explanation sheet)
    $m('#confirmCancel').hidden = !!opts.infoOnly;
    const ok = $m('#confirmOk');
    ok.textContent = opts.okLabel || I18N.t('btn_save');
    ok.removeAttribute('data-i18n');           // set explicitly each open → no stale i18n revert
    ok.classList.toggle('btn--danger',  !!opts.danger);
    ok.classList.toggle('btn--primary', !opts.danger);
    confirmCb = opts.onOk || null;
    // optional third button (a second affordance beside OK/Cancel) — e.g. Move here
    // vs Keep on existing. Stacks the buttons vertically so three fit on a phone.
    const alt = $m('#confirmAlt');
    confirmAltCb = opts.onAlt || null;
    if (opts.altLabel) { alt.hidden = false; alt.textContent = opts.altLabel; }
    else { alt.hidden = true; alt.textContent = ''; }
    $m('#confirmBtns').classList.toggle('form-buttons--stack', !!opts.altLabel);
    // optional cooldown: disable OK and count down on its label so the user is forced
    // to sit with the warning before accepting (e.g. 5s on the GPU risk gate).
    clearConfirmCountdown();
    const secs = parseInt(opts.countdown, 10) || 0;
    if (secs > 0) {
      const base = ok.textContent;
      let n = secs;
      ok.disabled = true;
      ok.textContent = `${base} (${n})`;
      confirmTimer = setInterval(() => {
        n--;
        if (n <= 0) { clearConfirmCountdown(); ok.disabled = false; ok.textContent = base; }
        else ok.textContent = `${base} (${n})`;
      }, 1000);
    } else {
      ok.disabled = false;
    }
    openModal('confirmModal');
  }
  function clearConfirmCountdown() {
    if (confirmTimer) { clearInterval(confirmTimer); confirmTimer = null; }
  }
  function confirmDelete(title, message, cb) {
    confirm({ title, message, okLabel: I18N.t('btn_delete'), danger: true, onOk: cb });
  }
  /* Plain-language explanation sheet (reuses the confirm sheet, no Cancel). */
  function info(opts) {
    confirm({ title: opts.title, message: opts.message, okLabel: opts.okLabel || I18N.t('info_ok'), infoOnly: true });
  }
  $m('#confirmOk').addEventListener('click', async () => {
    if ($m('#confirmOk').disabled) return;       // cooldown still running
    clearConfirmCountdown();
    // Persist "don't show again" before running the callback, so this spoof's gate is skipped next time.
    if (confirmRiskKey && $m('#confirmDsa') && $m('#confirmDsa').checked) setRiskAck(confirmRiskKey);
    confirmRiskKey = null;
    const cb = confirmCb; confirmCb = null;
    closeModal('confirmModal');                 // close only the confirm, not the sheet underneath
    if (cb) await cb();                          // callback decides whether to close the rest
  });
  $m('#confirmAlt').addEventListener('click', async () => {
    clearConfirmCountdown();
    const cb = confirmAltCb; confirmAltCb = null; confirmCb = null;
    closeModal('confirmModal');
    if (cb) await cb();
  });
  // Cancel / dismiss → stop any running cooldown and re-enable OK for the next open.
  $m('#confirmCancel').addEventListener('click', () => { clearConfirmCountdown(); confirmRiskKey = null; $m('#confirmOk').disabled = false; });

  /* Pick from installed apps → fills package + display name */
  $m('#pfPickBtn').addEventListener('click', () => {
    if (!w.AppPicker || typeof w.AppPicker.open !== 'function') {
      // warn level → visible even with Debug Logs off, so a missing picker is obvious
      if (w.logEvent) logEvent('App picker unavailable (AppPicker=' + (typeof w.AppPicker) + ').', 'warn');
      showToast(I18N.t('toast_picker_unavailable')); return;
    }
    w.AppPicker.open(app => {
      $m('#pfPackage').value = app.pkg;
      if (app.label) $m('#pfName').value = app.label;
      $m('#pfPackage').closest('.field')?.classList.remove('field--error');
    });
  });

  /* Keep the focused field above the on-screen keyboard.
     The sheet is position:fixed; bottom:0, so by default the soft keyboard
     covers the lower fields (the WebView uses resizes-visual — layout viewport
     doesn't shrink). Track visualViewport: lift the sheet by the keyboard height
     (--kb-inset) and cap the form sheet to the visible area (--sheet-vh) so its
     header stays on-screen; then scrollIntoView can reach any field. */
  (function setupKeyboardInset() {
    const vv = window.visualViewport;
    if (!vv) return;
    const root = document.documentElement.style;
    const apply = () => {
      const kb = Math.max(0, Math.round(window.innerHeight - vv.height - vv.offsetTop));
      root.setProperty('--kb-inset', kb + 'px');
      if (kb > 80) root.setProperty('--sheet-vh', Math.round(vv.height - 12) + 'px');
      else root.removeProperty('--sheet-vh');
    };
    vv.addEventListener('resize', apply);
    vv.addEventListener('scroll', apply);
    apply();
  })();
  ['#deviceForm', '#packageForm'].forEach(sel => {
    const form = $m(sel);
    form?.addEventListener('focusin', e => {
      const t = e.target;
      if (t.matches('input, select, textarea')) {
        setTimeout(() => t.scrollIntoView({ block: 'center', behavior: 'smooth' }), 300);
      }
    });
  });
  // Picker add/edit panels (GPU/CPU) are injected by their own scripts AFTER this
  // file, so delegate on document: any input inside a .picker-import__panel gets
  // centered in its scroll area once the keyboard is up (mirrors the form sheets).
  document.addEventListener('focusin', e => {
    const t = e.target;
    if (t.matches && t.matches('.picker-import__panel input')) {
      setTimeout(() => t.scrollIntoView({ block: 'center', behavior: 'smooth' }), 300);
    }
  });

  /* init */
  wireAndroidSdk();
  wireSerialGen();
  wireSdkWarn();
  wireAdvToggle();
  wireToggleGroups();
  wireAdvInfo();
  wireGen('dfSecPatchGen',    'dfSecPatch',    genSecPatch);
  wireGen('dfIncrementalGen', 'dfIncremental', genIncremental);
  wireGen('dfRadioGen',       'dfRadio',       genRadio);

  w.Modals = { openDevice, openDeviceShare, openPackage, confirm, confirmDelete, info, closeAll };

})(window);
