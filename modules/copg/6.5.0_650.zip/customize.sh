# ================================================
# COPG Module Installation Script
# ================================================

INSTALL_SUCCESS=true

print_box_start() {
  ui_print "╔═════════════════════════════════╗"
  ui_print "                                 "
}

print_box_end() {
  ui_print "                                 "
  ui_print "╚═════════════════════════════════╝"
}

print_empty_line() {
  ui_print "                                 "
}

print_failure_and_exit() {
  local section="$1"
  print_empty_line
  ui_print " ✗ Installation Failed!          "
  if [ "$section" = "binary" ]; then
    print_empty_line
    print_empty_line
    print_empty_line
  fi
  print_box_end
  exit 1
}

grep_prop() {
  local PROP_FILE="$1"
  local PROP_NAME="$2"
  if [ -f "$PROP_FILE" ]; then
    grep "^${PROP_NAME}=" "$PROP_FILE" | cut -d'=' -f2- | head -n 1
  else
    echo ""
  fi
}

print_module_version() {
  print_box_start
  ui_print "      ✦ COPG Module Version ✦    "
  print_empty_line
  MODULE_PROP="$MODPATH/module.prop"
  if [ -f "$MODULE_PROP" ]; then
    MODULE_VERSION=$(grep_prop "$MODULE_PROP" "version")
    MODULE_VERSION_CODE=$(grep_prop "$MODULE_PROP" "versionCode")
    if [ -n "$MODULE_VERSION" ]; then
      ui_print " ✔ Module Version: $MODULE_VERSION "
      [ -n "$MODULE_VERSION_CODE" ] && ui_print " ✔ Version Code: $MODULE_VERSION_CODE "
    else
      ui_print " ✗ Could Not Read Module Version! "
    fi
  else
    ui_print " ✗ module.prop Not Found!        "
  fi
  print_box_end
  print_empty_line
}

check_zygisk() {
  ZYGISK_NEXT_PATH="/data/adb/modules/zygisksu"
  REZYGISK_PATH="/data/adb/modules/rezygisk"

  print_box_start
  ui_print "      ✦ Zygisk Detection ✦      "
  print_empty_line

  DETECTED_ROOT_SOLUTIONS=""
  ROOT_SOLUTION_COUNT=0

  if command -v apd >/dev/null; then
    DETECTED_ROOT_SOLUTIONS="$DETECTED_ROOT_SOLUTIONS APatch"
    ROOT_SOLUTION_COUNT=$((ROOT_SOLUTION_COUNT + 1))
    ROOT_SOLUTION="APatch"
    MANAGER_NAME="APatch Manager"
  fi

  if command -v ksud >/dev/null; then
    DETECTED_ROOT_SOLUTIONS="$DETECTED_ROOT_SOLUTIONS KernelSU"
    ROOT_SOLUTION_COUNT=$((ROOT_SOLUTION_COUNT + 1))
    if [ $ROOT_SOLUTION_COUNT -eq 1 ]; then
      ROOT_SOLUTION="KernelSU"
      MANAGER_NAME="KernelSU Manager"
    fi
  fi

  if command -v magisk >/dev/null; then
    DETECTED_ROOT_SOLUTIONS="$DETECTED_ROOT_SOLUTIONS Magisk"
    ROOT_SOLUTION_COUNT=$((ROOT_SOLUTION_COUNT + 1))
    if [ $ROOT_SOLUTION_COUNT -eq 1 ]; then
      ROOT_SOLUTION="Magisk"
      MANAGER_NAME="Magisk Manager"
    fi
  fi

  if [ $ROOT_SOLUTION_COUNT -gt 1 ]; then
    ui_print " ✗ Multiple Root Solutions Found!"
    ui_print " ➤ Detected:$DETECTED_ROOT_SOLUTIONS"
    ui_print " ➤ Only One Root Solution Allowed"
    print_failure_and_exit "zygisk"
  elif [ $ROOT_SOLUTION_COUNT -eq 0 ]; then
    ui_print " ✗ No Supported Root Solution!   "
    ui_print " ➤ Supported Solutions:          "
    ui_print " ➤ • Magisk v26.4+ (ReZygisk/Zygisk Next)"
    ui_print " ➤ • KernelSU v0.7.0+ (Zygisk Next)"
    ui_print " ➤ • APatch v1.0.7+ (Zygisk Next)"
    print_failure_and_exit "zygisk"
  else
    ui_print " ➔ Root Solution: $ROOT_SOLUTION "
  fi

  # ── Per-variant ACTIVE state ──────────────────────────────────────────────
  # A variant counts as active only if its module dir exists AND has no
  # `disable` marker. Each is checked independently, so a disabled variant can
  # never mask another that IS active (e.g. Zygisk Next disabled + ReZygisk on
  # → ReZygisk still wins). `disable` on one says nothing about the other.
  ZN_ACTIVE=false; RZ_ACTIVE=false
  [ -d "$ZYGISK_NEXT_PATH" ] && [ ! -f "$ZYGISK_NEXT_PATH/disable" ] && ZN_ACTIVE=true
  [ -d "$REZYGISK_PATH" ]    && [ ! -f "$REZYGISK_PATH/disable" ]    && RZ_ACTIVE=true
  ZYGISK_INSTALLED=false
  { [ -d "$ZYGISK_NEXT_PATH" ] || [ -d "$REZYGISK_PATH" ]; } && ZYGISK_INSTALLED=true

  # ── Magisk: built-in Zygisk must be OFF ───────────────────────────────────
  # ReZygisk / Zygisk Next replace Magisk's native Zygisk and only load when
  # the built-in one is disabled. If native Zygisk is ON they silently fail to
  # work even though the module dir is present — so block install and tell the
  # user to turn it off (instead of falsely reporting the variant "Active").
  if [ "$ROOT_SOLUTION" = "Magisk" ]; then
    ZYGISK_STATUS=$(magisk --sqlite "SELECT value FROM settings WHERE key='zygisk';" 2>/dev/null)
    if [ "$ZYGISK_STATUS" = "value=1" ]; then
      ui_print " ✗ Magisk: Built-in Zygisk Enabled!"
      ui_print " ➤ Disable Native Zygisk in Magisk Settings"
      ui_print " ➤ ReZygisk / Zygisk Next need it OFF"
      print_failure_and_exit "zygisk"
    fi
  fi

  # ── Require an ACTIVE standalone Zygisk variant ───────────────────────────
  if $RZ_ACTIVE; then
    ui_print " ✔ $ROOT_SOLUTION: ReZygisk Active    "
    print_box_end
    return
  elif $ZN_ACTIVE; then
    ui_print " ✔ $ROOT_SOLUTION: Zygisk Next Active  "
    print_box_end
    return
  elif $ZYGISK_INSTALLED; then
    ui_print " ✗ $ROOT_SOLUTION: Zygisk Module Disabled!"
    ui_print " ➤ Enable ReZygisk / Zygisk Next in $MANAGER_NAME"
    print_failure_and_exit "zygisk"
  else
    ui_print " ✗ $ROOT_SOLUTION: No Zygisk Module Found!"
    ui_print " ➤ Install ReZygisk or Zygisk Next       "
    print_failure_and_exit "zygisk"
  fi
}

cleanup_unused_architectures() {
  # COPG ships ARM only (arm64-v8a + armeabi-v7a) — no x86/x86_64 is built. Just drop
  # any stray x86 libs (harmless no-op when absent) and the leftover controller sources.
  ui_print " 🧹 ARM device — keeping ARM64 + ARM32"
  rm -f "$MODPATH/zygisk/x86_64.so" "$MODPATH/zygisk/x86.so" 2>/dev/null
  rm -f "$MODPATH/controller_arm64" "$MODPATH/controller_armv7" "$MODPATH/controller_x86_64" 2>/dev/null
}

print_module_version

if ! $BOOTMODE; then
  print_box_start
  ui_print "      ✦ Installation Error ✦     "
  print_empty_line
  ui_print " ✗ Recovery Mode Not Supported!  "
  ui_print " ➤ Install via Magisk/KSU/APatch "
  print_failure_and_exit "initial"
fi

if [ "$API" -lt 26 ]; then
  print_box_start
  ui_print "      ✦ Installation Error ✦     "
  print_empty_line
  ui_print " ✗ Android Version Too Old!      "
  ui_print " ➤ Requires Android 9.0+         "
  print_failure_and_exit "initial"
fi

if $INSTALL_SUCCESS; then
  check_zygisk || {
    INSTALL_SUCCESS=false
  }
fi

if $INSTALL_SUCCESS; then
  print_box_start
  ui_print "      ✦ Installing Controller ✦  "
  print_empty_line
  ui_print " ⚙ Detecting Device Architecture "

  ARM64_VARIANTS="arm64-v8a|armv8-a|arm64|aarch64"
  ARM32_VARIANTS="armeabi-v7a|armeabi|armv7-a|armv7l|armhf|arm"

  # ABI detection — robust across OEMs. Some Android 12+/16 devices leave the plain
  # ro.product.cpu.abilist EMPTY and only publish the partition-scoped variant
  # (ro.system/vendor.product.cpu.abilist), or just the singular ro.product.cpu.abi.
  # An empty list here used to match nothing → "No Compatible Controller" abort → the
  # module never installed → the user could never reach the license flow. Fall back
  # through every source, then default to arm64 (every KernelSU/Zygisk host is arm).
  ABI_LIST=$(getprop ro.product.cpu.abilist)
  [ -z "$ABI_LIST" ] && ABI_LIST=$(getprop ro.system.product.cpu.abilist)
  [ -z "$ABI_LIST" ] && ABI_LIST=$(getprop ro.vendor.product.cpu.abilist)
  [ -z "$ABI_LIST" ] && ABI_LIST=$(getprop ro.product.cpu.abilist64)
  [ -z "$ABI_LIST" ] && ABI_LIST=$(getprop ro.product.cpu.abi)
  [ -z "$ABI_LIST" ] && ABI_LIST="arm64-v8a"
  ui_print " 📜 Supported ABIs: $ABI_LIST"

  if $INSTALL_SUCCESS; then
    CONTROLLER_INSTALLED=false

    for ABI in $(echo "$ABI_LIST" | tr ',' ' '); do
      if echo "$ABI" | grep -qE "$ARM64_VARIANTS"; then
        if [ -f "$MODPATH/controller_arm64" ]; then
          mv "$MODPATH/controller_arm64" "$MODPATH/controller" || {
            ui_print " ✗ Failed to Rename ARM64 Controller!  "
            print_failure_and_exit "binary"
          }
          chmod 0755 "$MODPATH/controller" || {
            ui_print " ✗ Failed to Set Permissions (controller)!  "
            print_failure_and_exit "binary"
          }
          ui_print " ✔ Installed ARM64 Controller     "
          ui_print " ➤ ($ABI)                        "
          CONTROLLER_INSTALLED=true

          rm -f "$MODPATH/controller_armv7" 2>/dev/null
          break
        fi
      elif echo "$ABI" | grep -qE "$ARM32_VARIANTS"; then
        if [ -f "$MODPATH/controller_armv7" ]; then
          mv "$MODPATH/controller_armv7" "$MODPATH/controller" || {
            ui_print " ✗ Failed to Rename ARM32 Controller!  "
            print_failure_and_exit "binary"
          }
          chmod 0755 "$MODPATH/controller" || {
            ui_print " ✗ Failed to Set Permissions (controller)!  "
            print_failure_and_exit "binary"
          }
          ui_print " ✔ Installed ARM32 Controller     "
          ui_print " ➤ ($ABI)                        "
          CONTROLLER_INSTALLED=true

          rm -f "$MODPATH/controller_arm64" 2>/dev/null
          break
        fi
      fi
    done

    # Last-resort: the ABI list was unusable/unrecognised but the ARM64 controller
    # is present (every KernelSU/Zygisk host is ARM). Use it rather than aborting the
    # whole install — aborting is what blocked users with empty ro.product.cpu.abilist.
    if ! $CONTROLLER_INSTALLED && [ -f "$MODPATH/controller_arm64" ]; then
      mv "$MODPATH/controller_arm64" "$MODPATH/controller" && chmod 0755 "$MODPATH/controller" && {
        ui_print " ✔ Installed ARM64 Controller (fallback) "
        CONTROLLER_INSTALLED=true
        rm -f "$MODPATH/controller_armv7" 2>/dev/null
      }
    fi

    if ! $CONTROLLER_INSTALLED; then
      ui_print " ✗ No Compatible Controller Found! "
      ui_print " ➤ Supported Architectures:      "
      ui_print " ➤ • ARM64 (arm64-v8a)          "
      ui_print " ➤ • ARM32 (armeabi-v7a)        "
      print_failure_and_exit "binary"
    fi
  print_box_end
  print_empty_line
fi

  if $INSTALL_SUCCESS; then
    chmod 0755 "$MODPATH/service.sh" 2>/dev/null
    chmod 0644 "$MODPATH/COPG.json" "$MODPATH/list.json" "$MODPATH/global.json" 2>/dev/null

    # Select the copg_lic helper for this ABI. The CI ships copg_lic_<abi> (multi-ABI);
    # the local build.sh ships a single copg_lic. Mirror the controller: pick the match,
    # rename to copg_lic, drop the rest.
    if [ ! -f "$MODPATH/copg_lic" ]; then
      for ABI in $(echo "$ABI_LIST" | tr ',' ' '); do
        if echo "$ABI" | grep -qE "$ARM64_VARIANTS" && [ -f "$MODPATH/copg_lic_arm64" ]; then
          mv "$MODPATH/copg_lic_arm64" "$MODPATH/copg_lic"; break
        elif echo "$ABI" | grep -qE "$ARM32_VARIANTS" && [ -f "$MODPATH/copg_lic_armv7" ]; then
          mv "$MODPATH/copg_lic_armv7" "$MODPATH/copg_lic"; break
        fi
      done
    fi
    # Fallback: the abilist match above can MISS on some OEM builds (odd ABI strings, empty/short
    # abilist — e.g. a Samsung S25 Ultra hit "copg_lic: not found" → enrollment fails). Never leave
    # the device with no helper: if nothing matched, promote a shipped variant (prefer arm64, the
    # dominant real-device ABI), so licensing works instead of silently breaking.
    if [ ! -f "$MODPATH/copg_lic" ]; then
      for cand in copg_lic_arm64 copg_lic_armv7; do
        if [ -f "$MODPATH/$cand" ]; then
          ui_print "  ! copg_lic ABI match missed (abilist='$ABI_LIST') — using $cand"
          mv "$MODPATH/$cand" "$MODPATH/copg_lic"; break
        fi
      done
    fi
    rm -f "$MODPATH/copg_lic_arm64" "$MODPATH/copg_lic_armv7" "$MODPATH/copg_lic_x86_64" 2>/dev/null

    # Licensing helper (licensing branch): the WebUI execs it via ksu.exec, so it MUST be
    # executable. Magisk/KSU reset extracted files to 0644, so set 0755 explicitly (same as
    # the controller). wv.dex is read (by app_process / the module in the zygote domain) so
    # it just needs to be readable with a normal system_file context.
    [ -f "$MODPATH/copg_lic" ] && chmod 0755 "$MODPATH/copg_lic" 2>/dev/null
    [ -f "$MODPATH/wv.dex" ] && chmod 0644 "$MODPATH/wv.dex" 2>/dev/null

    for file in "$MODPATH/COPG.json" "$MODPATH/list.json" "$MODPATH/global.json" \
                "$MODPATH/service.sh" "$MODPATH/copg_lic" \
                "$MODPATH/wv.dex"; do
      if [ -f "$file" ]; then
        chcon u:object_r:system_file:s0 "$file" 2>/dev/null
      fi
    done

    # Final licensing-helper sanity: the WebUI execs copg_lic via ksu.exec, so a missing or
    # non-executable binary makes "Get device code" fail with "Could not read device fingerprint".
    # Flag it loudly at install so a broken PRO-licensing build never ships silently.
    if [ ! -f "$MODPATH/copg_lic" ]; then
      ui_print "  ! WARNING: copg_lic missing — PRO licensing / device enrollment will NOT work"
    else
      chmod 0755 "$MODPATH/copg_lic" 2>/dev/null
      chcon u:object_r:system_file:s0 "$MODPATH/copg_lic" 2>/dev/null
      [ -x "$MODPATH/copg_lic" ] || ui_print "  ! WARNING: copg_lic not executable — enrollment may fail"
    fi

    # Per-app CPU profiles (CPU/cpuinfo_<key>) bind-mount onto /proc/cpuinfo, so each
    # must read like a normal system file — 0444 + system_file context (wrong context =
    # unreadable mount / tamper signal). CPU/cpuinfo_sd8elite is also the default/fallback
    # profile (replaces the old root cpuinfo_spoof).
    if [ -d "$MODPATH/CPU" ]; then
      chmod 0644 "$MODPATH/CPU/manifest.json" 2>/dev/null
      for file in "$MODPATH/CPU/"cpuinfo_*; do
        [ -f "$file" ] && chmod 0444 "$file" 2>/dev/null
      done
      for file in "$MODPATH/CPU/"*; do
        [ -f "$file" ] && chcon u:object_r:system_file:s0 "$file" 2>/dev/null
      done
    fi

    # GPU profiles (GPU/manifest.json) — reference branch only. Just a readable JSON
    # (strings, not bind-mounted), so plain 0644 is enough; no special context needed.
    if [ -d "$MODPATH/GPU" ]; then
      chmod 0644 "$MODPATH/GPU/manifest.json" 2>/dev/null
    fi

    # SIM/carrier profiles (SIM/manifest.json) — same as GPU: a readable JSON of carrier
    # identity strings, read in the zygote domain. No bind mount → plain 0644 is enough.
    if [ -d "$MODPATH/SIM" ]; then
      chmod 0644 "$MODPATH/SIM/manifest.json" 2>/dev/null
    fi

    # Per-app proxy: the routing scripts must be executable. The hev helper ships ENCRYPTED
    # (bin/<abi>/hev_tproxy.enc, 0644, NOT executable) — copg_lic decrypts + exec's it from a memfd
    # at runtime with the license's K_GPU, so there is no plaintext binary to chmod.
    if [ -d "$MODPATH/proxy" ]; then
      chmod 0755 "$MODPATH/proxy/"*.sh 2>/dev/null
      for b in "$MODPATH/bin/"*/hev_tproxy.enc; do [ -f "$b" ] && chmod 0644 "$b" 2>/dev/null; done
    fi
    # Proxy profiles (PROXY/manifest.json) — a readable JSON list of the user's proxies (like SIM).
    if [ -d "$MODPATH/PROXY" ]; then
      chmod 0644 "$MODPATH/PROXY/manifest.json" 2>/dev/null
    fi

    # Clean up unused architecture files to reduce module size
    cleanup_unused_architectures
  fi


  if $INSTALL_SUCCESS; then
    print_empty_line
    print_box_start
    ui_print " ✅ Module Successfully Installed "
    print_box_end
  fi
fi

if ! $INSTALL_SUCCESS; then
  exit 1
fi
