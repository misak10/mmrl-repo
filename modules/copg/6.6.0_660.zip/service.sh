#!/system/bin/sh

until [ "$(getprop sys.boot_completed)" = "1" ]; do
    sleep 2
done

sleep 5
chmod 0644 data/adb/modules/COPG/COPG.json
chcon u:object_r:system_file:s0 /data/adb/modules/COPG/COPG.json

# Boot-crash guard reset for the system_server-resident hooks (FLAG_SECURE / VPN-hide / per-app
# locale). We only get here AFTER sys.boot_completed, i.e. system_server booted fine this cycle, so
# clear the crash counters. If one of those hooks had bootlooped, boot_completed never fires, this
# never runs, the counters keep climbing, and spoof_module stops arming that hook after 3 crash-boots
# → the device recovers on its own. (FLAG_SECURE also self-clears from its own hook; harmless dup.)
for g in copg_fs_bootguard copg_vpn_bootguard copg_lang_bootguard; do
    echo 0 > "/data/system/$g" 2>/dev/null
    chmod 0644 "/data/system/$g" 2>/dev/null
done

# licensing: the GPU license-verify verdict is memoized IN THE COMPANION PROCESS (in memory),
# not on disk — a disk cache in /data/adb is forgeable by root and would unlock GPU with no
# license. So there is nothing to warm here; the first gpu-app launch per boot pays the verify,
# the rest are instant. Remove any stale disk cache left by older builds.
rm -f /data/adb/modules/COPG/.lic_cache 2>/dev/null

# per-app proxy daemon (M2): watches proxy/active.conf and applies kernel TPROXY routing for
# proxy-tagged apps (routing each through its remote SOCKS5 via a local hev-socks5-tproxy helper).
# No-ops when active.conf is absent/empty. PRO — the WebUI only writes active.conf on a valid
# license. Detached so it outlives this script; teardown-first on each (re)start keeps it clean.
MODDIR=/data/adb/modules/COPG
if [ -x "$MODDIR/proxy/copg_proxy.sh" ]; then
    nohup sh "$MODDIR/proxy/copg_proxy.sh" watch >/dev/null 2>&1 &
fi

exec /data/adb/modules/COPG/controller >/dev/null 2>&1 &
