set_perm "$MODPATH"/7zzs 0 0 0755

unzip_hydro(){
    "$MODPATH"/7zzs x "$MODPATH"/"$1" -o"$TMPDIR" >/dev/null 2>&1
    mv "$TMPDIR"/* "$MODPATH"
}

unzip_hydro "module_oplus.7z"

set_perm "$MODPATH"/customize_new.sh 0 0 0755
source "$MODPATH"/customize_new.sh

#case "$lang" in
#zh)
#    ui_print "★2025新年快乐★"
#    ;;
#en)
#    ui_print "★Merry Christmas★"
#    ;;
#fr)
#    ui_print "★Bonne année 2025★"
#    ;;
#esac

rm -f "$MODPATH"/7zzs
rm -f "$MODPATH"/module_*.7z