#!/system/bin/sh

rm -f "/data/adb/service.d/Surfing_service.sh" 2>/dev/null
rm -rf /data/adb/box_bll 2>/dev/null
