import{d as t,bC as r}from"./index-BOYfLmCZ.js";const o=({children:e})=>t(r,{get children(){return[e," - MetaCubeXD"]}});export{o as D};
