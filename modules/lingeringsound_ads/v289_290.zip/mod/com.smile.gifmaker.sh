id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

find /data/media/[0-9]*/Android/data/com.smile.gifmaker /data/user/[0-9]*/com.smile.gifmaker -iname '*logcat*' -type d -o -iname 'BeiZi' -type d -o -iname 'applog' -type d -o -iname 'AMPS' -type d -o -iname 'crashsdk' -type d -type d -o -iname 'debuglog' -type d -type d -o -iname 'exception' -type d 2>/dev/null | while read Folder ;do
	test -d "${Folder}" && mkdir_file "${Folder}"
done