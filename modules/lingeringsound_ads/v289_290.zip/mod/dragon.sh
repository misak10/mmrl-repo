id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

export PATH="/system/bin:$MODPATH/busybox:$PATH"

source $MODPATH/mod/util_functions.sh

#番茄阅读插件
#-o -iname "plugins" -type d 

find /data/user/*/com.dragon.read /data/data/com.dragon.read /data/media/*/Android/data/com.dragon.read -iname ".geckox" -type d -o -iname "offlineX" -type d -o -iname "ALOG" -type d -o -iname "apm6*" -type d -o -iname "luckycat_gecko_root_dir" -type d -o -iname "webview_bytedance" -type d 2>/dev/null | while read adfile
do
	mkdir_file $adfile 2>/dev/null 
done


function deny_appops(){
local IFS=$'\n'
local package="$1"
local action="$2"
local list="
AUDIO_MEDIA_VOLUME
CHANGE_WIFI_STATE
FINE_LOCATION
LEGACY_STORAGE
MOCK_LOCATION
MONITOR_HIGH_POWER_LOCATION
MONITOR_LOCATION
READ_CALENDAR
READ_DEVICE_IDENTIFIERS
READ_PHONE_STATE
READ_EXTERNAL_STORAGE
SYSTEM_ALERT_WINDOW
TOAST_WINDOW
TAKE_AUDIO_FOCUS
VIBRATE
WAKE_LOCK
WRITE_CALENDAR
WRITE_EXTERNAL_STORAGE
"
for ops in $list 
do
	cmd appops set $package $ops $action
done
}

deny_appops "com.dragon.read" "ignore"
