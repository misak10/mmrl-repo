id="GGAT_10007"
Magisk_mod=$(grep -w -q 'lite_modules' /data/adb/magisk/util_functions.sh 2>/dev/null && echo "lite_modules" || echo "modules")
MODPATH="/data/adb/$Magisk_mod/$id"

Running_bin="${MODPATH}/mod/ads_monitor/ads_monitor"
Running_config="${MODPATH}/mod/ads_monitor/ads_monitor.prop"

test ! -f "${Running_bin}" && exit 0
killall -15 ads_monitor >/dev/null 2>&1
source $MODPATH/mod/util_functions.sh
test ! -f "${Running_config}" && Log_10007_dmesg "@10007 ${Running_config} is missing" "w"


function Running_main_log(){
local log_Boolean="${1}"
if [[ -z "${log_Boolean}" ]] || [[ "${log_Boolean}" = "true" ]];then
	${Running_bin} -f "${Running_config}" > "${Running_config%/*}/运行日志.prop" 2>&1 &
else
	${Running_bin} -f "${Running_config}" >/dev/null 2>&1 &
fi
}

(Running_main_log "false" &)

