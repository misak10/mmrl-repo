#调用系统通知notification
function notification_simulation(){
local title="${2}"
local text="${1}"
local author="${3}"
local timestamp=$(date +"%m-%d %H:%M")
local RANDOM_TAG="$(date +%s)_$RANDOM"
if test "$(pm list package | grep -w 'com.google.android.ext.services' )" != "" ;then
	cmd notification allow_assistant 'com.google.android.ext.services/android.ext.services.notification.Assistant'
fi
#local word_count="`echo "${text}" | wc -c`"
#test "${word_count}" -gt "375" && text='文字超出限制，请尽量控制在375个字符！'
test -z "${title}" && title='10007'
test -z "${text}" && text='您未给出任何信息'
test "`echo "${author}" | grep -E '^[0-9].*[0-9]$'`" = "" && author="2000"
text="$(echo "${text}" | sed "s/'/'\"'\"'/g")"; title="$(echo "${title}" | sed "s/'/'\"'\"'/g")"
local notification_msg="cmd notification post -t '${title}' -S messaging --conversation '${timestamp}' --message '${title}':'${text}' '${RANDOM_TAG}' '${title}' "
su "${author}" -c "${notification_msg}" >/dev/null 2>&1 \
 || su -lp "${author}" -c "${notification_msg}" >/dev/null 2>&1 \
 || su "shell" -c "${notification_msg}" >/dev/null 2>&1 \
 || su -c "${notification_msg}" >/dev/null 2>&1 \
 || eval "${notification_msg}" >/dev/null 2>&1
}

function Host_info(){
local MODPATH="${0%/*}"
local host_file=`find "${MODPATH}" -iname "hosts" -type f | head -n 1`
test "${host_file}" = "" && host_file="/system/etc/hosts"
local host_count="$(cat $host_file | sed '/^#/d;/^[[:space:]]*$/d' | wc -l)"
if test "$host_count" -ge "500000" ;then 
	local sate="网络存在一定延迟"
elif test "$host_count" -ge "50000" ;then 
	local sate="网络小幅度延迟"
elif test "$host_count" -lt "50000" ;then 
	local sate="网络基本无影响"
fi
echo "当前Host数量: ${host_count}，${sate}"
#echo "${host_count}"
}

function reset_modules(){
test -f "${0%/*}/module.prop" && return 0
cat << KEY > "${0%/*}/module.prop"
id=GGAT_10007
name=去广告
version=橴炫v184
versionCode=185
author=@coolapk 10007
description=host+chattr+pm+iptables去广告，host规则来自网络+本人手动抓取。$(Host_info)
updateJson=https://lingeringsound.github.io/10007/update.json
KEY
}

function refresh_information(){
local magisk_package
if magisk -v >/dev/null 2>&1 ;then
case "$(pm list package | grep -Eo 'io\.github\.huskydg\.magisk|io\.github\.vvb2060\.magisk|com\.topjohnwu\.magisk' )" in
com.topjohnwu.magisk)
	magisk_package="com.topjohnwu.magisk"
;;
io.github.vvb2060.magisk)
	magisk_package="io.github.vvb2060.magisk"
;;
io.github.huskydg.magisk)
	magisk_package="io.github.huskydg.magisk"
;;
*)
	magisk_package=`magisk --sqlite "SELECT value FROM strings where key='requester'" | cut -d'=' -f2`
;;
esac
local top_app="$(dumpsys window | sed '/mCurrentFocus/!d;s/.*[[:space:]]//g;s/\/.*//g')"
	if [[ "${top_app}" = "${magisk_package}" ]];then
		am start "intent:#Intent;action=;category=android.intent.category.LAUNCHER;launchFlags=0x10000000;component=${magisk_package}/com.topjohnwu.magisk.ui.MainActivity;end"
	fi
fi
}

function set_perm() {
  chown -R $2:$3 "${1}" >/dev/null 2>&1
  chmod -R $4 "${1}" >/dev/null 2>&1
  local CON=$5
  [ -z $CON ] && CON=u:object_r:system_file:s0
  chcon -R $CON "${1}" >/dev/null 2>&1
}

function mount_set_perm_for_hosts(){
local target_file="${1}"
test ! -f "${target_file}" && return
local system_host="/system/etc/hosts"
if test ! -f "${system_host}" ;then
for file in $(find /system/ /system_ext /vendor /product -iname 'hosts' -type f 2>/dev/null)
do
case "${file}" in
/system_ext* | /vendor* | /product*)
	system_host="/system"${file}""
	break
;;
/system*)
	system_host="${file}"
	break
;;
		esac
	done
fi
local perm_hosts="$(`find /data/adb/ -iname "busybox" -type f | sed '/modules/d' | head -n 1` stat -c '%U %G %a' ${system_host} 2>/dev/null )"
local selinux_context="$(`find /data/adb/ -iname "busybox" -type f | sed '/modules/d' | head -n 1` stat -Z ${system_host} 2>/dev/null | grep -i 'S_Context:' | sed 's/.*u:/u:/g' )"
test "${selinux_context}" = "" && selinux_context="u:object_r:system_file:s0"
set_perm "${target_file%/*}" ${perm_hosts} "${selinux_context}"
umount "${system_host}" >/dev/null 2>&1
mount --bind "${target_file}" "${system_host}" >/dev/null 2>&1
}

function filter_hosts() {
local filter_file="$1"
local target_host="$2"
[ ! -f "${filter_file}" -o ! -f "${target_host}" ] && return
local tmp_dir="/dev/tmp/Hosts.$$"
mkdir -p "${tmp_dir}"
[ ! -d "${tmp_dir}" ] && tmp_dir="${0%/*}/TMPDIR" && mkdir -p "${tmp_dir}"
local tmp_domains="${tmp_dir}/domains.$$"
local tmp_hosts="${tmp_dir}/${target_host##*/}.tmp"
sed -n '/^[#!]/d;/^[[:space:]]*$/d;p' "${filter_file}" > "${tmp_domains}"
grep -Fv -f "${tmp_domains}" "${target_host}" > "${tmp_hosts}" && cp -af "${tmp_hosts}" "${target_host}"
[ -d "${tmp_dir}" ] && rm -rf "${tmp_dir}"
}

function Zygisk_next_Re_hidden() {
export PATH="/data/adb/modules/zygisksu/bin:$PATH"
local state_file="/data/adb/zygisksu/denylist_enforce"
local policy_file="${state_file%/*}/denylist_policy"
local state_value=$(cat "${state_file}" 2>/dev/null)
local policy_value=$(cat "${policy_file}" 2>/dev/null)
[ "$(command -v zygiskd)" = "" ] && return

case "${policy_value}" in
 0) zygiskd denylist-policy default ;;
 1) zygiskd denylist-policy whitelist ;;
 *) zygiskd denylist-policy default ;;
esac

case "${state_value}" in
 1) zygiskd enforce-denylist enabled ;;
 2) zygiskd enforce-denylist just_umount ;;
 *) zygiskd enforce-denylist just_umount ;;
esac

if [ ! -f "${state_file}" ]; then
	zygiskd denylist-policy default
	echo "2" > "${state_file}"
	zygiskd enforce-denylist just_umount
fi

[ ! -f "${policy_file}" ] && zygiskd denylist-policy default
}


(
test ! -f "${0%/*}/backup.prop" && cp -rf "${0%/*}/module.prop" "${0%/*}/backup.prop"

flag_file="${0%/*}/xiaomi_backup"

if test ! -f "${flag_file}" ;then
	echo "[✔]已经放行a0.app.xiaomi.com和广告奖励，注意放行可能会泄露已安装应用给小米，风险自行承担。" 
	echo -e "                                  
       _ _               
  __ _| | | _____      __
 / _\` | | |/ _ \ \ /\ / /
| (_| | | | (_) \ V  V / 
 \__,_|_|_|\___/ \_/\_/  
                         
"
	#云备份
	test -f "${0%/*}/mod/a0.app.xiaomi.com.sh" && {
	source "${0%/*}/mod/a0.app.xiaomi.com.sh"
		Xiaomi_backup "allow"
	touch "${flag_file}"
	} || echo "${0%/*}/mod/a0.app.xiaomi.com.sh丢失！"
	#广告奖励
	filter_hosts "${0%/*}/广告奖励.prop" "${0%/*}/Host/reward"
	mount_set_perm_for_hosts "${0%/*}/Host/reward"
	notification_simulation "已经放行a0.app.xiaomi.com和广告奖励(包含放行开屏广告)，注意放行可能会泄露已安装应用给小米，风险自行承担。" "放行MIUI云备份" "去广告模块"
	sed -i 's/description=.*/description=☞当前已放行MIUI云备份和广告奖励(包含放行开屏广告)，注意放行a0.app.xiaomi.com，可能会泄露已安装应用给小米，永久放行云备份建议看下模块的配置.prop☜\n/g' "${0%/*}/module.prop"
	refresh_information
else
	echo "[✘]已禁止访问a0.app.xiaomi.com和广告奖励域名，保护您的安全。"
	echo -e "                                   
 _     _            _    
| |__ | | ___   ___| | __
| '_ \| |/ _ \ / __| |/ /
| |_) | | (_) | (__|   < 
|_.__/|_|\___/ \___|_|\_\
                         
"
	#云备份
	test -f "${0%/*}/mod/a0.app.xiaomi.com.sh" && {
	source "${0%/*}/mod/a0.app.xiaomi.com.sh"
		Xiaomi_backup
	rm -rf "${flag_file}"
	} || echo "${0%/*}/mod/a0.app.xiaomi.com.sh丢失！"
	mount_set_perm_for_hosts "${0%/*}/Host/all"
	notification_simulation "已禁止访问a0.app.xiaomi.com和广告奖励域名，保护您的安全。" "禁用MIUI云备份" "去广告模块"
	cp -rf "${0%/*}/backup.prop" "${0%/*}/module.prop"
	refresh_information
fi

reset_modules
Zygisk_next_Re_hidden
test -f "${0%/*}/mod/ads_monitor.sh" && nohup "${0%/*}/mod/ads_monitor.sh" >/dev/null 2>&1 &
test -f "${0%/*}/mod/ad.sh" && nohup "${0%/*}/mod/ad.sh" >/dev/null 2>&1 &
) &






