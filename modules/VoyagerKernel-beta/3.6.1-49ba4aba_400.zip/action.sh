# shellcheck disable=SC2034,SC2148
MODDIR=${0%/*}

key_check() {
    while true; do
        key_check=$(/system/bin/getevent -qlc 1)
        key_event=$(echo "$key_check" | awk '{ print $3 }' | grep 'KEY_')
        key_status=$(echo "$key_check" | awk '{ print $4 }')
        if [[ "$key_event" == *"KEY_"* && "$key_status" == "DOWN" ]]; then
            keycheck="$key_event"
            break
        fi
    done
    while true; do
        key_check=$(/system/bin/getevent -qlc 1)
        key_event=$(echo "$key_check" | awk '{ print $3 }' | grep 'KEY_')
        key_status=$(echo "$key_check" | awk '{ print $4 }')
        if [[ "$key_event" == *"KEY_"* && "$key_status" == "UP" ]]; then
            break
        fi
    done
}

echo "-     请选择默认调速器："
echo ""
echo "      音量↑: VK_EXT_GOV"
echo "      音量↓: WALT"
key_check
case "$keycheck" in
"KEY_VOLUMEUP")
    echo ""
    echo "-     您选择了 [VK_EXT_GOV]"
    sh "$MODDIR"/governor_change.sh vk_ext_gov
    ;;
*)
    echo ""
    echo "-     您选择了 [WALT]"
    sh "$MODDIR"/governor_change.sh walt
    ;;
esac
