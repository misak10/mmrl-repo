# shellcheck disable=SC2148
MODDIR=${0%/*}
socid=$(cat "$MODDIR"/functions/socid)
insmod "$MODDIR"/"$socid"/vk_slim_walt.ko
sh "$MODDIR"/governor_change.sh vk_ext_gov
