# shellcheck disable=SC2148
MODDIR=${0%/*}

rm -rf "$MODDIR"
