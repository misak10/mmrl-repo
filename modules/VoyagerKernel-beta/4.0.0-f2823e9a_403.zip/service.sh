# shellcheck disable=SC2148
MODDIR=${0%/*}
socid=$(cat "$MODDIR"/functions/socid)

while [ "$(getprop sys.boot_completed)" != "1" ]; do
  sleep 1
done
while [ ! -d "/sdcard/Android" ]; do
  sleep 1
done

sleep 10
insmod "$MODDIR"/"$socid"/vk_slim_walt.ko
sh "$MODDIR"/governor_change.sh vk_ext_gov
