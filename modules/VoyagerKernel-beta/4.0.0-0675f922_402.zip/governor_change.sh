#!/system/bin/sh
# shellcheck disable=SC2044

while [ "$(getprop vendor.post_boot.parsed)" != "1" ]; do
  sleep 1
done

for scaling_governor in $(find /sys/devices/system/cpu/cpufreq -name "scaling_governor"); do
  echo "$1" >"$scaling_governor"
done
