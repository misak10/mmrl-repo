# shellcheck disable=SC2148
MODDIR=${0%/*}

sh "$MODDIR"/governor_change.sh walt
rm -rf "$MODDIR"
