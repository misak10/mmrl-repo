#!/system/bin/sh
# shellcheck disable=SC1091
# shellcheck disable=SC2154
MODDIR=${0%/*}
. "$MODDIR"/functions/FEAS
socid=$(cat "$MODDIR"/functions/socid)
new_slot="$(getprop ro.boot.slot_suffix)"
previous_slot="$(cat "$MODDIR"/functions/now_slot)"
vk_abi_version=$(cat /sys/module/vendor_hooks/parameters/vk_abi_version)
if [ "$new_slot" != "$previous_slot" ] || { [ -z "$vk_abi_version" ] && [ "$socid" != "SM8650" ]; }; then
  sed -i "s/\[ Perfmgr Fusion \] \[ VK Turbo Sched \]//" "$MODDIR"/module.prop
  sed -i "s/ \[ FEASEnabler $FEASEnabler_version \]//" "$MODDIR"/module.prop
  if [ "$FEAS_Effect" = "FEASJoyose" ]; then
    sed -i "s/ \[ FEASJoyose $FEASJoyose_version \]//" "$MODDIR"/module.prop
  elif [ "$FEAS_Effect" = "FEASHelper" ]; then
    sed -i "s/ \[ FEASHelper $FEASHelper_version \]//" "$MODDIR"/module.prop
  elif [ "$FEAS_Effect" = "Scene" ]; then
    sed -i "s/ \[ Scene 调度 \]//" "$MODDIR"/module.prop
  fi
  sed -i 's/ \[ 内存管理优化 Beta \]//' "$MODDIR"/module.prop
  sed -i 's/Perfmgr_Fusion=[^*]*/Perfmgr_Fusion=null/' "$MODDIR"/functions/FEAS
  sed -i 's/FEASEnabler=[^*]*/FEASEnabler=null/' "$MODDIR"/functions/FEAS
  sed -i 's/FEAS_Effect=[^*]*/FEAS_Effect=null/' "$MODDIR"/functions/FEAS
  sed -i 's/ZRAM_Enhanced=[^*]*/ZRAM_Enhanced=null/' "$MODDIR"/functions/ZRAM_Enhanced
fi
if [ "$FEASEnabler" = "installed" ]; then
  resetprop -n persist.sys.unionpower.enable true
  mkdir -p /dev/mount_lib/lib /dev/mount_lib/lib64
  cp -af /system_ext/lib/libmigui.so /dev/mount_lib/lib/libmigui.so
  cp -af /system_ext/lib64/libmigui.so /dev/mount_lib/lib64/libmigui.so
  chcon "u:object_r:system_lib_file:s0" /dev/mount_lib/lib/libmigui.so
  chcon "u:object_r:system_lib_file:s0" /dev/mount_lib/lib64/libmigui.so
  sed 's?ro.product.product.name?ro.product.prodcut.name?' /system_ext/lib/libmigui.so >/dev/mount_lib/lib/libmigui.so
  sed 's?ro.product.product.name?ro.product.prodcut.name?' /system_ext/lib64/libmigui.so >/dev/mount_lib/lib64/libmigui.so
  sync
  mount --bind "/dev/mount_lib/lib/libmigui.so" "/system_ext/lib/libmigui.so"
  mount --bind "/dev/mount_lib/lib64/libmigui.so" "/system_ext/lib64/libmigui.so"
  restorecon /system_ext/lib/libmigui.so
  restorecon /system_ext/lib64/libmigui.so
fi
# Thanks Pandora Kernel Project
if [ "$FEAS_Effect" = "FEASJoyose" ]; then
  mkdir -p "/dev/mount_lib/odm_etc"
  cp -af "$MODDIR/misc/default_cloud.img" "/dev/mount_lib"
  mount "/dev/mount_lib/default_cloud.img" "/dev/mount_lib/odm_etc"
  mount -t overlay -o lowerdir="/dev/mount_lib/odm_etc:/odm/etc" overlay /odm/etc
fi
