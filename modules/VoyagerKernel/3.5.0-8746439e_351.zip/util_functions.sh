# shellcheck disable=SC2068
# shellcheck disable=SC2086
# shellcheck disable=SC2124
# shellcheck disable=SC2148
# shellcheck disable=SC2155
# shellcheck disable=SC2162

ui_print() {
  echo "$1"
}

abort() {
  ui_print "$1"
  [ ! -z $MODPATH ] && rm -rf $MODPATH
  rm -rf $TMPDIR
  exit 1
}

grep_prop() {
  local REGEX="s/^$1=//p"
  shift
  local FILES=$@
  [ -z "$FILES" ] && FILES='/system/build.prop'
  cat $FILES 2>/dev/null | dos2unix | sed -n "$REGEX" | head -n 1
}

grep_get_prop() {
  local result=$(grep_prop $@)
  if [ -z "$result" ]; then
    # Fallback to getprop
    getprop "$1"
  else
    echo $result
  fi
}

set_perm() {
  chown $2:$3 $1 || return 1
  chmod $4 $1 || return 1
  local CON=$5
  [ -z $CON ] && CON=u:object_r:system_file:s0
  chcon $CON $1 || return 1
}

set_perm_recursive() {
  find $1 -type d 2>/dev/null | while read dir; do
    set_perm $dir $2 $3 $4 $6
  done
  find $1 -type f -o -type l 2>/dev/null | while read file; do
    set_perm $file $2 $3 $5 $6
  done
}

lock_val() { # From Pandora Kernel Project
  if [ -f "$2" ]; then
    chown root:root "$2"
    chmod 0666 "$2"
    echo "$1" >"$2"
    chmod 0444 "$2"
    restorecon -R -F "$2"
  fi
}

# $1:value $2:path
mask_val() { # From Pandora Kernel Project
  find "$2" -type f | while read -r file; do
    lock_val "$1" "$file"

    TIME="$(date "+%s%N")"
    echo "$1" >"/dev/mount_masks/mount_mask_$TIME"
    mount --bind "/dev/mount_masks/mount_mask_$TIME" "$file"
    restorecon -R -F "$file" >/dev/null 2>&1
  done
}

# $1:value $2:path $3:filename
# $1:value $2:path $3:subdir $4:filename
lock_val_in_path() {
  if [ "$#" = "4" ]; then
    find "$2/" -path "*$3*" -name "$4" -type f | while read -r file; do
      lock_val "$1" "$file"
    done
  else
    find "$2/" -name "$3" -type f | while read -r file; do
      lock_val "$1" "$file"
    done
  fi
}
