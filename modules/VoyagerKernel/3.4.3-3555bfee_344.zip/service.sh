#!/system/bin/sh
# shellcheck disable=SC1091
# shellcheck disable=SC2009
# shellcheck disable=SC2044
# shellcheck disable=SC2143
# shellcheck disable=SC2154

MODDIR=${0%/*}
. "$MODDIR"/functions/FEAS
[ -f "$MODDIR"/functions/ZRAM_Enhanced ] && . "$MODDIR"/functions/ZRAM_Enhanced
slot="$(getprop ro.boot.slot_suffix)"
echo "$slot" >"$MODDIR"/functions/now_slot
nohup "$MODDIR"/bin/uninstall "$MODDIR" >/dev/null 2>&1 &
socid=$(cat "$MODDIR"/functions/socid)
if [ "$FEAS_Effect" != "null" ]; then
  while [ "$(getprop sys.boot_completed)" != "1" ]; do
    sleep 1
  done
  while [ ! -d "/sdcard/Android" ]; do
    sleep 1
  done
fi
lock_val() {
  if [ -f "$2" ]; then
    chown root:root "$2"
    chmod 0666 "$2"
    echo "$1" >"$2"
    chmod 0444 "$2"
    restorecon -R -F "$2"
  fi
}
if [ "$Perfmgr_Fusion" = "installed" ]; then
  insmod "$MODDIR"/"$socid"/perfmgr.ko
  if [ -f /sys/module/perfmgr/parameters/freq_scaling ]; then
    if [ -f "$MODDIR"/functions/freq_scaling ]; then
      echo Y >/sys/module/perfmgr/parameters/freq_scaling
    else
      echo N >/sys/module/perfmgr/parameters/freq_scaling
    fi
  fi
  if [ "$socid" = "SM8450" ] || [ "$socid" = "SM8475" ] || [ "$socid" = "SM7475" ]; then
    insmod "$MODDIR"/"$socid"/hyperframe.ko
  else
    insmod "$MODDIR"/"$socid"/vk_turbo_sched.ko
  fi
fi
if [ "$FEAS_Effect" = "FEASHelper" ]; then
  [ ! -f "/data/feas.conf" ] && cp "$MODDIR/misc/feas.conf" "/data/feas.conf"
  killall Feashelper_Mtk >/dev/null 2>&1
  killall FEASHelper >/dev/null 2>&1
  killall FEAShelper >/dev/null 2>&1
  "$MODDIR"/bin/FEASHelper "/data/feas.conf" >/dev/null 2>&1 &
  sleep 3
  isSupport="$(ps -ef | grep FEASHelper | grep -v grep)"
  if [ -n "$isSupport" ]; then
    if [ "$(grep -c FEASEnabler "$MODDIR"/module.prop)" -ne 0 ] && [ "$(grep -c FEASHelper "$MODDIR"/module.prop)" -eq 0 ]; then
      sed -i "s/\(\[ FEASEnabler $FEASEnabler_version \]\)/\1 [ FEASHelper $FEASHelper_version ]/" "$MODDIR"/module.prop
    else
      sed -i "s/\[ FEASHelper 服务运行失败 \]/[ FEASHelper $FEASHelper_version ]/" "$MODDIR"/module.prop
    fi
  else
    if [ "$(grep -c FEASEnabler "$MODDIR"/module.prop)" -ne 0 ] && [ "$(grep -c FEASHelper "$MODDIR"/module.prop)" -eq 0 ]; then
      sed -i "s/\(\[ FEASEnabler $FEASEnabler_version \]\)/\1 [ FEASHelper 服务运行失败 ]/" "$MODDIR"/module.prop
    else
      sed -i "s/\[ FEASHelper $FEASHelper_version \]/[ FEASHelper 服务运行失败 ]/" "$MODDIR"/module.prop
    fi
  fi
elif [ "$FEAS_Effect" = "null" ]; then
  killall -9 com.xiaomi.joyose
  am force-stop com.xiaomi.joyose
  am kill com.xiaomi.joyose
  pm clear com.xiaomi.joyose
  pm enable com.xiaomi.joyose/com.xiaomi.joyose.cloud.CloudServerReceiver
  am startservice com.xiaomi.joyose/com.xiaomi.joyose.smartop.SmartOpService
fi
if [ "$ZRAM_Enhanced" = "installed" ]; then
  [ -f "$MODDIR"/functions/RAM_Info ] && . "$MODDIR"/functions/RAM_Info
  backing_dev="none"
  if [ "$(getprop persist.miui.extm.enable)" = "1" ]; then
    while [ "$(cat /sys/block/zram0/backing_dev)" = "none" ]; do
      sleep 1
    done
    backing_dev="$(cat /sys/block/zram0/backing_dev)"
  fi
  swapoff /dev/block/zram0
  rmmod zram
  insmod "$MODDIR"/"$socid"/crypto_zstdn.ko
  insmod "$MODDIR"/"$socid"/zram.ko
  lock_val "1" /sys/class/block/zram0/reset
  lock_val "0" /sys/class/block/zram0/mem_limit
  lock_val "zstdn" >/sys/class/block/zram0/comp_algorithm
  lock_val "$backing_dev" /sys/class/block/zram0/backing_dev
  lock_val "$ZRAM_Size" /sys/class/block/zram0/disksize
  mkswap /dev/block/zram0
  swapon /dev/block/zram0
fi
scaling_available_governors="$(find /sys/devices/system/cpu/cpufreq -name "scaling_available_governors" | head -n 1)"
if [ "$(grep -c 'uag' "$scaling_available_governors")" -ge 1 ]; then
  while [ "$(getprop vendor.post_boot.parsed)" != "1" ]; do
    sleep 1
  done
  for scaling_governor in $(find /sys/devices/system/cpu/cpufreq -name "scaling_governor"); do
    echo uag >"$scaling_governor"
  done
  for stall_aware in $(find /sys/devices/system/cpu/cpufreq -name "stall_aware"); do
    echo 1 >"$stall_aware"
  done
  if [ "$socid" = "SM8650" ]; then
    for cobuck_enable in $(find /sys/devices/system/cpu/cpufreq -name "cobuck_enable"); do
      if [ "$(echo "$cobuck_enable" | cut -d'/' -f7)" != "policy7" ]; then
        echo 1 >"$cobuck_enable"
      fi
    done
  fi
fi
