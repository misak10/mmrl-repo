/*
 Navicat Premium Data Transfer

 Source Server         : teg_config_SM8650
 Source Server Type    : SQLite
 Source Server Version : 3035005
 Source Schema         : main

 Target Server Type    : SQLite
 Target Server Version : 3035005
 File Encoding         : 65001

 Date: 12/09/2024 16:05:34
*/

PRAGMA foreign_keys = false;

-- ----------------------------
-- Table structure for rules
-- ----------------------------
DROP TABLE IF EXISTS "rules";
CREATE TABLE "rules" (
  "_id" INTEGER PRIMARY KEY AUTOINCREMENT,
  "rule_id" INTEGER,
  "rule_version" INTEGER,
  "rule_module" TEXT,
  "rule_content" TEXT
);

-- ----------------------------
-- Records of rules
-- ----------------------------
INSERT INTO "rules" VALUES (1, 1205847, 404844, 'booster_config', '{
  "config_name": "booster_config",
  "enable": true,
  "group_name": "booster_config",
  "params": {
    "game_booster": {
      "GameSight": true,
      "action_key_optimized": true,
      "affinity_enable": true,
      "background_freeze_enable": true,
      "background_freeze_whitelist": [
        "com.xiaomi.joyose",
        "com.miui.powerkeeper",
        "com.xiaomi.migameservice",
        "mcd",
        "com.xiaomi.gamecenter.sdk.service"
      ],
      "booster_config": {
        "scene_config": [
          {
            "scene_id": 5,
            "scene_name": "loading",
            "booster": [
              {
                "permission": "root",
                "cmd": "perflock#40800000_FFF#20"
              }
            ]
          },
          {
            "scene_id": 1004,
            "end": [
              {
                "permission": "root",
                "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
              }
            ],
            "scene_name": "target_fps_update",
            "booster": [
              {
                "permission": "root",
                "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
              },
              {
                "permission": "root",
                "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
              },
              {
                "permission": "root",
                "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
              }
            ]
          }
        ],
        "default_config": [
          {
            "permission": "root",
            "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
          }
        ],
        "ovrride_config": [
          {
            "game_name": "SGAME",
            "scene_ovrride": [
              {
                "scene_id": 3,
                "scene_name": "login",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 1,
                "scene_name": "startgame",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "booster#120#ED": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,2956800,2956800,3052800;WA#0;BI#0;BP#2;sys/module/migt/parametes/force_forbidden_walt_lb#0;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/module/migt/parameters/render_prefer_cluster#1;/data/system/mcd/raf_debug#0;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu2/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "swe#"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu2_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu5_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu7_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/policy#CoreThread:1:2:4"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a#340"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_b#-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/fast_down_circle_base#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_c#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/f_minfreq#400000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#14"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/timeout_120#12000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu5/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40804100_626_40804000_A46_40804300_94C_40804200_A46_5FC00000_7C#0"
                  }
                ],
                "booster#120#HDR#ED": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,2956800,2956800,3052800;WA#0;BI#0;BP#0;/data/system/mcd/raf_debug#0;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu2/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "swe#"
                  },
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,2956800,2956800,3052800;WA#0;BI#0;BP#2;/sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1017600:-20;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1286400:-10 1824000:-15 2188800:-15;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1286400:-10 1824000:-15 2188800:-15;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1248000:-10 1593600:-15;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/policy#CoreThread:1:2:4"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu5/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu2_offset#200000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu5_offset#200000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu7_offset#200000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a#340"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_b#-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/fast_down_circle_base#4"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_c#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/f_minfreq#400000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#14"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/timeout_120#12000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40804100_626_40804000_A46_40804300_94C_40804200_A46_5FC00000_7C#0"
                  }
                ],
                "scene_id": 1004,
                "booster#FI": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,2956800,2956800,3052800;WA#0;BI#0;BP#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2;/data/system/mcd/policy#CoreThread:1:2:4"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/module/migt/parameters/force_forbidden_walt_lb#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/module/migt/parameters/render_prefer_cluster#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "CORE7_CTL#0;CORE5_CTL#0;CORE2_CTL#0;T0_LOADS#0;T2_LOADS#0 1286400:-10 1612800:-15 1920000:-15;T5_LOADS#0 1286400:-10 1612800:-15 1920000:-15;T7_LOADS#0 1248000:-10 1593600:-15 1824000:-15;WALT_RTG0#800000;WALT_HISPEED2#800000;WALT_HISPEED5#800000;WALT_THRESH0#0;WALT_THRESH2#600;WALT_THRESH5#600;WALT_THRESH7#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC_5FC00000_63_5FC04000_63_40800200_384_40800300_3C0_40800000_3C0#0"
                  }
                ],
                "end": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,2956800,2956800,3052800;WA#0;BI#0;BP#0;/sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/stask_prefer_cluster#0;/sys/module/migt/parameters/render_prefer_cluster#0;/data/system/mcd/raf_debug#0;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu2/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "swe#"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq#2265600"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq#2956800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq#3052800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq#2956800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/timeout_120#13000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a#380"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_b#-50"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu2_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu5_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu7_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_c#3"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/f_minfreq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/fast_down_circle_base#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#10"
                  }
                ],
                "booster#ED": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,2956800,2956800,3052800;WA#0;BI#0;BP#0;/data/system/mcd/raf_debug#0;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu2/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "swe#"
                  },
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,2956800,2956800,3052800;WA#0;BI#0;BP#2;/sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu2/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1017600:-20;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1286400:-10 1612800:-15 1920000:-15;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1286400:-10 1612800:-15 1920000:-15;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1248000:-10 1593600:-15 1824000:-15;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/policy#CoreThread:1:2:4"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a#380"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_b#-50"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/fast_down_circle_base#4"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_c#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/f_minfreq#400000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu5/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/core_ctl/enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/timeout_120#12000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/target_loads#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC_5FC00000_7C#0"
                  }
                ],
                "scene_name": "target_fps_update"
              },
              {
                "scene_id": 8,
                "booster#FI": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,2956800,2956800,3052800;WA#0;BI#0;BP#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2;/data/system/mcd/policy#CoreThread:1:2:4"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/module/migt/parameters/force_forbidden_walt_lb#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/module/migt/parameters/render_prefer_cluster#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "CORE7_CTL#0;CORE5_CTL#0;CORE2_CTL#0;T0_LOADS#0;T2_LOADS#0 1286400:-10 1612800:-15 1920000:-15;T5_LOADS#0 1286400:-10 1612800:-15 1920000:-15;T7_LOADS#0 1248000:-10 1593600:-15 1824000:-15;WALT_RTG0#800000;WALT_HISPEED2#800000;WALT_HISPEED5#800000;WALT_THRESH0#0;WALT_THRESH2#600;WALT_THRESH5#600;WALT_THRESH7#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC_5FC00000_63_5FC04000_63_40800200_384_40800300_3C0_40800000_3C0#0"
                  }
                ],
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq#2265600"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq#2956800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq#3052800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq#2956800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/timeout_120#13000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a#380"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_b#-50"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu2_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu5_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu7_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_c#3"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/f_minfreq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/fast_down_circle_base#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#10"
                  },
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,2956800,2956800,3052800;WA#0;BI#0;BP#0;/data/system/mcd/raf_debug#0;sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/stask_prefer_cluster#0;/sys/module/migt/parameters/render_prefer_cluster#0;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu2/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "swe#"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_x#10"
                  }
                ],
                "scene_name": "replay",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/policy#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/timeout_120#13000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a#400"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_b#-80"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu2_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu5_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cpu7_offset#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_c#3"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/f_minfreq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/fast_down_circle_base#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#9"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq#2265600"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq#2956800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq#3052800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq#2956800"
                  },
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MA#2265600,2956800,2956800,3052800;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu2/core_ctl/enable#0;/data/system/mcd/raf_debug#2;/data/system/mcd/policy#UnityGfx:1:2:6,UnityMain:1:7:7,CoreThread:1:2:6;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1017600:-20;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1286400:-10 1824000:-15 2188800:-15;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1286400:-20 1824000:-25 2188800:-25;;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1248000:-20 1593600:-25;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#40C00000_0_42C08000_0_43C00000_1_5FC18000_0#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/load_scaling_x#5"
                  }
                ]
              },
              {
                "scene_id": 1002,
                "scene_name": "motor",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "motor#500"
                  }
                ]
              },
              {
                "scene_id": 5,
                "scene_name": "loading",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 10004,
                "scene_name": "coldLaunch",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#20"
                  }
                ]
              },
              {
                "scene_id": 4,
                "scene_name": "ending",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "group_fight_thresh": 4,
            "end_scene": "4",
            "badfps_thresh1": "54,81,108",
            "badfps_thresh2": "3,5,10"
          },
          {
            "PID_M": "60#10:0 61 61 0 0 0,42:43 60 30 10 0.8 3",
            "game_name": "com.miHoYo.hkrpg",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,3148800,3148800,3052800;WA#0;BI#0;BP#0;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpu2/core_ctl/enable#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/proc/sys/walt/sched_asymcap_boost#0;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024;/sys/module/migt/parameters/vip_task_max_num#15"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR/scaling_a#380;PERFMGR/scaling_b#-50;PERFMGR/scaling_c#3"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR/timeout_60#25000;PERFMGR/cons_no_j_cnt#10;PERFMGR/d_boost#0"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  }
                ],
                "scene_name": "foreground",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MA#1248000,2438400,1017600,1708800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000;/data/system/mcd/raf_debug#2;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/module/migt/parameters/force_viptask_select_rq#1;/sys/module/migt/parameters/force_forbidden_walt_lb#1;/sys/module/migt/parameters/vip_task_max_num#0;/data/system/mcd/policy#Job.Worker:6:2:4;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;sys/module/migt/parameters/cpu_boost_cycle#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 902400:-15;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 2188800:-10;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1286400:-10;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1248000:-10 1824000:-10;/sys/devices/system/cpu/cpu2/core_ctl/enable#0;/sys/devices/system/cpu/cpu5/core_ctl/enable#0;/sys/devices/system/cpu/cpu7/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;PERFMGR/scaling_a#350;PERFMGR/scaling_b#-40;PERFMGR/scaling_c#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR/timeout_60#20000;PERFMGR/cons_no_j_cnt#10;PERFMGR/d_boost#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#600000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_42810000_242_5FC18000_0_40CE0000_005F0055_40CE0100_005F0055_40CE0200_005F0055#0"
                  }
                ]
              },
              {
                "scene_id": 1005,
                "scene_name": "others",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MA#1248000,2438400,1017600,1708800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000"
                  }
                ]
              },
              {
                "scene_id": 1009,
                "scene_name": "xingchahai",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MA#1248000,2438400,1017600,1708800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000"
                  }
                ]
              },
              {
                "scene_id": 1010,
                "scene_name": "changletian",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MA#1248000,2572800,1017600,1708800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000"
                  }
                ]
              },
              {
                "scene_id": 1011,
                "scene_name": "taibusi",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MA#1248000,2438400,1017600,1708800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000"
                  }
                ]
              },
              {
                "scene_id": 1012,
                "scene_name": "xingzhengqu",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MA#1248000,2438400,1017600,1708800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000"
                  }
                ]
              },
              {
                "scene_id": 10004,
                "scene_name": "coldLaunch",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#10"
                  }
                ]
              }
            ],
            "PID_T": "60#10:0 61 61 0 0 0,46:47 60 56 10 0.5 3,47:48 55 30 10 0.8 3"
          },
          {
            "game_name": "com.tencent.tmgp.pubgmhd",
            "scene_ovrride": [
              {
                "booster#90#ED": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#0;CORE2_CTL#0;CORE5_CTL#1;CORE7_CTL#1;WALT_PL2#0;WALT_PL5#0;WALT_PL7#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/max_cpus#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;/sys/devices/system/cpu/cpu5/core_ctl/max_cpus#2;/sys/devices/system/cpu/cpu5/core_ctl/min_cpus#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/module/migt/parameters/force_viptask_select_rq#1;/sys/module/migt/parameters/force_forbidden_walt_lb#1;/sys/module/migt/parameters/vip_task_max_num#0;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/data/system/mcd/raf_debug#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;WALT_HISPEED2#800000;WALT_HISPEED5#800000;WALT_THRESH0#0;WALT_THRESH2#600;WALT_THRESH5#600;WALT_THRESH7#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 1248000:-10;T2_LOADS#0 1497600:-10 1920000:-5;T5_LOADS#0 1497600:-10 1920000:-5;T7_LOADS#0 1593600:-10 1939200:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#43C00000_1_5FC18000_0_5FC00000_63_5FC04000_63#0"
                  }
                ],
                "scene_id": 1004,
                "booster#FI": [
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2;/data/system/mcd/policy#RenderThread:1:2:4,Thread-:1:7:7,FAsyncLoading:1:2:4"
                  },
                  {
                    "permission": "root",
                    "cmd": "CORE2_CTL#1;CORE5_CTL#1;CORE7_CTL#1;WALT_PL0#0;WALT_PL2#0;WALT_PL5#0;WALT_PL7#0;WALT_RTG0#600000;WALT_RTG2#729600;WALT_RTG5#729600;WALT_RTG7#787200"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu0/core_ctl/min_cpus#2;/sys/devices/system/cpu/cpu2/core_ctl/min_cpus#3;/sys/devices/system/cpu/cpu5/core_ctl/min_cpus#2;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;/sys/devices/system/cpu/cpu5/core_ctl/min_partial_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;PERFMGR/d_boost#0;PERFMGR/cons_no_j_cnt#10;PERFMGR/scaling_c#3;PERFMGR/scaling_b#-50;PERFMGR/scaling_a#360;PERFMGR/t_fps_61#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 1248000:-10;T2_LOADS#0 1708800:-10 1920000:-12;T5_LOADS#0 1708800:-5 1958400:-12;T7_LOADS#0 1248000:-10 1593600:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC_40800200_384_40800000_3E8#0"
                  }
                ],
                "booster#90#HD#ED": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1248000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1497600:-10 1920000:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1497600:-10 1920000:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1593600:-10 1939200:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600;/sys/devices/system/cpu/cpu7/core_ctl/max_cpus#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;/sys/devices/system/cpu/cpu5/core_ctl/max_cpus#2;/sys/devices/system/cpu/cpu5/core_ctl/min_cpus#2;/sys/module/migt/parameters/ip_task_max_num#5;/sys/module/migt/parameters/cpu_boost_cycle#0;/sys/module/migt/parameters/force_viptask_select_rq#0;/sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/vip_task_max_num#15;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/data/system/mcd/raf_debug#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#43C00000_1_5FC18000_0_5FC00000_63_5FC04000_63#0"
                  }
                ],
                "end": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;WA#0;BI#0;BP#0;SCN#1;CPU_WALT_OFF;/data/system/mcd/policy#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR/d_boost#0;PERFMGR/d_table#1500000:3187000 1400000:2736000 1300000:2092000 1200000:1708000"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR/cons_no_j_cnt#10;PERFMGR/scaling_a#380;PERFMGR/scaling_b#-50;PERFMGR/scaling_c#3"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR/t_fps_91#0;PERFMGR/better_perf#1;PERFMGR/timeout_90#16600;PERFMGR/load_scaling_x#10;PERFMGR/min_freq_limit_level_limit#0"
                  }
                ],
                "booster#ED": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#0;CORE2_CTL#0;CORE5_CTL#1;CORE7_CTL#1;WALT_PL2#0;WALT_PL5#0;WALT_PL7#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;WALT_HISPEED2#800000;WALT_THRESH0#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 787200:-20;T2_LOADS#0 1286400:-5 1401600:-15;T5_LOADS#0 1286400:-5 1401600:-15;T7_LOADS#0 1286400:-5"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/module/migt/parameters/force_viptask_select_rq#1;/sys/module/migt/parameters/force_forbidden_walt_lb#1;/sys/module/migt/parameters/vip_task_max_num#0;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/data/system/mcd/raf_debug#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;SCN#2;sys/module/migt/parameters/cpu_boost_cycle#0;MM#307200,499200,499200,480000;MA#1248000,1824000,1824000,1939200"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#43C00000_1_5FC18000_0_5FC00000_63_5FC04000_63#0"
                  }
                ],
                "scene_name": "target_fps_update"
              },
              {
                "scene_id": 3,
                "scene_name": "login",
                "change_end": true,
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 5,
                "scene_name": "loading",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#5"
                  }
                ]
              },
              {
                "scene_id": 10004,
                "scene_name": "coldLaunch",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#20"
                  }
                ]
              },
              {
                "scene_id": 100,
                "scene_name": "player",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40804000_720_40804300_720_40804200_639#50"
                  }
                ]
              }
            ],
            "start_scene": "102",
            "end_scene": "3",
            "badfps_thresh1": "54,81",
            "badfps_thresh2": "3,5"
          },
          {
            "game_name": "com.tencent.lolm",
            "scene_ovrride": [
              {
                "scene_id": 3,
                "scene_name": "login",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 1,
                "scene_name": "startgame",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;WA#0;BI#0;BP#0;SCN#1;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#1024;/proc/sys/walt/sched_asymcap_boost#0;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1612800;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#1612800;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MM#307200,499200,499200,480000;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000;/data/system/mcd/raf_debug#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/module/migt/parameters/ip_task_max_num#5;/sys/module/migt/parameters/cpu_boost_cycle#0;/sys/module/migt/parameters/force_viptask_select_rq#0;/sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/vip_task_max_num#15;/data/system/mcd/policy#CoreThread:1:vip;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1248000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1612800:-10 1920000:-10 2188800:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1612800:-10 1920000:-10 2188800:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1478400:-10 1708800:-5  1939200:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#3"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_5FC00000_63_5FC04000_63_5FC18000_0#0"
                  }
                ]
              },
              {
                "scene_id": 1002,
                "scene_name": "motor",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "motor#500"
                  }
                ]
              },
              {
                "scene_id": 5,
                "scene_name": "loading",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              },
              {
                "scene_id": 4,
                "scene_name": "ending",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#15"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "group_fight_thresh": 4,
            "end_scene": "4",
            "badfps_thresh1": "54,81,108",
            "badfps_thresh2": "3,5,10"
          },
          {
            "game_name": "com.tencent.tmgp.cod",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F_40C40000_FC_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.garena.game.codm",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F_40C40000_FC_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.netease.lglr",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T2_LOADS#-3 994125:-7 1435500:-11 1881000:-15 2338875:-19"
                  },
                  {
                    "permission": "root",
                    "cmd": "T7_LOADS#-3 1167187:-7 1649625:-12 2128171:-16 2587265:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "android.process.acore",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
                  }
                ]
              }
            ]
          },
          {
            "PID_RE2_T": "60#10:0 61 61 0 0 0,46.5:47 60 30 10 0.8 3",
            "PID_RE3_T": "60#10:0 45 45 0 0 0,46.5:47 45 30 10 0.8 3",
            "PID_RE4_T": "60#10:0 30 30 0 0 0,46.5:47 30 25 10 0.8 3",
            "scene_ovrride": [
              {
                "booster#MGAME#ED": [
                  {
                    "permission": "root",
                    "cmd": "perfhint#00001055_1_1#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1248000:-5;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1497600:-10 2035200:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1286400:-10 1497600:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1248000:-15 1593600:-10;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/migt/parameters/boost_policy#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq#1248000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq#2707200"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq#2169600"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq#1075200"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a#340"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_b#-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_c#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/t_fps_61#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#6"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#600000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/d_boost#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/timeout_60#20000"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/policy#UnityMain:1:2:4,UnityGfxDeviceW:1:7:7,Worker Thread:3:2:4,UnityPreload:1:2:6,Thread-:20:2:3"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC_4280C000_136_43488000_29BF80_5FC00000_7C#0"
                  }
                ],
                "booster#FI#YS_RE_4": [
                  {
                    "permission": "root",
                    "cmd": "perfhint#00001055_1_1#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 1248000:-5;T2_LOADS#0 1497600:-10 2035200:-5;T5_LOADS#0 1286400:-10 1497600:-5;T7_LOADS#0 1248000:-15 1593600:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "WALT_PL0#0;WALT_PL2#0;WALT_PL5#0;WALT_PL7#0;WALT_RTG0#787200;WALT_RTG2#729600;WALT_RTG5#729600;WALT_RTG7#787200;WALT_THRESH0#0;WALT_THRESH2#600;WALT_THRESH5#600;WALT_THRESH7#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/core_ctl/min_cpus#2;sys/devices/system/cpu/cpu2/core_ctl/min_cpus#3;sys/devices/system/cpu/cpu5/core_ctl/min_cpus#2;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;/sys/devices/system/cpu/cpu5/core_ctl/min_partial_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1344000;CPU2_MAX#2131200;CPU5_MAX#1708800;CPU7_MAX#1939200"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR/scaling_a#380;PERFMGR/scaling_b#-80;PERFMGR/scaling_c#2;PERFMGR/timeout_30#35000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/d_boost#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "glk#BP#2;sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/module/migt/parameters/render_prefer_cluster#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2;/data/system/mcd/policy#UnityMain:1:7:7,UnityMultiRende:1:5:6,Worker Thread:3:2:4,UnityPreload:1:2:4,Thread-:10:2:6"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC_5FC00000_7C_42810000_242_43488000_30A138_40800200_3E8_40800000_3E8#0"
                  }
                ],
                "booster#TGAME#ED": [
                  {
                    "permission": "root",
                    "cmd": "perfhint#00001055_1_1#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1248000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1497600:-10 2035200:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1286400:-20 1497600:-10;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1248000:-15 1593600:-10;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#800;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#800;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/migt/parameters/boost_policy#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq#1248000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq#2707200"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq#2169600"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq#1075200"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/perfmgr_enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a#340"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_b#-50"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_c#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/t_fps_61#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#600000"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/d_boost#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/timeout_60#20000"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/policy#UnityMain:1:2:4,UnityGfxDeviceW:1:7:7,Worker Thread:3:2:4,UnityPreload:1:2:6,Thread-:20:2:3"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC_4280C000_136_43488000_29BF80_5FC00000_7C#0"
                  }
                ],
                "scene_id": 1004,
                "booster#FI": [
                  {
                    "permission": "root",
                    "cmd": "perfhint#00001055_1_1#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 1248000:-5;T2_LOADS#0 1497600:-10 2035200:-5;T5_LOADS#0 1286400:-10 1497600:-5;T7_LOADS#0 1248000:-15 1593600:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "WALT_PL0#0;WALT_PL2#0;WALT_PL5#0;WALT_PL7#0;WALT_RTG0#787200;WALT_RTG2#729600;WALT_RTG5#729600;WALT_RTG7#787200;WALT_THRESH0#0;WALT_THRESH2#600;WALT_THRESH5#600;WALT_THRESH7#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/core_ctl/min_cpus#2;sys/devices/system/cpu/cpu2/core_ctl/min_cpus#3;sys/devices/system/cpu/cpu5/core_ctl/min_cpus#2;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;/sys/devices/system/cpu/cpu5/core_ctl/min_partial_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1344000;CPU2_MAX#2707200;CPU5_MAX#1708800;CPU7_MAX#1939200"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR/scaling_a#320;PERFMGR/scaling_b#-50;PERFMGR/scaling_c#3;PERFMGR/timeout_49#24500"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#12"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/d_boost#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#2;/data/system/mcd/policy#UnityMain:1:7:7,UnityMultiRende:1:5:6,Worker Thread:3:2:4,UnityPreload:1:2:4,Thread-:10:2:6"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC_4280C000_136_43488000_29BF80_5FC00000_7C_40800200_3E8_40800000_3E8#0"
                  }
                ],
                "end": [
                  {
                    "permission": "root",
                    "cmd": "CPU_WALT_OFF"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu0/core_ctl/min_cpus#0;/sys/devices/system/cpu/cpu2/core_ctl/min_cpus#0;/sys/devices/system/cpu/cpu5/core_ctl/min_cpus#0;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;/sys/devices/system/cpu/cpu5/core_ctl/min_partial_cpus#2"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/l3freq_boost#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/scaling_max_freq#2265600"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/cpufreq/scaling_max_freq#2956800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu7/cpufreq/scaling_max_freq#3052800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu5/cpufreq/scaling_max_freq#2956800"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/d_boost#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_a#380"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_b#-50"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/scaling_c#3"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/t_fps_61#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/cons_no_j_cnt#10"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/module/perfmgr/parameters/timeout_60#25000"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/raf_debug#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/data/system/mcd/policy#0"
                  }
                ],
                "scene_name": "target_fps_update"
              },
              {
                "scene_id": 10004,
                "scene_name": "coldLaunch",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#12"
                  }
                ]
              },
              {
                "scene_id": 1008,
                "scene_name": "loading",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#17"
                  }
                ]
              },
              {
                "scene_id": 1007,
                "scene_name": "transfer",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#5"
                  }
                ]
              }
            ],
            "PID_RE5_T": "60#10:0 0 0 0 0 0,42.5:42.5 45 45 0 0 0,45:45 30 30 0 0 0",
            "PID_T": "60#10:0 0 0 0 0 0,46.5:47 60 30 10 0.8 3",
            "dynamic_yuanshen_high_quality_targetfps_M": "60#10:0,42:45,43:30",
            "dynamic_yuanshen_high_quality_targetfps": "60#10:0,47:45,48:30",
            "PID_M": "60#10:0 0 0 0 0 0,42:43 60 30 10 1 2",
            "game_name": "YUANSHEN",
            "PID_HQ1_T": "60#10:0 61 61 0 0 0,46.5:47 60 30 10 0.8 3",
            "PID_HQ2_T": "60#10:0 30 30 0 0 0,46.5:47 30 30 10 0.8 3",
            "PID_RE2_M": "60#10:0 61 61 0 0 0,42:43 60 30 10 1 2",
            "PID_HQ1_M": "60#10:0 61 61 0 0 0,42:43 60 30 10 1 2",
            "PID_RE3_M": "60#10:0 45 45 0 0 0,42:43 45 30 10 1 2",
            "PID_HQ2_M": "60#10:0 30 30 0 0 0,42:43 30 30 10 1 2",
            "PID_RE4_M": "60#10:0 30 30 0 0 0,42:43 30 25 10 1 2",
            "PID_RE5_M": "60#10:0 0 0 0 0 0,41:41 30 30 0 0 0"
          },
          {
            "game_name": "COMMON1",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20;T2_LOADS##-3 994125:-7 1435500:-11 1881000:-15 2338875:-19;T7_LOADS#-3 1167187:-7 1649625:-12 2128171:-16 2587265:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC_40CE0000_0064005F_40CE0200_00410037#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "COMMON2",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T2_LOADS#-3 994125:-7 1435500:-11 1881000:-15 2338875:-19"
                  },
                  {
                    "permission": "root",
                    "cmd": "T7_LOADS#-3 1167187:-7 1649625:-12 2128171:-16 2587265:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "MOBA",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T2_LOADS#10 1435500:-5 1881000:-10 2338875:-15"
                  },
                  {
                    "permission": "root",
                    "cmd": "T7_LOADS#10 1649625:-5 2128171:-10 2587265:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "BH3",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perfhint#00001055_1_1#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#2016000;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T2_LOADS#5;T7_LOADS#5"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#600000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.af",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T2_LOADS#-25 1401600:-30 1785600:-55;T7_LOADS#-10 1478400:-20 1843200:-35"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F_40C3C000_7F_40C40000_7F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.tmgp.cf",
            "scene_ovrride": [
              {
                "scene_id": 5,
                "scene_name": "loading",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#5"
                  }
                ]
              },
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1716000;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0;T2_LOADS#0 2100000:-5 2500000:-10;T7_LOADS#0 2100000:-7 2500000:-13"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "G67",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.bilibili.hunter3.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20;T2_LOADS#-5;T7_LOADS#-5"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ]
              }
            ],
            "start_scene": "7",
            "group_fight_thresh": 4,
            "end_scene": "4",
            "badfps_thresh1": "54,81,108",
            "badfps_thresh2": "3,5,10"
          },
          {
            "game_name": "com.netease.nshm.mi",
            "scene_ovrride": [
              {
                "scene_id": 10001,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;WA#0;BI#0;BP#0;SCN#1;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#1024;/proc/sys/walt/sched_asymcap_boost#0;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1612800;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#1612800;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024"
                  }
                ],
                "scene_name": "foreground",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000;/data/system/mcd/raf_debug#1;/sys/module/migt/parameters/force_viptask_select_rq#1;/sys/module/migt/parameters/force_forbidden_walt_lb#1;/sys/module/migt/parameters/vip_task_max_num#0;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;/data/system/mcd/policy#UnityChoreograp:1:vip,Job.Worker:2:vip;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1248000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1401600:-10 1612800:-10 1824000:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1401600:-10 1612800:-10 1824000:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1248000:-10 1478400:-5  1708800:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/module/migt/parameters/vip_task_max_num#15"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_5FC18000_0#0"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  }
                ]
              },
              {
                "scene_id": 10004,
                "scene_name": "coldLaunch",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#10"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.jkchess",
            "scene_ovrride": [
              {
                "scene_id": 10001,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;WA#0;BI#0;BP#0;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu2/core_ctl/enable#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#1024;/proc/sys/walt/sched_asymcap_boost#0;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#1497600;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0;/sys/module/migt/parameters/vip_task_max_num#15"
                  }
                ],
                "scene_name": "foreground",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MA#2265600,3148800,2956800,3052800;/data/system/mcd/raf_debug#1;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/max_cpus#1;/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/sys/module/migt/parameters/ip_task_max_num#5;/sys/module/migt/parameters/cpu_boost_cycle#0;/sys/devices/system/cpu/cpufreq/policy7/walt/rtg_boost_freq#0;/sys/module/migt/parameters/force_viptask_select_rq#0;/sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/vip_task_max_num#15;/data/system/mcd/policy#Job.Worker:2:vip;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1344000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1612800:-10 1920000:-10 2188800:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1497600:-10 1824000:-10 2035200:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1593600:-10 1824000:-5  2112000:-10;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#40C00000_0_43C00000_1_5FC18000_0_5FC00000_63_5FC04000_63_42810000_136#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.netease.mc.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F_40C40000_FC_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.feiyu.carrot3.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.minitech.miniworld.TMobile.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.taomee.molenew.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-6"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#4280C000_16C_42C08000_0_43C00000_1_40C20100_14_40C20200_5A_40C1C100_1E_40C1C200_5F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "DLDL",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_7F_40C3C000_7F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.knight.union.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq#633600"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq#1200000"
                  },
                  {
                    "permission": "root",
                    "cmd": "CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.tmgp.djsy",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_FC_40C3C000_FC_4280C000_1B7#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.wb.elsfkx.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq#633600"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq#1200000"
                  },
                  {
                    "permission": "root",
                    "cmd": "CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.leniu.jlsy.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_FC_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.tmgp.speedmobile",
            "scene_ovrride": [
              {
                "booster#120": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000;/data/system/mcd/raf_debug#2;/data/system/mcd/policy#UnityGfxDeviceW:1:5:6,UnityMain:1:7:7,Job.Worker:6:2:6;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1248000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1612800:-10 1920000:-10 2323200:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1612800:-10 1920000:-10 2323200:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1593600:-10 1824000:-5  2112000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1#0"
                  }
                ],
                "scene_id": 10001,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "glk#MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;WA#0;BI#0;BP#0;SCN#1;/data/system/mcd/policy#0;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#1;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#787200;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#1024;/proc/sys/walt/sched_asymcap_boost#0;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#1612800;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#1612800;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#1024;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#1024"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  }
                ],
                "scene_name": "foreground",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": ""
                  }
                ]
              },
              {
                "booster#60": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000;/data/system/mcd/raf_debug#2;/data/system/mcd/policy#UnityGfxDeviceW:1:5:6,UnityMain:1:7:7,Job.Worker:6:2:6;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1248000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1286400:-10 1497600:-10 1708800:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1286400:-10 1497600:-10 1708800:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1248000:-10 1478400:-5  1708800:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1#0"
                  }
                ],
                "booster#90": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000;/data/system/mcd/raf_debug#2;/data/system/mcd/policy#UnityGfxDeviceW:1:5:6,UnityMain:1:7:7,Job.Worker:6:2:6;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1248000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1497600:-10 1708800:-10 1920000:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1497600:-10 1708800:-10 1920000:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1478400:-10 1708800:-5  1939200:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1#0"
                  }
                ],
                "booster#120": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000;/data/system/mcd/raf_debug#2;/data/system/mcd/policy#UnityGfxDeviceW:1:5:6,UnityMain:1:7:7,Job.Worker:6:2:6;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1344000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1824000:-10 2188800:-10 2323200:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1824000:-10 2188800:-10 2323200:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1824000:-10 2112000:-5  2304000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1#0"
                  }
                ],
                "scene_id": 1004,
                "scene_name": "target_fps_update",
                "booster#30": [
                  {
                    "permission": "root",
                    "cmd": "glk#WA#1;BI#0;BE#0;BP#2;MM#307200,499200,499200,480000;MA#2265600,3148800,2956800,3052800;MF#0:307200 1:307200 2:499200 3:499200 4:499200 5:499200 6:499200 7:480000;/data/system/mcd/raf_debug#2;/data/system/mcd/policy#UnityGfxDeviceW:1:5:6,UnityMain:1:7:7,Job.Worker:6:2:6;/sys/devices/system/cpu/cpufreq/policy0/walt/target_loads#0 1248000:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/target_loads#0 1190400:-10 1401600:-10 1612800:-5;/sys/devices/system/cpu/cpufreq/policy5/walt/target_loads#0 1190400:-10 1401600:-10 1612800:-5;/sys/devices/system/cpu/cpufreq/policy7/walt/target_loads#0 1017600:-10 1363200:-5  1593600:-10;/sys/devices/system/cpu/cpufreq/policy2/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy5/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy7/walt/pl#0;/sys/devices/system/cpu/cpufreq/policy0/walt/rtg_boost_freq#800000;/sys/devices/system/cpu/cpufreq/policy2/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy5/walt/hispeed_freq#800000;/sys/devices/system/cpu/cpufreq/policy0/walt/target_load_thresh#0;/sys/devices/system/cpu/cpufreq/policy2/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy5/walt/target_load_thresh#600;/sys/devices/system/cpu/cpufreq/policy7/walt/target_load_thresh#600;/sys/devices/system/cpu/cpu5/core_ctl/enable#1;/sys/devices/system/cpu/cpu7/core_ctl/enable#1"
                  },
                  {
                    "permission": "root",
                    "cmd": ""
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1#0"
                  }
                ]
              },
              {
                "scene_id": 3,
                "scene_name": "login",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#5"
                  }
                ]
              },
              {
                "scene_id": 5,
                "scene_name": "loading",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#5"
                  }
                ]
              },
              {
                "scene_id": 10004,
                "scene_name": "coldLaunch",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "perflock#40C20100_14_40C20200_14_40C1C100_1E_40C1C200_1E_40800000_FFF_40800200_FFF_40800100_FFF_40800300_FFF_41800000_FF_40400000_1_42C10000_1_43000000_FF_43400000_FFFF#10"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "HARRYPOTTER",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq#633600"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu2/cpufreq/scaling_min_freq#1200000"
                  },
                  {
                    "permission": "root",
                    "cmd": "CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.netease.lrs.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.hermes.h1game.mi",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq#633600"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu3/cpufreq/scaling_min_freq#1200000"
                  },
                  {
                    "permission": "root",
                    "cmd": "CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F_4280C000_16C#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.KiHan",
            "scene_ovrride": [
              {
                "booster#60": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/module/migt/parameters/force_viptask_select_rq#0;/sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/vip_task_max_num#0;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/data/system/mcd/raf_debug#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ],
                "booster#90": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/module/migt/parameters/force_viptask_select_rq#0;/sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/vip_task_max_num#0;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/data/system/mcd/raf_debug#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-10 1440000:-15"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ],
                "booster#120": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/module/migt/parameters/force_viptask_select_rq#0;/sys/module/migt/parameters/force_forbidden_walt_lb#0;/sys/module/migt/parameters/vip_task_max_num#0;/sys/module/migt/parameters/vip_prefer_cluster#1;/sys/module/migt/parameters/render_prefer_cluster#1;/sys/module/migt/parameters/stask_prefer_cluster#3;/data/system/mcd/raf_debug#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#-5 940800:-14 1440000:-20"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ],
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update"
              }
            ]
          },
          {
            "game_name": "com.tencent.fifamobile",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "CPU0_MAX#2016000"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_FC_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "COMMON3",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_FC_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.zz.mm",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-6"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C40000_FC_40C3C000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.tmgp.supercell.brawlstars",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "/sys/devices/system/cpu/cpu7/core_ctl/min_cpus#1"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/top-app/cpus#3-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "dev/cpuset/foreground/cpus#0-7"
                  },
                  {
                    "permission": "root",
                    "cmd": "T0_LOADS#0 940800:-5 1440000:-10"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C20100_55_40C20200_55_40C1C100_5F_40C1C200_5F#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.tmgp.codev",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40CE0000_0064005F_40CE0200_00410037_40C3C000_FC_40C40000_FC#0"
                  }
                ]
              }
            ]
          },
          {
            "game_name": "com.tencent.tmgp.maplem",
            "scene_ovrride": [
              {
                "scene_id": 1004,
                "end": [
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#787200"
                  }
                ],
                "scene_name": "target_fps_update",
                "booster": [
                  {
                    "permission": "root",
                    "cmd": "PERFMGR_ENABLE#1;CPU0_MAX#1459200;CORE2_CTL#0;CORE5_CTL#0;CORE7_CTL#0"
                  },
                  {
                    "permission": "root",
                    "cmd": "sys/devices/system/cpu/cpu0/cpufreq/walt/rtg_boost_freq#800000"
                  },
                  {
                    "permission": "root",
                    "cmd": "PERFMGR/scaling_a#450;PERFMGR/scaling_b#-80;PERFMGR/scaling_c#2;PERFMGR/fast_down_circle_base#3;PERFMGR/cons_no_j_cnt#8"
                  },
                  {
                    "permission": "root",
                    "cmd": "glk#BP#0;/data/system/mcd/raf_debug#2;/data/system/mcd/policy#Job.Worker:6:2:4,UnityGfxDeviceW:1:2:4,UnityMain:1:7:7"
                  },
                  {
                    "permission": "root",
                    "cmd": "perflock#42C08000_0_43C00000_1_40C3C000_FC#0"
                  }
                ]
              }
            ]
          }
        ]
      },
      "booster_debug_log_collect_config": {
        "L3_jank_debug_log_enable": false,
        "L3_threshold_jank_percent": 10,
        "max_trace_file_num_per_game": 2,
        "trace_events": "gfx,input,view,audio,hal,power,sched,freq,idle,binder_driver,binder_lock",
        "trace_rest_time_by_second": 15
      },
      "booster_enable": true,
      "cgame_df": [
        "com.tencent.tmgp.sgame@120#10:0,45:110,46:90"
      ],
      "cgame_enable": true,
      "clusterList": [
        0,
        2,
        5,
        7
      ],
      "cpuset_enable": true,
      "dynamic_fps_global": {
        "dynamic_fps": "10:0,43:90,45:60",
        "dynamic_fps_M": "10:0,38:90,42.8:60"
      },
      "dynamic_performance": "1#0",
      "force_scale_app_list": [
        "com.netease.g67:560#1.66;420#1.25:com.netease.game.MessiahNativeActivity",
        "com.netease.g67.mi:560#1.66;420#1.25:com.netease.game.MessiahNativeActivity"
      ],
      "gameIdentify_whitelist": [
        "com.phonetest.stresstest",
        "com.drawelements.deqp",
        "com.antutu.ABenchMark",
        "com.antutu.ABenchMark5",
        "com.antutu.benchmark.bench64",
        "com.antutu.videobench",
        "com.antutu.ABenchMark.GL2",
        "com.antutu.tester",
        "com.antutu.benchmark.full",
        "com.music.videogame",
        "com.ludashi.benchmark",
        "com.ludashi.benchmarkhd",
        "com.qihoo360.ludashi.cooling",
        "cn.opda.android.activity",
        "com.shouji.cesupaofen",
        "com.colola.mobiletest",
        "ws.j7uxli.a6urcd",
        "com.gamebench.metricscollector",
        "com.huahua.test",
        "com.futuremark.dmandroid.application",
        "com.eembc.coremark",
        "com.rightware.BasemarkOSII",
        "com.glbenchmark.glbenchmark27",
        "com.greenecomputing.linpack",
        "eu.chainfire.cfbench",
        "com.primatelabs.geekbench",
        "com.primatelabs.geekbench3",
        "com.quicinc.vellamo",
        "com.aurorasoftworks.quadrant.ui.advanced",
        "com.aurorasoftworks.quadrant.ui.standard",
        "eu.chainfire.perfmon",
        "com.evozi.deviceid",
        "com.finalwire.aida64",
        "com.cpuid.cpu_z",
        "rs.in.luka.android.pi",
        "com.uzywpq.cqlzahm",
        "com.xidige.androidinfo",
        "com.appems.hawkeye",
        "com.tyyj89.androidsuperinfo",
        "com.ft1gp",
        "ws.k6t2we.b4zyjdjv",
        "com.myapp.dongxie_app1",
        "com.shoujijiance.zj",
        "com.qrj.test",
        "com.appems.testonetest",
        "com.andromeda.androbench2",
        "com.primatelabs.geekbench5.corporate",
        "net.kishonti.gfxbench.vulkan.v50000.corporate",
        "com.antutu.ABenchMark.lite",
        "com.antutu.aibenchmark",
        "com.ludashi.benchmark2",
        "com.ludashi.aibench",
        "com.primatelabs.geekbench5c",
        "com.primatelabs.geekbench5",
        "com.primatelabs.geekbench4.corporate",
        "net.kishonti.gfxbench.gl.v40001.corporate",
        "org.benchmark.demo",
        "com.android.gputest",
        "android.test.app",
        "com.ioncannon.cpuburn.gpugflops",
        "ioncannon.com.andspecmod",
        "skynet.cputhrottlingtest",
        "com.openai.chatgpt",
        "com.discord",
        "com.miui.weather3"
      ],
      "game_group_mapping_config": [
        {
          "game_group_name": "SGAME",
          "package_list": [
            "com.tencent.tmgp.sgame",
            "com.tencent.tmgp.sgamece"
          ]
        },
        {
          "game_group_name": "YUANSHEN",
          "package_list": [
            "com.miHoYo.Yuanshen",
            "com.miHoYo.GenshinImpact",
            "com.miHoYo.ys.mi",
            "com.miHoYo.ys.bilibili"
          ]
        },
        {
          "game_group_name": "PUBG",
          "package_list": [
            "com.tencent.tmgp.pubgmhd",
            "com.tencent.ig"
          ]
        },
        {
          "game_group_name": "HARRYPOTTER",
          "package_list": [
            "com.netease.harrypotter",
            "com.netease.harrypotter.mi"
          ]
        }
      ],
      "game_group_mapping_enable": true,
      "game_identify": false,
      "low_display_refresh_rate_scenes": [
        1,
        2,
        3,
        4,
        5
      ],
      "migl_settings": {
        "enable": true,
        "game_params": [
          {
            "force_source_crop": "420#ignore;ignore;ignore&560#ignore;ignore;864,1920,1440,3200",
            "force_source_crop_re": "1:ignore;2:ignore;3:864,1920,1200,2670;4:864,1920,1440,3200;5:864,1920,1440,3200",
            "game": "yuanshen",
            "game_cmdlines": [
              "com.miHoYo.Yuanshen",
              "com.miHoYo.GenshinImpact",
              "com.miHoYo.ys.mi",
              "com.miHoYo.ys.bilibili"
            ],
            "params": {
              "migl_drr": [
                {
                  "drr_available_size": "1620x728;1548x696;1476x663",
                  "drr_base_size": "1620x728",
                  "drr_illegal_size": "1296x582;1024x460;864x388;776x348",
                  "drr_update_interval": "10"
                }
              ],
              "tex_size_v3": [
                {
                  "max_resolution": "1920x864;1620x728",
                  "max_resolution_80p": "1536x690;1296x582",
                  "post_process_high": "1920x864;1620x728;1280x576;1080x486;972x436",
                  "post_process_low": "1536x690;1296x582;1024x460;864x388;776x348",
                  "tex_size_config_density": "420#1440x648;-1x-1;1920x864&560#1440x648;-1x-1;3200x1440",
                  "tex_size_config_re": "1:1440x648;2:1920x864;3:2670x1200;4:3200x1440;5:3200x1440"
                }
              ],
              "ys_launch_recognize": "1",
              "ys_transfer_recognize": "1"
            }
          },
          {
            "game": "hkrpg",
            "game_cmdlines": [
              "com.miHoYo.hkrpg"
            ],
            "params": {
              "hkrpg_scene_recognize": "1"
            }
          },
          {
            "game": "pubg",
            "game_cmdlines": [
              "com.tencent.tmgp.pubgmhd"
            ],
            "params": {
              "tex_param_anisotropy": "1"
            }
          }
        ]
      },
      "monitor": {
        "analytics_enable": false,
        "default_interval": 2,
        "monitor_enable": false
      },
      "mqs_enhance_list": [
        "com.miHoYo.hkrpg:60#default",
        "com.miHoYo.Yuanshen:60#default",
        "com.miHoYo.ys.mi:60#default"
      ],
      "predownload_enable": true,
      "qsync_enable": false,
      "recommend_tgame_thresh": "44#90",
      "scale_app_enable": true,
      "scene_id_reuse": true,
      "scene_id_sender_enable": true,
      "support_display_refresh_rates": [
        60,
        90,
        120
      ],
      "support_dynamic_refresh_rate_games": [
        "com.tencent.tmgp.sgame",
        "com.tencent.lolm",
        "com.tencent.ig",
        "com.tencent.tmgp.speedmobile",
        "com.tencent.tmgp.pubgmhd"
      ],
      "support_highfps_app": [
        "com.tencent.tmgp.sgame:120",
        "com.tencent.tmgp.sgamece:120",
        "com.tencent.tmgp.gnyx:90",
        "com.activision.callofduty.shooter:90",
        "com.netease.lztg1.mi:120",
        "com.netease.lztg:120",
        "com.tencent.tmgp.cf:120",
        "com.pwrd.xxajh.laohu:120",
        "com.pwrd.xxajh.mi:120",
        "com.miHoYo.bh3.mi:90",
        "com.miHoYo.enterprise.NGHSoD:90",
        "com.t2ksports.nba2k20and:60",
        "com.tencent.af:120",
        "com.tencent.tmgp.pubgmhd:120",
        "com.tencent.tmgp.speedmobile:120",
        "com.tencent.YiRen:120",
        "com.tencent.KiHan:120",
        "com.tencent.ig:90",
        "com.tencent.tmgp.cod:120",
        "com.tencent.tmgp.codty:120",
        "com.denachina.g13002010.mi:120",
        "com.denachina.g13002010.denacn:120",
        "com.tencent.lolm:120",
        "com.pwrd.hotta.laohu:90",
        "com.hottagames.hotta.mi:90",
        "com.netease.moba.mi:90",
        "com.netease.moba:90",
        "com.youzu.bs.mi:90",
        "com.youzu.bs:90",
        "com.tencent.mf.uam:120",
        "com.tencent.mf.uamty:120",
        "com.miHoYo.hkrpg:60",
        "com.xd.rotaeno.googleplay:120",
        "com.tencent.game.rhythmmaster:120",
        "com.tencent.jkchess:120",
        "com.miHoYo.Nap:60"
      ],
      "support_motor_app": [],
      "support_predownload_app_list": [
        "com.tencent.tmgp.pubgmhd",
        "com.tencent.tmgp.projectg",
        "com.tencent.tmgp.sgamece#1",
        "com.tencent.tmgp.sgame#1"
      ],
      "support_scale_app_list": [
        "com.miHoYo.enterprise.NGHSoD",
        "com.happyelements.AndroidAnimal",
        "cn.jj",
        "com.tencent.tmgp.speedmobile",
        "com.blizzard.wtcg.hearthstone",
        "com.tencent.peng",
        "com.tencent.qqgame.xq",
        "com.qqgame.happymj",
        "com.tencent.tmgp.tstl",
        "com.tencent.wmsj",
        "com.tencent.swy",
        "com.tencent.tmgp.qqx5",
        "com.tencent.tmgp.wec",
        "com.tencent.shootgame",
        "com.tencent.tmgp.vgame",
        "com.tencent.tmgp.mt4",
        "com.tencent.woool3d",
        "com.tencent.xishanju.xj4",
        "com.tencent.tmgp.redfox",
        "com.tencent.wdqy",
        "com.tencent.YiRen",
        "com.tencent.tmgp.ylm",
        "com.tencent.yoozoo.got.wintercoming",
        "com.tencent.hxh",
        "com.tencent.tmgp.sskgame",
        "com.minitech.miniworld",
        "com.bairimeng.dmmdzz",
        "com.netease.tom",
        "com.supercell.clashofclans.kunlun",
        "com.aligames.sgzzlb",
        "com.outfit7.talkingtomgoldrun.bd",
        "com.bf.sgs.hdexp",
        "com.lilithgames.hgame.cn",
        "com.supercell.clashroyale.kunlun",
        "com.ChillyRoom.DungeonShooter",
        "com.wepie.snake",
        "com.ledou.mhhy",
        "com.gbits.atm.leiting",
        "com.shiyi.bkby",
        "com.jiguang.dldl.sy37",
        "com.qidian.dldl.official",
        "com.papegames.nn4.cn",
        "com.wanmei.zhuxian.laohu",
        "com.qhjx.snk.sy371",
        "com.szxchd.yqxx.dodsdk",
        "com.sqw.sssf",
        "com.hermes.bgame",
        "com.netease.lx7",
        "com.taomee.huah",
        "com.soulgame.shokudo.kuaishou"
      ],
      "support_vrs_app": [
        "com.miHoYo.Yuanshen",
        "com.miHoYo.hkrpg",
        "com.qihoo.camera",
        "io.wallpaperengine.weclient",
        "com.netease.nshm",
        "com.netease.nshm.mi"
      ],
      "support_ysre": true,
      "tuner_enable": true
    },
    "header": {
      "index_enable": true,
      "mqs_enable": true,
      "network_improve": true,
      "version": "2024123199"
    }
  },
  "version": 2024123199,
  "with_model": false
}');

-- ----------------------------
-- Auto increment value for rules
-- ----------------------------
UPDATE "sqlite_sequence" SET seq = 1 WHERE name = 'rules';

PRAGMA foreign_keys = true;
