#!/system/bin/sh
# shellcheck disable=SC2044
MODDIR=${0%/*}
socid=$(cat "$MODDIR"/functions/socid)
scaling_available_governors="$(find /sys/devices/system/cpu/cpufreq -name "scaling_available_governors" -print -quit)"
while [ "$(getprop vendor.post_boot.parsed)" != "1" ]; do
  sleep 1
done
if [ "$1" = "uag" ]; then
  if [ "$(grep -c 'uag' "$scaling_available_governors")" -ge 1 ]; then
    for scaling_governor in $(find /sys/devices/system/cpu/cpufreq -name "scaling_governor"); do
      echo uag >"$scaling_governor"
    done
    for stall_aware in $(find /sys/devices/system/cpu/cpufreq -name "stall_aware"); do
      echo 1 >"$stall_aware"
    done
    if [ "$socid" = "SM8650" ]; then
      for cobuck_enable in $(find /sys/devices/system/cpu/cpufreq -name "cobuck_enable"); do
        if [ "$(echo "$cobuck_enable" | cut -d'/' -f7)" != "policy7" ]; then
          echo 1 >"$cobuck_enable"
        fi
      done
    fi
  fi
else
  if [ "$(grep -c 'walt' "$scaling_available_governors")" -ge 1 ]; then
    for scaling_governor in $(find /sys/devices/system/cpu/cpufreq -name "scaling_governor"); do
      echo walt >"$scaling_governor"
    done
  else
    for scaling_governor in $(find /sys/devices/system/cpu/cpufreq -name "scaling_governor"); do
      echo schedutil >"$scaling_governor"
    done
  fi
fi
