. /data/adb/agh/settings.conf

$SCRIPT_DIR/tool.sh toggle

sleep 1
