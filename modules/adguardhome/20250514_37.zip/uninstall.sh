[ -d "/data/adb/agh" ] && rm -rf "/data/adb/agh"
