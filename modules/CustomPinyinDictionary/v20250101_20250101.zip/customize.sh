SKIPUNZIP=1
ASH_STANDALONE=1
DIVIDE_STR="*********************************************************"
MODULE_DIR=/data/adb/modules/$MODID
INSTALL_STATUS=0
MODULE_DATA=/data/adb/wuhgit/CustomPinyinDictionary/gboard
GBOARD_PACKAGENAME=com.google.android.inputmethod.latin
CUID=$(am get-current-user)

enforce_install_from_app() {
  if $BOOTMODE; then
    if [ "$KSU" ]; then
      ui_print "- 正在通过 KernelSU 进行安装"
      ui_print "- KernelSU 版本: $KSU_KERNEL_VER_CODE (kernel) + $KSU_VER_CODE (ksud)"
      if ! [ "$KSU_KERNEL_VER_CODE" ] || [ "$KSU_KERNEL_VER_CODE" -lt 10940 ]; then
        ui_print "$DIVIDE_STR"
        ui_print "! 请将 KernelSU 升级到最新版本！"
        abort "$DIVIDE_STR"
      fi
    else
      ui_print "- 正在通过 Magisk 进行安装"
      ui_print "- Magisk 版本: $MAGISK_VER_CODE"
      if [ "$MAGISK_VER_CODE" -lt 24000 ]; then
        ui_print "$DIVIDE_STR"
        ui_print "! 请升级 Magisk 到 v24.0+ (24000+)以上版本"
        abort "$DIVIDE_STR"
      fi
    fi
  else
    ui_print "$DIVIDE_STR"
    ui_print "! 模块不支持通过 recovery 安装！"
    ui_print "! 请使用 Magisk 或者 KernelSU"
    abort "$DIVIDE_STR"
  fi
}

unzip -o "$ZIPFILE" -d "$TMPDIR" >&2
if [ ! -f "$TMPDIR/verify.sh" ]; then
  ui_print "$DIVIDE_STR"
  ui_print "! verify.sh 不存在！"
  ui_print "! 此模块可能被篡改，请重新下载！"
  abort "$DIVIDE_STR"
fi
ui_print "- 正在准备 verify.sh"
. "$TMPDIR/verify.sh"

enforce_install_from_app

VERSION=$(grep_prop version "${TMPDIR}/module.prop")
ui_print " "
ui_print " "
ui_print "$DIVIDE_STR"
ui_print "Gboard自建拼音输入法词库"
ui_print " "
ui_print "${VERSION}"
ui_print " "
ui_print "https://github.com/wuhgit/CustomPinyinDictionary"
ui_print "$DIVIDE_STR"
ui_print "- 提取文件……"

if [ ! -d "/data/user/$CUID" ]; then
  ui_print "- 无法识别当前用户，默认为主用户……"
  CUID=0
fi

mkdir -p $MODULE_DATA
touch $MODULE_DATA/$CUID
chmod -R 0755 $TMPDIR/tools

exxit() {
  set +eu
  $KSU || {
    rm -rf /data/adb/modules_update/$MODID
    (abort) >/dev/null
  }
  echo
  exit
} 2>/dev/null

trap exxit EXIT

chooseport_legacy() {
  # Keycheck binary by someone755 @Github, idea for code below by Zappo @xda-developers
  # Calling it first time detects previous input. Calling it second time will do what we want
  [ "$1" ] && local delay=$1 || local delay=3
  local error=false
  while true; do
    timeout 0 $TMPDIR/tools/$ARCH32/keycheck
    timeout $delay $TMPDIR/tools/$ARCH32/keycheck
    local sel=$?
    if [ $sel -eq 42 ]; then
      return 0
    elif [ $sel -eq 41 ]; then
      return 1
    elif $error; then
      abort "未检测到音量键!"
    else
      error=true
      echo "未检测到音量键，请再试一次。"
    fi
  done
}

chooseport() {
  # Original idea by chainfire and ianmacd @xda-developers
  [ "$1" ] && local delay=$1 || local delay=3
  local error=false
  while true; do
    local count=0
    while true; do
      timeout $delay /system/bin/getevent -lqc 1 2>&1 >$TMPDIR/events &
      sleep 0.5
      count=$((count + 1))
      if ($(grep -q 'KEY_VOLUMEUP *DOWN' $TMPDIR/events)); then
        return 0
      elif ($(grep -q 'KEY_VOLUMEDOWN *DOWN' $TMPDIR/events)); then
        return 1
      fi
      [ $count -gt 10 ] && break
    done
    if $error; then
      echo "未检测到音量键，请再试一次。"
      export chooseport=chooseport_legacy VKSEL=chooseport_legacy
      chooseport_legacy $delay
      return $?
    else
      error=true
      echo "未检测到音量键，请再试一次。"
    fi
  done
}

data_install() {
  if [ ! -n "$1" ]; then
    ui_print " -$1,参数错误！"
  else
    if [ "$1" -ne "0" ]; then
      USER_DESC="用户$1"
    else
      USER_DESC="主用户"
    fi
    I_DATA_UID=$(pm list packages -U --user $1 $GBOARD_PACKAGENAME | cut -f3 -d ":")
    if [ ! -n "$I_DATA_UID" ]; then
      ui_print "- $USER_DESC未检测到Gboard，已跳过安装……"
      rm $MODULE_DATA/$1 2>/dev/null
    else
      if [ ! -d "/data/user/$1/$GBOARD_PACKAGENAME/databases/" ]; then
        ui_print "- 数据库文件夹不存在！"
      else
        DB_FILE=/data/user/$1/$GBOARD_PACKAGENAME/databases/PersonalDictionary.db
        ui_print "- 正在为 $USER_DESC 安装……"
        ui_print "- 写入数据……"
        cp -f $TMPDIR/dict/db $DB_FILE
        chown $I_DATA_UID $DB_FILE
        chgrp $I_DATA_UID $DB_FILE
        chmod 600 $DB_FILE
        INSTALL_STATUS=1
      fi
    fi
  fi
}

data_install_prepare() {
  ui_print "- 准备开始安装"
  for I_ID in $MODULE_DATA/*; do
    data_install ${I_ID##*/}
  done
  if [ $INSTALL_STATUS -ne "0" ]; then
    am force-stop $GBOARD_PACKAGENAME
    ui_print "- 安装完成！"
    ui_print "  新词可能需要一段时间才能生效。"
    ui_print "  无须重启，请忽略重启要求。"
  else
    abort "- 错误！未能成功安装！"
  fi
}

data_uninstall() {
  if [ ! -n "$1" ]; then
    ui_print " -$1,参数错误！"
  else
    if [ "$1" -ne "0" ]; then
      USER_DESC="用户$1"
    else
      USER_DESC="主用户"
    fi
    DATA_UID=$(pm list packages -U --user $1 $GBOARD_PACKAGENAME | cut -f3 -d ":")
    if [ -n "$DATA_UID" ] && [ -d "/data/user/$1/$GBOARD_PACKAGENAME/databases/" ]; then
      DB_FILE=/data/user/$1/$GBOARD_PACKAGENAME/databases/PersonalDictionary.db
      cp -f $TMPDIR/dict/empty $DB_FILE
      ui_print "- $USER_DESC 数据已卸载……"
      chown $DATA_UID $DB_FILE
      chgrp $DATA_UID $DB_FILE
      chmod 600 $DB_FILE
    fi
    rm $MODULE_DATA/$CUID 2>/dev/null
  fi
}

data_uninstall_prepare() {
  ui_print "- 准备开始卸载"
  data_uninstall $CUID
  for U_UID in $(pm list users | grep -E "UserInfo" | cut -f1 -d ":" | cut -f2 -d "{" | xargs); do
    if [ ! -f "$MODULE_DATA/$U_UID" ]; then
      data_uninstall $U_UID
    fi
  done
  am force-stop $GBOARD_PACKAGENAME
  ui_print "- 单一用户："
  ui_print "    在执行卸载后，"
  ui_print "    请在模块管理中对此模块进行移除。"
  ui_print "- 多用户："
  ui_print "    若其它用户也安装有此模块，"
  ui_print "    请确保其它用户均已完成卸载，再执行移除。"
}

ui_print " "
ui_print "请使用音量键选择操作："
ui_print "  "
ui_print "  安装    音量+"
ui_print "  卸载    音量-"
ui_print "  "
if chooseport; then
  data_install_prepare
else
  data_uninstall_prepare
fi

! $KSU || {
  rm -rf /data/adb/modules_update/$MODID 2>/dev/null || :
  if [ $INSTALL_STATUS -ne "0" ]; then
    mkdir -p $MODULE_DIR
    cp -f "$TMPDIR/module.prop" "$MODULE_DIR/module.prop"
    set_perm_recursive "$MODULE_DIR" 0 0 0755 0644
  fi
  cp -a $MODULE_DIR /data/adb/modules_update
  touch $MODULE_DIR/update
}

exit
